<?php
// emoji_store.php
// Dedicated emoji store for a comic — users spend coins to unlock special emojis
// Link here from comic.php: emoji_store.php?id=COMIC_ID

require_once 'db.php';

$comicId = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$comicId) { header('Location: index.php'); exit; }

// Fetch comic info
$comicStmt = $pdo->prepare("SELECT ID, Name, Title, HardCopyLink FROM COMIC WHERE ID = ?");
$comicStmt->execute([$comicId]);
$comic = $comicStmt->fetch();
if (!$comic) { header('Location: index.php'); exit; }

$comicTitle  = $comic['Title'] ?: $comic['Name'];
$pageTitle   = $comicTitle . ' — Emoji Store';

// Coin balance for logged-in user
$balance    = 0;
$ownedNames = []; // emoji names the user already owns
if (isUserLoggedIn()) {
    $uid = intval($_SESSION['user_id']);

    $balStmt = $pdo->prepare("SELECT COALESCE(SUM(Amount), 0) FROM COIN_TRANSACTION WHERE UID = ?");
    $balStmt->execute([$uid]);
    $balance = intval($balStmt->fetchColumn());

    $ownedStmt = $pdo->prepare("SELECT Emoji_Name FROM USER_EMOJI WHERE UID = ?");
    $ownedStmt->execute([$uid]);
    $ownedNames = $ownedStmt->fetchAll(PDO::FETCH_COLUMN);
}

// Fetch all emojis for this comic
$emojiStmt = $pdo->prepare("
    SELECT Name, E_Value, Coin_Amount
    FROM SPECIAL_EMOJI
    WHERE Comic_ID = ?
    ORDER BY Coin_Amount ASC, Name ASC
");
$emojiStmt->execute([$comicId]);
$emojis = $emojiStmt->fetchAll();

require_once 'header.php';
?>

<style>
/* ── Store layout ──────────────────────────────────── */
.store-page {
    max-width: 900px;
    margin: 0 auto;
    padding: 30px 20px;
}

.store-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    gap: 16px;
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--border-color);
}

.store-header-left h1 {
    font-size: 1.5rem;
    margin-bottom: 6px;
}

.store-header-left p {
    color: var(--text-muted);
    font-size: 0.9rem;
}

.store-balance-box {
    display: flex;
    align-items: center;
    gap: 10px;
    background: rgba(243, 156, 18, 0.1);
    border: 1px solid rgba(243, 156, 18, 0.35);
    border-radius: var(--radius-md);
    padding: 12px 18px;
}

.store-balance-box .label {
    font-size: 0.8rem;
    color: var(--text-muted);
}

.store-balance-box .amount {
    font-size: 1.3rem;
    font-weight: 700;
    color: #f39c12;
}

/* ── Login banner ──────────────────────────────────── */
.store-login-banner {
    background: rgba(52, 152, 219, 0.08);
    border: 1px solid rgba(52, 152, 219, 0.3);
    border-radius: var(--radius-md);
    padding: 16px 20px;
    margin-bottom: 28px;
    font-size: 0.9rem;
    color: var(--text-secondary);
}

.store-login-banner a { color: var(--accent-secondary); text-decoration: underline; }

/* ── Emoji grid ────────────────────────────────────── */
.emoji-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
    gap: 18px;
}

.emoji-card {
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-lg);
    padding: 20px 16px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 12px;
    transition: border-color 0.2s, transform 0.15s;
    text-align: center;
}

.emoji-card:hover {
    border-color: var(--accent-secondary);
    transform: translateY(-2px);
}

.emoji-card.owned {
    border-color: var(--success);
    background: rgba(39, 174, 96, 0.05);
}

.emoji-preview {
    width: 80px;
    height: 80px;
    object-fit: contain;
    border-radius: var(--radius-md);
    background: rgba(255,255,255,0.04);
    padding: 6px;
}

/* Fallback when image fails */
.emoji-preview-fallback {
    width: 80px;
    height: 80px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2.5rem;
    background: rgba(255,255,255,0.04);
    border-radius: var(--radius-md);
}

.emoji-name {
    font-size: 0.88rem;
    font-weight: 600;
    color: var(--text-primary);
    word-break: break-word;
}

.emoji-cost {
    font-size: 0.82rem;
    color: #f39c12;
    font-weight: 600;
}

.owned-badge {
    display: inline-block;
    background: rgba(39, 174, 96, 0.2);
    color: var(--success);
    border: 1px solid var(--success);
    border-radius: 20px;
    padding: 3px 12px;
    font-size: 0.75rem;
    font-weight: 700;
}

.btn-buy {
    width: 100%;
    padding: 8px 12px;
    background: var(--accent-secondary, #3498db);
    color: #fff;
    border: none;
    border-radius: var(--radius-md);
    font-size: 0.85rem;
    font-weight: 600;
    cursor: pointer;
    transition: opacity 0.2s;
}

.btn-buy:hover   { opacity: 0.85; }
.btn-buy:disabled { opacity: 0.45; cursor: not-allowed; }

/* ── Toast / result message ────────────────────────── */
#storeToast {
    position: fixed;
    bottom: 24px;
    left: 50%;
    transform: translateX(-50%) translateY(80px);
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    padding: 12px 22px;
    font-size: 0.9rem;
    font-weight: 500;
    box-shadow: 0 8px 24px rgba(0,0,0,0.4);
    transition: transform 0.3s ease, opacity 0.3s ease;
    opacity: 0;
    z-index: 999;
    white-space: nowrap;
}

#storeToast.show       { transform: translateX(-50%) translateY(0); opacity: 1; }
#storeToast.toast-ok   { border-color: var(--success); color: var(--success); }
#storeToast.toast-err  { border-color: var(--accent-primary); color: var(--accent-primary); }

/* ── Empty state ───────────────────────────────────── */
.store-empty {
    text-align: center;
    padding: 60px 20px;
    color: var(--text-muted);
}

@media (max-width: 600px) {
    .store-header   { flex-direction: column; }
    .emoji-grid     { grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); }
}
</style>

<div class="store-page">

    <!-- Header -->
    <div class="store-header">
        <div class="store-header-left">
            <h1>🛍️ <?php echo h($comicTitle); ?> Emoji Store</h1>
            <p>Purchase exclusive emojis to use in community posts. Earn coins by predicting correctly!</p>
            <div style="margin-top: 10px;">
                <a href="comic.php?id=<?php echo $comicId; ?>" class="btn btn-outline">← Back to Comic</a>
                <a href="community.php?id=<?php echo $comicId; ?>" class="btn btn-outline" style="margin-left: 8px;">💬 Community</a>
            </div>
        </div>

        <?php if (isUserLoggedIn()): ?>
            <div class="store-balance-box">
                <span style="font-size: 1.4rem;">🪙</span>
                <div>
                    <div class="label">Your Balance</div>
                    <div class="amount" id="balanceDisplay"><?php echo $balance; ?> coins</div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <?php if (!isUserLoggedIn()): ?>
        <div class="store-login-banner">
            🔒 <a href="login_user.php">Log in</a> to purchase emojis and use them in community posts.
        </div>
    <?php endif; ?>

    <?php if (empty($emojis)): ?>
        <div class="store-empty">
            <p style="font-size: 2rem; margin-bottom: 12px;">🎭</p>
            <p>No special emojis available for this comic yet. Check back later!</p>
        </div>
    <?php else: ?>
        <div class="emoji-grid" id="emojiGrid">
            <?php foreach ($emojis as $emoji):
                $isOwned = in_array($emoji['Name'], $ownedNames);
                $canAfford = ($balance >= $emoji['Coin_Amount']);
            ?>
                <div class="emoji-card <?php echo $isOwned ? 'owned' : ''; ?>"
                     id="card-<?php echo h($emoji['Name']); ?>">

                    <!-- Preview image -->
                    <img class="emoji-preview"
                         src="<?php echo h($emoji['E_Value']); ?>"
                         alt="<?php echo h($emoji['Name']); ?>"
                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div class="emoji-preview-fallback" style="display:none;">🖼️</div>

                    <div class="emoji-name"><?php echo h($emoji['Name']); ?></div>

                    <div class="emoji-cost">
                        🪙 <?php echo $emoji['Coin_Amount']; ?> coin<?php echo $emoji['Coin_Amount'] !== 1 ? 's' : ''; ?>
                    </div>

                    <?php if ($isOwned): ?>
                        <span class="owned-badge">✓ Owned</span>
                    <?php elseif (!isUserLoggedIn()): ?>
                        <button class="btn-buy" disabled>Log in to buy</button>
                    <?php else: ?>
                        <button class="btn-buy"
                                <?php echo !$canAfford ? 'disabled title="Not enough coins"' : ''; ?>
                                onclick="purchaseEmoji(this, '<?php echo h($emoji['Name']); ?>', <?php echo $emoji['Coin_Amount']; ?>)">
                            <?php echo $canAfford ? 'Buy' : 'Need more coins'; ?>
                        </button>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Toast notification -->
<div id="storeToast"></div>

<script>
const comicId = <?php echo $comicId; ?>;

function purchaseEmoji(btn, emojiName, cost) {
    if (!confirm(`Buy "${emojiName}" for ${cost} coin${cost !== 1 ? 's' : ''}?`)) return;

    btn.disabled   = true;
    btn.textContent = 'Buying…';

    fetch('emoji_purchase.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `emoji_name=${encodeURIComponent(emojiName)}&comic_id=${comicId}`
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            // Update the card to owned state
            const card = document.getElementById('card-' + emojiName);
            card.classList.add('owned');
            btn.replaceWith((() => {
                const badge = document.createElement('span');
                badge.className   = 'owned-badge';
                badge.textContent = '✓ Owned';
                return badge;
            })());

            // Update balance display
            const balEl = document.getElementById('balanceDisplay');
            if (balEl) balEl.textContent = data.new_balance + ' coins';

            // Disable any buttons that user can no longer afford
            refreshAffordability(data.new_balance);

            showToast(data.message, 'ok');
        } else {
            btn.disabled    = false;
            btn.textContent = 'Buy';
            showToast(data.message, 'err');
        }
    })
    .catch(() => {
        btn.disabled    = false;
        btn.textContent = 'Buy';
        showToast('Network error. Please try again.', 'err');
    });
}

function refreshAffordability(newBalance) {
    document.querySelectorAll('.btn-buy:not([disabled])').forEach(b => {
        const cost = parseInt(b.closest('.emoji-card').querySelector('.emoji-cost').textContent);
        if (newBalance < cost) {
            b.disabled    = true;
            b.textContent = 'Need more coins';
            b.title       = 'Not enough coins';
        }
    });
}

let toastTimer;
function showToast(msg, type) {
    const t = document.getElementById('storeToast');
    t.textContent = msg;
    t.className   = 'show toast-' + type;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.className = ''; }, 3500);
}
</script>

<?php require_once 'footer.php'; ?>
