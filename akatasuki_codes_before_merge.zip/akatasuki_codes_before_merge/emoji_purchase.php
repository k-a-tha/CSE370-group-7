<?php
// emoji_purchase.php
// AJAX endpoint — returns JSON only, no HTML output
// Called via fetch() from emoji_store.php

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'db.php';

// ---- Auth check ----
$isUser = isset($_SESSION['user_id']) && isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'user';
if (!$isUser) {
    echo json_encode(['success' => false, 'message' => 'You must be logged in to purchase emojis.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

$emojiName = trim($_POST['emoji_name'] ?? '');
$comicId   = intval($_POST['comic_id'] ?? 0);
$userId    = intval($_SESSION['user_id']);

if (empty($emojiName) || !$comicId) {
    echo json_encode(['success' => false, 'message' => 'Invalid request parameters.']);
    exit;
}

try {
    // ---- Fetch and validate the emoji ----
    $emojiStmt = $pdo->prepare("
        SELECT Name, E_Value, Coin_Amount, Comic_ID
        FROM SPECIAL_EMOJI
        WHERE Name = ? AND Comic_ID = ?
    ");
    $emojiStmt->execute([$emojiName, $comicId]);
    $emoji = $emojiStmt->fetch();

    if (!$emoji) {
        echo json_encode(['success' => false, 'message' => 'Emoji not found for this comic.']);
        exit;
    }

    // ---- Check the user doesn't already own it ----
    $ownedStmt = $pdo->prepare("SELECT 1 FROM USER_EMOJI WHERE UID = ? AND Emoji_Name = ?");
    $ownedStmt->execute([$userId, $emojiName]);
    if ($ownedStmt->fetchColumn()) {
        echo json_encode(['success' => false, 'message' => 'You already own this emoji!']);
        exit;
    }

    // ---- Check coin balance ----
    $balStmt = $pdo->prepare("SELECT COALESCE(SUM(Amount), 0) FROM COIN_TRANSACTION WHERE UID = ?");
    $balStmt->execute([$userId]);
    $balance = intval($balStmt->fetchColumn());

    if ($balance < $emoji['Coin_Amount']) {
        echo json_encode([
            'success' => false,
            'message' => "Not enough coins! You have {$balance} but need {$emoji['Coin_Amount']}."
        ]);
        exit;
    }

    // ---- Deduct coins and record ownership atomically ----
    $pdo->beginTransaction();

    // Deduct: negative COIN_TRANSACTION
    $deductStmt = $pdo->prepare("
        INSERT INTO COIN_TRANSACTION (Amount, Time_stamp, UID)
        VALUES (?, NOW(), ?)
    ");
    $deductStmt->execute([-$emoji['Coin_Amount'], $userId]);

    // Record ownership
    $ownInsert = $pdo->prepare("
        INSERT INTO USER_EMOJI (UID, Emoji_Name, Purchase_Date)
        VALUES (?, ?, NOW())
    ");
    $ownInsert->execute([$userId, $emojiName]);

    $pdo->commit();

    $newBalance = $balance - $emoji['Coin_Amount'];

    echo json_encode([
        'success'     => true,
        'message'     => "🎉 You unlocked \"{$emojiName}\"! Use it in community posts.",
        'new_balance' => $newBalance,
        'emoji_name'  => $emojiName,
    ]);

} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Transaction failed. Please try again.']);
}
