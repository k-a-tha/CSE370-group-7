<?php
// admin_panel.php
// Protected admin page - requires artist login
// Artists can only manage their OWN comics

if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'db.php';

$isArtist = isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'artist';
if (!$isArtist) { header('Location: login_artist.php'); exit; }

$artistId = intval($_SESSION['user_id'] ?? 0);
$message  = '';
$msgType  = 'success';

// ============================================================
// HELPER: verify a chapter belongs to this artist's comic
// ============================================================
function artistOwnsChapter(PDO $pdo, int $chapterId, int $artistId): bool {
    $stmt = $pdo->prepare("
        SELECT 1 FROM CHAPTER ch
        JOIN COMIC c ON ch.Comic_ID = c.ID
        WHERE ch.CHAPTER_ID = ? AND c.AID = ?
    ");
    $stmt->execute([$chapterId, $artistId]);
    return (bool)$stmt->fetch();
}

// ============================================================
// HELPER: verify a comic belongs to this artist
// ============================================================
function artistOwnsComic(PDO $pdo, int $comicId, int $artistId): bool {
    $stmt = $pdo->prepare("SELECT 1 FROM COMIC WHERE ID = ? AND AID = ?");
    $stmt->execute([$comicId, $artistId]);
    return (bool)$stmt->fetch();
}

// ============================================================
// POST: Create prediction poll
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create_poll') {
    $chapterId = intval($_POST['chapter_id'] ?? 0);
    $options   = array_filter(array_map('trim', $_POST['options'] ?? []), fn($o) => $o !== '');

    if (!$chapterId) {
        $message = 'Invalid chapter selected.'; $msgType = 'error';
    } elseif (!artistOwnsChapter($pdo, $chapterId, $artistId)) {
        $message = 'You do not have permission to create a poll for this chapter.'; $msgType = 'error';
    } elseif (count($options) !== 4) {
        $message = 'You must provide exactly 4 options.'; $msgType = 'error';
    } else {
        $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM PREDICTION_OPTION WHERE Chapter_ID = ?");
        $checkStmt->execute([$chapterId]);
        if ($checkStmt->fetchColumn() > 0) {
            $message = 'A poll already exists for this chapter. Delete it first.'; $msgType = 'error';
        } else {
            $insertStmt = $pdo->prepare("INSERT INTO PREDICTION_OPTION (Option_Number, OptionText, Chapter_ID) VALUES (?, ?, ?)");
            foreach (array_values($options) as $i => $text) {
                $insertStmt->execute([$i + 1, $text, $chapterId]);
            }
            $message = 'Prediction poll created successfully!';
        }
    }
}

// ============================================================
// POST: Publish chapter + resolve previous poll + distribute coins
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'publish_and_resolve') {
    $chapterToPublish = intval($_POST['chapter_to_publish'] ?? 0);
    $correctOptionId  = intval($_POST['correct_option_id']  ?? 0);
    $pollChapterId    = intval($_POST['poll_chapter_id']    ?? 0);

    if (!$chapterToPublish) {
        $message = 'Please select a chapter to publish.'; $msgType = 'error';
    } elseif (!artistOwnsChapter($pdo, $chapterToPublish, $artistId)) {
        $message = 'You do not have permission to publish this chapter.'; $msgType = 'error';
    } elseif ($pollChapterId && !artistOwnsChapter($pdo, $pollChapterId, $artistId)) {
        $message = 'You do not have permission to resolve that poll.'; $msgType = 'error';
    } elseif (!$correctOptionId || !$pollChapterId) {
        $pdo->prepare("UPDATE CHAPTER SET isPublished = TRUE WHERE CHAPTER_ID = ?")->execute([$chapterToPublish]);
        $message = 'Chapter published (no poll to resolve).';
    } else {
        try {
            $pdo->beginTransaction();

            $pollInfo = $pdo->prepare("
                SELECT po.OptionText, ch.ChapterNumber, c.Name AS ComicName, c.Title AS ComicTitle
                FROM PREDICTION_OPTION po
                JOIN CHAPTER ch ON po.Chapter_ID = ch.CHAPTER_ID
                JOIN COMIC   c  ON ch.Comic_ID   = c.ID
                WHERE po.ID = ?
            ");
            $pollInfo->execute([$correctOptionId]);
            $poll = $pollInfo->fetch();
            $comicTitle  = $poll ? ($poll['ComicTitle'] ?: $poll['ComicName']) : 'the comic';
            $chapterNo   = $poll['ChapterNumber'] ?? '?';
            $correctText = $poll['OptionText'] ?? 'the correct option';

            $pdo->prepare("UPDATE PREDICTION_OPTION SET IsResolved = TRUE, IsCorrect = (ID = ?) WHERE Chapter_ID = ?")
                ->execute([$correctOptionId, $pollChapterId]);

            $winners = $pdo->prepare("SELECT p.ID AS Prediction_ID, p.UID FROM PREDICTION p WHERE p.Option_ID = ?");
            $winners->execute([$correctOptionId]);
            $winners = $winners->fetchAll();

            $losers = $pdo->prepare("
                SELECT DISTINCT p.ID AS Prediction_ID, p.UID
                FROM PREDICTION p JOIN PREDICTION_OPTION po ON p.Option_ID = po.ID
                WHERE po.Chapter_ID = ? AND p.Option_ID != ?
            ");
            $losers->execute([$pollChapterId, $correctOptionId]);
            $losers = $losers->fetchAll();

            $coinInsert  = $pdo->prepare("INSERT INTO COIN_TRANSACTION (Amount, Time_stamp, UID) VALUES (1, NOW(), ?)");
            $predUpdate  = $pdo->prepare("UPDATE PREDICTION SET Coin_T_ID = ? WHERE ID = ?");
            $notifInsert = $pdo->prepare("INSERT INTO NOTIFICATION (Message, Type, UID) VALUES (?, ?, ?)");

            foreach ($winners as $w) {
                $coinInsert->execute([$w['UID']]);
                $predUpdate->execute([$pdo->lastInsertId(), $w['Prediction_ID']]);
                $notifInsert->execute([
                    "You predicted correctly for {$comicTitle} Chapter {$chapterNo}! The answer was: \"{$correctText}\". You earned 1 coin!",
                    'correct_prediction', $w['UID']
                ]);
            }

            foreach ($losers as $l) {
                $notifInsert->execute([
                    "Your prediction for {$comicTitle} Chapter {$chapterNo} was incorrect. The correct answer was: \"{$correctText}\". Better luck next time!",
                    'wrong_prediction', $l['UID']
                ]);
            }

            $pdo->prepare("UPDATE CHAPTER SET isPublished = TRUE WHERE CHAPTER_ID = ?")->execute([$chapterToPublish]);
            $pdo->commit();
            $message = 'Chapter published! ' . count($winners) . ' user(s) earned coins. ' . count($losers) . ' user(s) notified.';
        } catch (Exception $e) {
            $pdo->rollBack();
            $message = 'Error: ' . $e->getMessage(); $msgType = 'error';
        }
    }
}

// ============================================================
// POST: Delete prediction poll
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_poll') {
    $chapterId = intval($_POST['chapter_id'] ?? 0);
    if (!$chapterId) {
        $message = 'Invalid chapter.'; $msgType = 'error';
    } elseif (!artistOwnsChapter($pdo, $chapterId, $artistId)) {
        $message = 'You do not have permission to delete this poll.'; $msgType = 'error';
    } else {
        $pdo->prepare("DELETE FROM PREDICTION_OPTION WHERE Chapter_ID = ?")->execute([$chapterId]);
        $message = 'Poll deleted.';
    }
}

// ============================================================
// POST: Add special emoji — only for this artist's comics
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_emoji') {
    $emojiName  = trim($_POST['emoji_name']  ?? '');
    $emojiPath  = trim($_POST['emoji_path']  ?? '');
    $emojiCost  = intval($_POST['emoji_cost'] ?? 1);
    $emojiComic = intval($_POST['emoji_comic'] ?? 0);

    if (empty($emojiName) || empty($emojiPath) || !$emojiComic) {
        $message = 'All emoji fields are required.'; $msgType = 'error';
    } elseif (!preg_match('/^[a-zA-Z0-9_ \-]+$/', $emojiName)) {
        $message = 'Emoji name may only contain letters, numbers, spaces, hyphens, and underscores.'; $msgType = 'error';
    } elseif (mb_strlen($emojiName) > 50) {
        $message = 'Emoji name cannot be longer than 50 characters.'; $msgType = 'error';
    } elseif ($emojiCost < 1) {
        $message = 'Emoji cost must be at least 1 coin.'; $msgType = 'error';
    } elseif (!artistOwnsComic($pdo, $emojiComic, $artistId)) {
        $message = 'You do not have permission to add emojis to this comic.'; $msgType = 'error';
    } else {
        try {
            $pdo->prepare("INSERT INTO SPECIAL_EMOJI (Name, E_Value, Coin_Amount, Comic_ID) VALUES (?, ?, ?, ?)")
                ->execute([$emojiName, $emojiPath, $emojiCost, $emojiComic]);
            $message = "Emoji \"{$emojiName}\" added successfully.";
        } catch (PDOException $e) {
            $message = 'An emoji with that name already exists.'; $msgType = 'error';
        }
    }
}

// ============================================================
// POST: Delete special emoji — only for this artist's comics
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_emoji') {
    $emojiName = trim($_POST['emoji_name'] ?? '');
    if (!$emojiName) {
        $message = 'Invalid emoji.'; $msgType = 'error';
    } else {
        // Verify the emoji belongs to one of this artist's comics
        $ownerCheck = $pdo->prepare("
            SELECT 1 FROM SPECIAL_EMOJI se
            JOIN COMIC c ON se.Comic_ID = c.ID
            WHERE se.Name = ? AND c.AID = ?
        ");
        $ownerCheck->execute([$emojiName, $artistId]);
        if (!$ownerCheck->fetch()) {
            $message = 'You do not have permission to delete this emoji.'; $msgType = 'error';
        } else {
            $pdo->prepare("DELETE FROM SPECIAL_EMOJI WHERE Name = ?")->execute([$emojiName]);
            $message = "Emoji \"{$emojiName}\" deleted.";
        }
    }
}

// ============================================================
// FETCH DATA — scoped to this artist's comics only
// ============================================================

// This artist's comics only
$comics = $pdo->prepare("
    SELECT c.ID, c.Name, c.Title, c.IsCompleted,
           COUNT(ch.CHAPTER_ID) AS TotalChapters
    FROM COMIC c
    LEFT JOIN CHAPTER ch ON c.ID = ch.Comic_ID
    WHERE c.AID = ?
    GROUP BY c.ID
    ORDER BY c.ID DESC
");
$comics->execute([$artistId]);
$comics = $comics->fetchAll();

// Chapters & polls — this artist's comics only
$chaptersWithPolls = $pdo->prepare("
    SELECT ch.CHAPTER_ID, ch.ChapterNumber, ch.isPublished, ch.Comic_ID,
           c.Name AS ComicName, c.Title AS ComicTitle,
           COUNT(po.ID) AS OptionCount,
           SUM(po.IsResolved) AS ResolvedCount,
           SUM(CASE WHEN po.IsCorrect THEN 1 ELSE 0 END) AS HasCorrect
    FROM CHAPTER ch
    JOIN COMIC c ON ch.Comic_ID = c.ID
    LEFT JOIN PREDICTION_OPTION po ON ch.CHAPTER_ID = po.Chapter_ID
    WHERE c.AID = ?
    GROUP BY ch.CHAPTER_ID
    ORDER BY ch.Comic_ID ASC, ch.ChapterNumber ASC
");
$chaptersWithPolls->execute([$artistId]);
$chaptersWithPolls = $chaptersWithPolls->fetchAll();

// Unpublished chapters — this artist's comics only
$unpublishedChapters = $pdo->prepare("
    SELECT ch.CHAPTER_ID, ch.ChapterNumber, c.Name AS ComicName, c.Title AS ComicTitle
    FROM CHAPTER ch
    JOIN COMIC c ON ch.Comic_ID = c.ID
    WHERE ch.isPublished = FALSE AND c.AID = ?
    ORDER BY c.ID ASC, ch.ChapterNumber ASC
");
$unpublishedChapters->execute([$artistId]);
$unpublishedChapters = $unpublishedChapters->fetchAll();

// Emojis — this artist's comics only
$allEmojis = $pdo->prepare("
    SELECT se.Name, se.E_Value, se.Coin_Amount, se.Comic_ID,
           c.Title AS ComicTitle, c.Name AS ComicName,
           COUNT(ue.UID) AS OwnersCount
    FROM SPECIAL_EMOJI se
    JOIN COMIC c ON se.Comic_ID = c.ID
    LEFT JOIN USER_EMOJI ue ON se.Name = ue.Emoji_Name
    WHERE c.AID = ?
    GROUP BY se.Name
    ORDER BY se.Comic_ID ASC, se.Name ASC
");
$allEmojis->execute([$artistId]);
$allEmojis = $allEmojis->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Akatsuki</title>
    <style>
        :root {
            --bg-primary: #0f0f0f; --bg-secondary: #1a1a1a; --bg-card: #1e1e1e;
            --text-primary: #ffffff; --text-secondary: #a0a0a0; --text-muted: #666;
            --accent-primary: #e74c3c; --accent-secondary: #3498db;
            --border-color: #2a2a2a; --success: #27ae60; --warning: #f39c12;
            --radius-md: 8px; --radius-lg: 12px;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-primary); color: var(--text-primary); padding: 30px 20px; }
        .admin-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid var(--border-color); }
        .admin-header h1 { font-size: 1.6rem; }
        .admin-header a  { color: var(--accent-secondary); font-size: 0.9rem; }
        .container  { max-width: 1100px; margin: 0 auto; }
        .section    { background: var(--bg-card); border: 1px solid var(--border-color); border-radius: var(--radius-lg); padding: 25px; margin-bottom: 30px; }
        .section h2 { font-size: 1.1rem; margin-bottom: 20px; color: var(--accent-secondary); border-bottom: 1px solid var(--border-color); padding-bottom: 10px; }
        .alert          { padding: 12px 16px; border-radius: var(--radius-md); margin-bottom: 20px; font-size: 0.9rem; }
        .alert-success  { background: rgba(39,174,96,0.15); border: 1px solid var(--success); color: var(--success); }
        .alert-error    { background: rgba(231,76,60,0.15);  border: 1px solid var(--accent-primary); color: var(--accent-primary); }
        label           { display: block; font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 6px; }
        input[type="text"], input[type="number"], select, textarea {
            width: 100%; background: #111; color: #fff;
            border: 1px solid var(--border-color); border-radius: var(--radius-md);
            padding: 10px 12px; font-size: 0.9rem; margin-bottom: 14px;
        }
        input[type="text"]:focus, input[type="number"]:focus, select:focus { outline: none; border-color: var(--accent-secondary); }
        .btn           { display: inline-block; padding: 10px 20px; border-radius: var(--radius-md); border: none; cursor: pointer; font-size: 0.9rem; font-weight: 600; }
        .btn-primary   { background: var(--accent-primary);   color: #fff; }
        .btn-secondary { background: var(--accent-secondary); color: #fff; }
        .btn-success   { background: var(--success);          color: #fff; }
        .btn-danger    { background: transparent; color: var(--accent-primary); border: 1px solid var(--accent-primary); font-size: 0.8rem; padding: 5px 10px; }
        .btn:hover     { opacity: 0.85; }
        table          { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
        th             { text-align: left; padding: 10px; color: var(--text-muted); font-weight: 600; border-bottom: 1px solid var(--border-color); }
        td             { padding: 10px; border-bottom: 1px solid #1a1a1a; color: var(--text-secondary); }
        tr:hover td    { background: rgba(255,255,255,0.02); }
        .badge         { display: inline-block; padding: 2px 8px; border-radius: 20px; font-size: 0.75rem; font-weight: 600; }
        .badge-green   { background: rgba(39,174,96,0.2);  color: var(--success); }
        .badge-orange  { background: rgba(243,156,18,0.2); color: var(--warning); }
        .badge-red     { background: rgba(231,76,60,0.2);  color: var(--accent-primary); }
        .badge-gray    { background: rgba(255,255,255,0.05); color: var(--text-muted); }
        .form-row      { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .form-row-3    { display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 15px; }
        .options-grid  { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 16px; }
        .emoji-preview-sm { width: 32px; height: 32px; object-fit: contain; vertical-align: middle; border-radius: 4px; }
        .section-note  { color: var(--text-muted); font-size: 0.85rem; margin-bottom: 20px; line-height: 1.55; }
        .inline-form   { display: inline; }
        .no-comics-msg { color: var(--text-muted); font-size: 0.9rem; padding: 20px 0; }
    </style>
</head>
<body>
<div class="container">

    <div class="admin-header">
        <h1>🛠 Akatsuki Admin Panel</h1>
        <div>
            <span style="color: var(--text-muted); font-size: 0.85rem; margin-right: 15px;">
                Logged in as: <?php echo h($_SESSION['user_name'] ?? 'Artist'); ?>
            </span>
            <a href="index.php">← Back to Site</a>
        </div>
    </div>

    <?php if (empty($comics)): ?>
        <div class="section">
            <p class="no-comics-msg">⚠️ You have no comics registered under your account. Please contact a site administrator to have your comics linked to your artist profile.</p>
        </div>
    <?php else: ?>

    <?php if ($message): ?>
        <div class="alert alert-<?php echo $msgType; ?>"><?php echo h($message); ?></div>
    <?php endif; ?>

    <div class="section">
        <h2>📊 Create Prediction Poll</h2>
        <p class="section-note">
            Create a poll for the latest published chapter of your comics. Users predict what happens in the NEXT chapter.
            You must provide exactly 4 options.
        </p>
        <form method="POST" action="">
            <input type="hidden" name="action" value="create_poll">
            <label>Select Chapter to attach poll to:</label>
            <select name="chapter_id" required>
                <option value="">-- Select a published chapter --</option>
                <?php foreach ($chaptersWithPolls as $ch): ?>
                    <?php if ($ch['isPublished'] && $ch['OptionCount'] == 0): ?>
                        <option value="<?php echo $ch['CHAPTER_ID']; ?>">
                            <?php echo h($ch['ComicTitle'] ?: $ch['ComicName']); ?> — Chapter <?php echo $ch['ChapterNumber']; ?>
                        </option>
                    <?php endif; ?>
                <?php endforeach; ?>
            </select>
            <label>Poll Options (exactly 4 — phrase as predictions for the NEXT chapter):</label>
            <div class="options-grid">
                <?php for ($i = 1; $i <= 4; $i++): ?>
                    <div>
                        <label style="color: var(--accent-secondary);">Option <?php echo $i; ?></label>
                        <input type="text" name="options[]" placeholder="Option <?php echo $i; ?>" required>
                    </div>
                <?php endfor; ?>
            </div>
            <button type="submit" class="btn btn-primary">Create Poll</button>
        </form>
    </div>

    <div class="section">
        <h2>🚀 Publish New Chapter & Resolve Poll</h2>
        <p class="section-note">
            When you publish a new chapter, select which option was correct in the PREVIOUS chapter's poll.
            Coins will automatically be distributed to correct predictors and notifications sent to all.
        </p>
        <form method="POST" action="" id="publishForm">
            <input type="hidden" name="action" value="publish_and_resolve">
            <div class="form-row">
                <div>
                    <label>Chapter to Publish:</label>
                    <select name="chapter_to_publish" required>
                        <option value="">-- Select unpublished chapter --</option>
                        <?php foreach ($unpublishedChapters as $ch): ?>
                            <option value="<?php echo $ch['CHAPTER_ID']; ?>">
                                <?php echo h($ch['ComicTitle'] ?: $ch['ComicName']); ?> — Chapter <?php echo $ch['ChapterNumber']; ?>
                            </option>
                        <?php endforeach; ?>
                        <?php if (empty($unpublishedChapters)): ?>
                            <option disabled>No unpublished chapters</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div>
                    <label>Resolve Poll for Chapter (the chapter whose poll you are now answering):</label>
                    <select name="poll_chapter_id" id="pollChapterSelect" onchange="loadOptions(this.value)">
                        <option value="">-- No poll to resolve --</option>
                        <?php foreach ($chaptersWithPolls as $ch): ?>
                            <?php if ($ch['OptionCount'] > 0 && !$ch['ResolvedCount']): ?>
                                <option value="<?php echo $ch['CHAPTER_ID']; ?>">
                                    <?php echo h($ch['ComicTitle'] ?: $ch['ComicName']); ?> — Chapter <?php echo $ch['ChapterNumber']; ?>
                                </option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div id="optionsContainer" style="display:none; margin-bottom: 16px;">
                <label>Select the Correct Option:</label>
                <select name="correct_option_id" id="correctOptionSelect">
                    <option value="">-- Select the chapter first --</option>
                </select>
            </div>
            <button type="submit" class="btn btn-secondary"
                    onclick="return confirm('This will publish the chapter and permanently distribute coins. Continue?');">
                Publish Chapter & Distribute Coins
            </button>
        </form>
    </div>

    <div class="section">
        <h2>📋 Chapter & Poll Overview</h2>
        <table>
            <thead>
                <tr><th>Comic</th><th>Chapter</th><th>Published</th><th>Poll Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php foreach ($chaptersWithPolls as $ch): ?>
                    <tr>
                        <td><?php echo h($ch['ComicTitle'] ?: $ch['ComicName']); ?></td>
                        <td>Chapter <?php echo $ch['ChapterNumber']; ?></td>
                        <td>
                            <?php if ($ch['isPublished']): ?>
                                <span class="badge badge-green">Published</span>
                            <?php else: ?>
                                <span class="badge badge-gray">Draft</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($ch['OptionCount'] == 0): ?>
                                <span class="badge badge-gray">No poll</span>
                            <?php elseif ($ch['ResolvedCount'] > 0): ?>
                                <span class="badge badge-green">Resolved ✓</span>
                            <?php else: ?>
                                <span class="badge badge-orange">Open (<?php echo $ch['OptionCount']; ?> options)</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($ch['OptionCount'] > 0 && !$ch['ResolvedCount']): ?>
                                <form method="POST" class="inline-form"
                                      onsubmit="return confirm('Delete poll and all predictions for this chapter?');">
                                    <input type="hidden" name="action"     value="delete_poll">
                                    <input type="hidden" name="chapter_id" value="<?php echo $ch['CHAPTER_ID']; ?>">
                                    <button type="submit" class="btn btn-danger">Delete Poll</button>
                                </form>
                            <?php else: ?>
                                <span style="color: var(--text-muted); font-size: 0.8rem;">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="section">
        <h2>🎭 Emoji Store Management</h2>
        <p class="section-note">
            Add or remove special emojis for your comics. The <strong>emoji name</strong> can contain
            letters, numbers, spaces, hyphens, and underscores (max 50 characters).
            The <strong>file path</strong> should be the server-relative path to the .webp file,
            e.g. <code>assets/emojis/anya-heh.webp</code>. Upload the file to the server first.
        </p>

        <form method="POST" action="" style="margin-bottom: 28px; padding-bottom: 24px; border-bottom: 1px solid var(--border-color);">
            <input type="hidden" name="action" value="add_emoji">
            <h3 style="font-size: 0.95rem; color: var(--text-secondary); margin-bottom: 16px;">➕ Add New Emoji</h3>
            <div class="form-row-3">
                <div>
                    <label>Comic:</label>
                    <select name="emoji_comic" required>
                        <option value="">-- Select comic --</option>
                        <?php foreach ($comics as $c): ?>
                            <option value="<?php echo $c['ID']; ?>">
                                <?php echo h($c['Title'] ?: $c['Name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label>Emoji Name (max 50 chars, letters/numbers/spaces/hyphens/underscores):</label>
                    <input type="text" name="emoji_name"
                           placeholder="e.g. Anya Heh"
                           maxlength="50"
                           pattern="[a-zA-Z0-9_ \-]+"
                           title="Letters, numbers, spaces, hyphens, underscores only. Max 50 characters."
                           required>
                </div>
                <div>
                    <label>Coin Cost:</label>
                    <input type="number" name="emoji_cost" min="1" max="100" value="1" required>
                </div>
            </div>
            <div>
                <label>WebP File Path (relative to site root):</label>
                <input type="text" name="emoji_path" placeholder="assets/emojis/anya-heh.webp" required>
            </div>
            <button type="submit" class="btn btn-success">Add Emoji</button>
        </form>

        <?php if (empty($allEmojis)): ?>
            <p style="color: var(--text-muted); font-size: 0.9rem;">No emojis in the store yet for your comics. Add some above.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr><th>Preview</th><th>Name</th><th>Comic</th><th>Cost</th><th>Owners</th><th>File Path</th><th>Delete</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($allEmojis as $em): ?>
                        <tr>
                            <td>
                                <img src="<?php echo h($em['E_Value']); ?>"
                                     alt="<?php echo h($em['Name']); ?>"
                                     class="emoji-preview-sm"
                                     onerror="this.style.opacity='0.2';">
                            </td>
                            <td style="font-family: monospace; color: var(--text-primary);">
                                <?php echo h($em['Name']); ?>
                            </td>
                            <td><?php echo h($em['ComicTitle'] ?: $em['ComicName']); ?></td>
                            <td style="color: var(--warning);">🪙 <?php echo $em['Coin_Amount']; ?></td>
                            <td><?php echo $em['OwnersCount']; ?> user(s)</td>
                            <td style="font-size: 0.78rem; color: var(--text-muted); font-family: monospace;">
                                <?php echo h($em['E_Value']); ?>
                            </td>
                            <td>
                                <?php if ($em['OwnersCount'] == 0): ?>
                                    <form method="POST" class="inline-form"
                                          onsubmit="return confirm('Permanently delete emoji \"<?php echo h($em['Name']); ?>\"?');">
                                        <input type="hidden" name="action"     value="delete_emoji">
                                        <input type="hidden" name="emoji_name" value="<?php echo h($em['Name']); ?>">
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                <?php else: ?>
                                    <span class="badge badge-gray" title="Cannot delete — users own this emoji">Owned</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <?php endif; // end: artist has comics ?>

</div><script>
function loadOptions(chapterId) {
    const container = document.getElementById('optionsContainer');
    const select    = document.getElementById('correctOptionSelect');
    if (!chapterId) { container.style.display = 'none'; return; }

    fetch(`get_poll_options.php?chapter_id=${chapterId}`)
        .then(r => r.json())
        .then(options => {
            select.innerHTML = '<option value="">-- Select the correct option --</option>';
            options.forEach(opt => {
                const o = document.createElement('option');
                o.value       = opt.ID;
                o.textContent = `Option ${opt.Option_Number}: ${opt.OptionText}`;
                select.appendChild(o);
            });
            container.style.display = 'block';
        })
        .catch(() => { container.style.display = 'none'; });
}
</script>
</body>
</html>