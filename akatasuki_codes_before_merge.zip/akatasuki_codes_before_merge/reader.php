<?php
require_once 'db.php';

// Get chapter ID from URL
$chapterId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$chapterId) {
    header('Location: index.php');
    exit;
}

// Fetch chapter information
$stmt = $pdo->prepare("
    SELECT 
        ch.CHAPTER_ID,
        ch.ChapterNumber,
        ch.Date_of_Publication,
        ch.ContentURL,
        ch.Comic_ID,
        c.Name as ComicName,
        c.Title as ComicTitle
    FROM CHAPTER ch
    JOIN COMIC c ON ch.Comic_ID = c.ID
    WHERE ch.CHAPTER_ID = ? AND ch.isPublished = TRUE
");
$stmt->execute([$chapterId]);
$chapter = $stmt->fetch();

if (!$chapter) {
    header('Location: index.php');
    exit;
}

$pageTitle = ($chapter['ComicTitle'] ?: $chapter['ComicName']) . ' - Chapter ' . $chapter['ChapterNumber'];

// Fetch all chapters for navigation
$stmt = $pdo->prepare("
    SELECT CHAPTER_ID, ChapterNumber 
    FROM CHAPTER 
    WHERE Comic_ID = ? AND isPublished = TRUE
    ORDER BY ChapterNumber ASC
");
$stmt->execute([$chapter['Comic_ID']]);
$allChapters = $stmt->fetchAll();

// Find previous and next chapters
$prevChapter = null;
$nextChapter = null;
foreach ($allChapters as $index => $ch) {
    if ($ch['CHAPTER_ID'] == $chapterId) {
        if ($index > 0) {
            $prevChapter = $allChapters[$index - 1];
        }
        if ($index < count($allChapters) - 1) {
            $nextChapter = $allChapters[$index + 1];
        }
        break;
    }
}

// Get chapter images from ContentURL folder
$images = [];
$contentPath = $chapter['ContentURL'] ?? '';

// Normalize path - ContentURL should contain folder path like "assets/chapters/solo-leveling/chapter-1"
if (!empty($contentPath) && is_dir($contentPath)) {
    $files = scandir($contentPath);
    foreach ($files as $file) {
        if (preg_match('/\.(webp|jpg|jpeg|png|gif)$/i', $file)) {
            $images[] = $contentPath . '/' . $file;
        }
    }
    // Sort images numerically
    usort($images, function($a, $b) {
        preg_match('/(\d+)/', basename($a), $matchA);
        preg_match('/(\d+)/', basename($b), $matchB);
        return (intval($matchA[1] ?? 0)) - (intval($matchB[1] ?? 0));
    });
}

require_once 'header.php';
?>

<div class="reader-container">
    <div class="reader-header">
        <div class="reader-info">
            <h1><?php echo h($chapter['ComicTitle'] ?: $chapter['ComicName']); ?></h1>
            <span>Chapter <?php echo $chapter['ChapterNumber']; ?></span>
        </div>
        
        <div class="reader-nav">
            <?php if ($prevChapter): ?>
                <a href="reader.php?id=<?php echo $prevChapter['CHAPTER_ID']; ?>" class="btn btn-outline">
                    ← Previous
                </a>
            <?php else: ?>
                <span class="btn btn-outline" style="opacity: 0.5; cursor: not-allowed;">← Previous</span>
            <?php endif; ?>
            
            <select class="chapter-select" onchange="window.location.href='reader.php?id='+this.value">
                <?php foreach ($allChapters as $ch): ?>
                    <option value="<?php echo $ch['CHAPTER_ID']; ?>" <?php echo $ch['CHAPTER_ID'] == $chapterId ? 'selected' : ''; ?>>
                        Chapter <?php echo $ch['ChapterNumber']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
            
            <?php if ($nextChapter): ?>
                <a href="reader.php?id=<?php echo $nextChapter['CHAPTER_ID']; ?>" class="btn btn-outline">
                    Next →
                </a>
            <?php else: ?>
                <span class="btn btn-outline" style="opacity: 0.5; cursor: not-allowed;">Next →</span>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="reader-images">
        <?php if (!empty($images)): ?>
            <?php foreach ($images as $image): ?>
                <img src="<?php echo h($image); ?>" 
                     alt="Page" 
                     loading="lazy">
            <?php endforeach; ?>
        <?php else: ?>
            <div style="padding: 100px 20px; text-align: center;">
                <h2 style="color: var(--text-secondary); margin-bottom: 20px;">Chapter content not available</h2>
                <p style="color: var(--text-muted);">
                    The chapter images for this content have not been uploaded yet.<br>
                    Expected path: <code><?php echo h($contentPath ?: 'assets/chapters/[comic-folder]/chapter-' . $chapter['ChapterNumber']); ?></code>
                </p>
                <p style="color: var(--text-muted); margin-top: 20px;">
                    Please ensure the ContentURL in the CHAPTER table points to a valid folder containing WebP images.
                </p>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="reader-header" style="margin-top: 20px;">
        <div></div>
        <div class="reader-nav">
            <?php if ($prevChapter): ?>
                <a href="reader.php?id=<?php echo $prevChapter['CHAPTER_ID']; ?>" class="btn btn-outline">
                    ← Previous
                </a>
            <?php else: ?>
                <span class="btn btn-outline" style="opacity: 0.5; cursor: not-allowed;">← Previous</span>
            <?php endif; ?>
            
            <a href="comic.php?id=<?php echo $chapter['Comic_ID']; ?>" class="btn btn-primary">
                Back to Comic
            </a>
            
            <?php if ($nextChapter): ?>
                <a href="reader.php?id=<?php echo $nextChapter['CHAPTER_ID']; ?>" class="btn btn-outline">
                    Next →
                </a>
            <?php else: ?>
                <span class="btn btn-outline" style="opacity: 0.5; cursor: not-allowed;">Next →</span>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
