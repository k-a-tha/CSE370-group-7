<?php
$pageTitle = 'Artist Registration';
require_once 'header.php';

$error = '';
$success = '';

// Redirect if already logged in
if (isArtistLoggedIn()) {
    header('Location: index.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $gender = $_POST['gender'] ?? '';
    
    // Validation
    if (empty($name) || empty($email) || empty($password)) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } elseif ($password !== $confirmPassword) {
        $error = 'Passwords do not match.';
    } else {
        // Check if email already exists
        $stmt = $pdo->prepare("SELECT ID FROM ARTIST WHERE Email = ?");
        $stmt->execute([$email]);
        
        if ($stmt->fetch()) {
            $error = 'An account with this email already exists.';
        } else {
            // Hash password and create artist
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt = $pdo->prepare("
                INSERT INTO ARTIST (Email, Name, Gender, PasswordHash) 
                VALUES (?, ?, ?, ?)
            ");
            
            try {
                $stmt->execute([$email, $name, $gender, $passwordHash]);
                $success = 'Artist account created successfully! You can now sign in.';
            } catch (PDOException $e) {
                $error = 'An error occurred. Please try again.';
            }
        }
    }
}
?>

<div class="auth-container">
    <div class="auth-tabs">
        <a href="register_user.php" class="auth-tab">User Sign Up</a>
        <a href="register_artist.php" class="auth-tab active">Artist Sign Up</a>
    </div>
    
    <div class="auth-header">
        <h1>Become an Artist</h1>
        <p>Share your manga with the world</p>
    </div>
    
    <?php if ($error): ?>
        <div class="alert alert-error"><?php echo h($error); ?></div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo h($success); ?></div>
    <?php endif; ?>
    
    <form method="POST" action="">
        <div class="form-group">
            <label for="name">Artist Name / Pen Name *</label>
            <input type="text" 
                   id="name" 
                   name="name" 
                   class="form-control" 
                   placeholder="Enter your artist name"
                   value="<?php echo h($_POST['name'] ?? ''); ?>"
                   required>
        </div>
        
        <div class="form-group">
            <label for="email">Email Address *</label>
            <input type="email" 
                   id="email" 
                   name="email" 
                   class="form-control" 
                   placeholder="Enter your email"
                   value="<?php echo h($_POST['email'] ?? ''); ?>"
                   required>
        </div>
        
        <div class="form-group">
            <label for="gender">Gender</label>
            <select id="gender" name="gender" class="form-control">
                <option value="">Select gender (optional)</option>
                <option value="Male" <?php echo (($_POST['gender'] ?? '') === 'Male') ? 'selected' : ''; ?>>Male</option>
                <option value="Female" <?php echo (($_POST['gender'] ?? '') === 'Female') ? 'selected' : ''; ?>>Female</option>
                <option value="Other" <?php echo (($_POST['gender'] ?? '') === 'Other') ? 'selected' : ''; ?>>Other</option>
            </select>
        </div>
        
        <div class="form-group">
            <label for="password">Password *</label>
            <input type="password" 
                   id="password" 
                   name="password" 
                   class="form-control" 
                   placeholder="Create a password (min 6 characters)"
                   required>
        </div>
        
        <div class="form-group">
            <label for="confirm_password">Confirm Password *</label>
            <input type="password" 
                   id="confirm_password" 
                   name="confirm_password" 
                   class="form-control" 
                   placeholder="Confirm your password"
                   required>
        </div>
        
        <button type="submit" class="btn btn-secondary btn-full">Create Artist Account</button>
    </form>
    
    <div class="auth-footer">
        <p>Already have an account? <a href="login_artist.php">Sign in</a></p>
    </div>
</div>

<?php require_once 'footer.php'; ?>
