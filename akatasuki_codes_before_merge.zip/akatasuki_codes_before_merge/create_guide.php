<?php
// create_guide.php  —  Only the artist who owns the comic can create / edit its guide.
require_once 'db.php';

if (!isArtistLoggedIn()) {
    header('Location: login_user.php');
    exit;
}

$artistId = (int)$_SESSION['user_id'];
$comicId  = isset($_GET['comic_id']) ? (int)$_GET['comic_id'] : 0;

if (!$comicId) {
    header('Location: index.php');
    exit;
}

// ── Verify ownership ──────────────────────────────────
$stmt = $pdo->prepare("SELECT ID, Name, Title, PDF FROM COMIC WHERE ID = ? AND AID = ?");
$stmt->execute([$comicId, $artistId]);
$comic = $stmt->fetch();

if (!$comic) {
    header('Location: index.php');  // not their comic
    exit;
}

$comicLabel  = $comic['Title'] ?: $comic['Name'];
$guideFile   = "assets/guides/comic-{$comicId}.html";
$guideExists = !empty($comic['PDF']) && file_exists($guideFile);

// ── Load existing guide data for editing ──────────────
$existing = [
    'guide_title'  => '',
    'overview'     => '',
    'sections'     => [['heading' => '', 'body' => '']],
    'tips'         => '',
    'final_notes'  => '',
];

if ($guideExists) {
    $raw = file_get_contents($guideFile);

    // Pull structured data back out of the saved HTML via data-* attributes on a
    // hidden <script type="application/json"> block we embed when saving.
    if (preg_match('/<script type="application\/json" id="guide-data">(.*?)<\/script>/s', $raw, $m)) {
        $decoded = json_decode(html_entity_decode($m[1]), true);
        if ($decoded) $existing = $decoded;
    }
}

// ── Handle save ───────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['_action'] ?? '') === 'save_guide') {

    $data = [
        'guide_title' => trim($_POST['guide_title'] ?? ''),
        'overview'    => trim($_POST['overview']    ?? ''),
        'tips'        => trim($_POST['tips']        ?? ''),
        'final_notes' => trim($_POST['final_notes'] ?? ''),
        'sections'    => [],
    ];

    $headings = $_POST['sec_heading'] ?? [];
    $bodies   = $_POST['sec_body']    ?? [];
    foreach ($headings as $i => $h) {
        $h = trim($h);
        $b = trim($bodies[$i] ?? '');
        if ($h || $b) {
            $data['sections'][] = ['heading' => $h, 'body' => $b];
        }
    }
    if (empty($data['sections'])) {
        $data['sections'] = [['heading' => '', 'body' => '']];
    }

    // ── Build the HTML file ───────────────────────────
    $sectionsHtml = '';
    foreach ($data['sections'] as $s) {
        if ($s['heading'] || $s['body']) {
            $sectionsHtml .= '<div class="gv-section">';
            if ($s['heading']) {
                $sectionsHtml .= '<h2 class="gv-sec-heading">' . htmlspecialchars($s['heading']) . '</h2>';
            }
            if ($s['body']) {
                $sectionsHtml .= '<div class="gv-sec-body">' . nl2br(htmlspecialchars($s['body'])) . '</div>';
            }
            $sectionsHtml .= '</div>';
        }
    }

    $tipsHtml = '';
    if ($data['tips']) {
        $items = array_filter(array_map('trim', explode("\n", $data['tips'])));
        $tipsHtml = '<ul class="gv-tips-list">';
        foreach ($items as $item) {
            $tipsHtml .= '<li>' . htmlspecialchars($item) . '</li>';
        }
        $tipsHtml .= '</ul>';
    }

    $jsonBlob = htmlspecialchars(json_encode($data, JSON_UNESCAPED_UNICODE), ENT_QUOTES);

    $html = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{$data['guide_title']} — Guide</title>
</head>
<body>
<!-- Structured data for editing — do not remove -->
<script type="application/json" id="guide-data">{$jsonBlob}</script>
<!-- Content start -->
<div data-guide="true">
    <h1 class="gv-main-title">{$data['guide_title']}</h1>
HTML;

    if ($data['overview']) {
        $html .= '<div class="gv-overview">' . nl2br(htmlspecialchars($data['overview'])) . '</div>';
    }

    $html .= $sectionsHtml;

    if ($tipsHtml) {
        $html .= '<div class="gv-tips-block"><h2 class="gv-sec-heading">💡 Tips &amp; Tricks</h2>' . $tipsHtml . '</div>';
    }

    if ($data['final_notes']) {
        $html .= '<div class="gv-final"><h2 class="gv-sec-heading">📝 Final Notes</h2>'
               . '<div class="gv-sec-body">' . nl2br(htmlspecialchars($data['final_notes'])) . '</div>'
               . '</div>';
    }

    $html .= '</div></body></html>';

    // ── Write file ────────────────────────────────────
    if (!is_dir('assets/guides')) {
        mkdir('assets/guides', 0755, true);
    }
    file_put_contents($guideFile, $html);

    // ── Update COMIC.PDF ──────────────────────────────
    $pdo->prepare("UPDATE COMIC SET PDF = ? WHERE ID = ? AND AID = ?")
        ->execute([$guideFile, $comicId, $artistId]);

    header("Location: create_guide.php?comic_id={$comicId}&saved=1");
    exit;
}

// ── Delete guide ──────────────────────────────────────
if (isset($_GET['delete'])) {
    if ($guideExists) {
        @unlink($guideFile);
    }
    $pdo->prepare("UPDATE COMIC SET PDF = NULL WHERE ID = ? AND AID = ?")
        ->execute([$comicId, $artistId]);
    header("Location: create_guide.php?comic_id={$comicId}&deleted=1");
    exit;
}

$pageTitle = 'Create Guide — ' . $comicLabel;
require_once 'header.php';
?>

<style>
/* ── Layout ──────────────────────────────────────────── */
.cg-wrap      { max-width: 860px; margin: 0 auto; }
.cg-back      { display: inline-flex; align-items: center; gap: 8px; color: var(--text-muted);
                font-size: 0.88rem; margin-bottom: 20px; text-decoration: none; transition: color .2s; }
.cg-back:hover { color: var(--text-primary); }

.cg-heading   { font-size: 1.7rem; color: var(--text-primary); margin-bottom: 6px;
                display: flex; align-items: center; gap: 12px; }
.cg-sub       { color: var(--text-muted); font-size: 0.88rem; margin-bottom: 28px; }

/* ── Cards ───────────────────────────────────────────── */
.cg-card      { background: var(--bg-card); border: 1px solid var(--border-color);
                border-radius: var(--radius-lg); padding: 28px; margin-bottom: 22px; }
.cg-card h3   { font-size: 1rem; color: var(--text-primary); margin-bottom: 20px;
                padding-bottom: 12px; border-bottom: 1px solid var(--border-color); }

/* ── Fields ──────────────────────────────────────────── */
.fg           { margin-bottom: 16px; }
.fg label     { display: block; font-size: 0.82rem; font-weight: 600;
                color: var(--text-secondary); margin-bottom: 6px; }
.fg input, .fg textarea {
    width: 100%; padding: 10px 14px; background: var(--bg-secondary);
    border: 1px solid var(--border-color); border-radius: var(--radius-md);
    color: var(--text-primary); font-size: 0.9rem; font-family: inherit;
    transition: border-color .2s; box-sizing: border-box; }
.fg input:focus, .fg textarea:focus { outline: none; border-color: var(--accent-color, #818cf8); }
.fg small     { font-size: 0.75rem; color: var(--text-muted); margin-top: 4px; display: block; }
textarea      { resize: vertical; }

/* ── Dynamic sections ────────────────────────────────── */
.section-block  { background: var(--bg-secondary); border: 1px solid var(--border-color);
                  border-radius: var(--radius-md); padding: 18px; margin-bottom: 14px;
                  position: relative; }
.section-num    { font-size: 0.75rem; font-weight: 700; color: var(--text-muted);
                  text-transform: uppercase; letter-spacing: .05em; margin-bottom: 12px; }
.btn-rm-section { position: absolute; top: 12px; right: 14px; background: none; border: none;
                  color: var(--text-muted); cursor: pointer; font-size: 1rem;
                  transition: color .2s; padding: 0; }
.btn-rm-section:hover { color: #f87171; }

/* ── Buttons ─────────────────────────────────────────── */
.btn-add-section { width: 100%; padding: 10px; background: transparent;
                   border: 2px dashed var(--border-color); border-radius: var(--radius-md);
                   color: var(--text-muted); cursor: pointer; font-size: 0.88rem;
                   font-family: inherit; transition: all .2s; margin-bottom: 8px; }
.btn-add-section:hover { border-color: var(--accent-color, #818cf8); color: var(--accent-color, #818cf8); }

.btn-save     { width: 100%; padding: 13px; background: var(--accent-color, #818cf8); color: #fff;
                border: none; border-radius: var(--radius-md); font-size: 1rem; font-weight: 700;
                cursor: pointer; font-family: inherit; transition: opacity .2s; }
.btn-save:hover { opacity: .85; }

/* ── Toasts ──────────────────────────────────────────── */
.toast       { border-radius: var(--radius-md); padding: 12px 18px;
               margin-bottom: 22px; font-size: 0.88rem; font-weight: 500; }
.t-ok        { background: rgba(34,197,94,.12); border: 1px solid rgba(34,197,94,.3); color: #4ade80; }
.t-del       { background: rgba(239,68,68,.12); border: 1px solid rgba(239,68,68,.3); color: #f87171; }

/* ── Preview banner ──────────────────────────────────── */
.cg-preview-bar { display: flex; align-items: center; justify-content: space-between;
                  background: rgba(129,140,248,.08); border: 1px solid rgba(129,140,248,.25);
                  border-radius: var(--radius-md); padding: 12px 18px; margin-bottom: 22px; }
.cg-preview-bar span { font-size: 0.88rem; color: var(--text-secondary); }
.cg-preview-bar a    { font-size: 0.85rem; color: var(--accent-color, #818cf8); font-weight: 600;
                       text-decoration: none; }
.cg-preview-bar a:hover { text-decoration: underline; }

.btn-del-guide { background: none; border: 1px solid rgba(239,68,68,.4); color: #f87171;
                 padding: 5px 14px; border-radius: var(--radius-sm); font-size: 0.8rem;
                 cursor: pointer; font-family: inherit; transition: all .2s; }
.btn-del-guide:hover { background: rgba(239,68,68,.12); }
</style>

<div class="cg-wrap">

    <a href="comic.php?id=<?php echo $comicId; ?>" class="cg-back">← Back to Comic</a>

    <div class="cg-heading">📖 <?php echo $guideExists ? 'Edit' : 'Create'; ?> Guide</div>
    <p class="cg-sub">
        Writing guide for <strong><?php echo h($comicLabel); ?></strong> —
        only you (the artist) can edit this. Readers will see it as a formatted page.
    </p>

    <?php if (isset($_GET['saved'])): ?>
        <div class="toast t-ok">✓ Guide saved! Readers can now view it on the comic page.</div>
    <?php endif; ?>

    <?php if (isset($_GET['deleted'])): ?>
        <div class="toast t-del">Guide deleted.</div>
    <?php endif; ?>

    <?php if ($guideExists): ?>
        <div class="cg-preview-bar">
            <span>📄 A guide is live for this comic.</span>
            <div style="display:flex;gap:12px;align-items:center;">
                <a href="view_guide.php?comic_id=<?php echo $comicId; ?>" target="_blank">👁 Preview</a>
                <button class="btn-del-guide"
                        onclick="if(confirm('Delete this guide permanently?'))
                                 window.location='create_guide.php?comic_id=<?php echo $comicId; ?>&delete=1'">
                    🗑 Delete Guide
                </button>
            </div>
        </div>
    <?php endif; ?>

    <form method="POST" action="create_guide.php?comic_id=<?php echo $comicId; ?>" id="guideForm">
        <input type="hidden" name="_action" value="save_guide">

        <!-- ── Guide Title ──────────────────────────── -->
        <div class="cg-card">
            <h3>Guide Title & Overview</h3>
            <div class="fg">
                <label>Guide Title</label>
                <input type="text" name="guide_title"
                       placeholder="e.g. Reading Guide for <?php echo h($comicLabel); ?>"
                       value="<?php echo h($existing['guide_title']); ?>" required>
                <small>This is the big heading readers see at the top.</small>
            </div>
            <div class="fg">
                <label>Overview / Introduction</label>
                <textarea name="overview" rows="4"
                          placeholder="Briefly introduce what this comic is about and what readers can expect…"><?php echo h($existing['overview']); ?></textarea>
            </div>
        </div>

        <!-- ── Dynamic Sections ─────────────────────── -->
        <div class="cg-card">
            <h3>📚 Content Sections</h3>
            <p style="color:var(--text-muted);font-size:0.85rem;margin-bottom:18px;">
                Add as many sections as you like — reading order tips, world-building notes,
                character introductions, chapter breakdowns, anything!
            </p>

            <div id="sections-container">
                <?php foreach ($existing['sections'] as $i => $sec): ?>
                <div class="section-block" data-index="<?php echo $i; ?>">
                    <div class="section-num">Section <?php echo $i + 1; ?></div>
                    <?php if (count($existing['sections']) > 1): ?>
                        <button type="button" class="btn-rm-section" onclick="removeSection(this)" title="Remove section">✕</button>
                    <?php endif; ?>
                    <div class="fg">
                        <label>Section Heading</label>
                        <input type="text" name="sec_heading[]"
                               placeholder="e.g. Where to Start, Power System Explained…"
                               value="<?php echo h($sec['heading']); ?>">
                    </div>
                    <div class="fg" style="margin-bottom:0;">
                        <label>Content</label>
                        <textarea name="sec_body[]" rows="5"
                                  placeholder="Write the section content here…"><?php echo h($sec['body']); ?></textarea>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <button type="button" class="btn-add-section" onclick="addSection()">
                + Add Another Section
            </button>
        </div>

        <!-- ── Tips ─────────────────────────────────── -->
        <div class="cg-card">
            <h3>💡 Tips & Tricks</h3>
            <div class="fg">
                <label>Tips (one per line)</label>
                <textarea name="tips" rows="5"
                          placeholder="Pay attention to the background details&#10;Read the author's notes at the end of each chapter&#10;The power system is explained in Chapter 3"><?php echo h($existing['tips']); ?></textarea>
                <small>Each line becomes a bullet point in the guide.</small>
            </div>
        </div>

        <!-- ── Final Notes ───────────────────────────── -->
        <div class="cg-card">
            <h3>📝 Final Notes</h3>
            <div class="fg">
                <label>Closing message to readers</label>
                <textarea name="final_notes" rows="4"
                          placeholder="Thank readers, share your socials, mention upcoming chapters…"><?php echo h($existing['final_notes']); ?></textarea>
            </div>
        </div>

        <button type="submit" class="btn-save">💾 Save Guide</button>

    </form>
</div>

<script>
let sectionCount = <?php echo count($existing['sections']); ?>;

function renumberSections() {
    document.querySelectorAll('.section-block').forEach((block, i) => {
        block.querySelector('.section-num').textContent = 'Section ' + (i + 1);
    });
    // Show/hide remove buttons — always allow remove if more than 1
    const blocks = document.querySelectorAll('.section-block');
    blocks.forEach(block => {
        const rm = block.querySelector('.btn-rm-section');
        if (blocks.length > 1) {
            if (!rm) {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'btn-rm-section';
                btn.title = 'Remove section';
                btn.textContent = '✕';
                btn.onclick = function() { removeSection(this); };
                block.appendChild(btn);
            }
        } else {
            if (rm) rm.remove();
        }
    });
}

function addSection() {
    sectionCount++;
    const container = document.getElementById('sections-container');
    const div = document.createElement('div');
    div.className = 'section-block';
    div.dataset.index = sectionCount;
    div.innerHTML = `
        <div class="section-num">Section ${container.children.length + 1}</div>
        <button type="button" class="btn-rm-section" onclick="removeSection(this)" title="Remove section">✕</button>
        <div class="fg">
            <label>Section Heading</label>
            <input type="text" name="sec_heading[]" placeholder="e.g. Where to Start, Power System Explained…">
        </div>
        <div class="fg" style="margin-bottom:0;">
            <label>Content</label>
            <textarea name="sec_body[]" rows="5" placeholder="Write the section content here…"></textarea>
        </div>
    `;
    container.appendChild(div);
    renumberSections();
    div.querySelector('input').focus();
}

function removeSection(btn) {
    btn.closest('.section-block').remove();
    renumberSections();
}
</script>

<?php require_once 'footer.php'; ?>
