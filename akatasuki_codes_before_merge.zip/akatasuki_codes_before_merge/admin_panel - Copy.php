<?php
// admin_panel.php  (updated)
// Protected admin page - requires artist login
// New sections: Grant Coins to Users | Emoji Store Management

if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'db.php';

$isArtist = isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'artist';
if (!$isArtist) { header('Location: login_artist.php'); exit; }

$artistId = intval($_SESSION['user_id'] ?? 0);
$message  = '';
$msgType  = 'success';

// ============================================================
// POST: Create prediction poll
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create_poll') {
    $chapterId = intval($_POST['chapter_id'] ?? 0);
    $options   = array_filter(array_map('trim', $_POST['options'] ?? []), fn($o) => $o !== '');

    if (!$chapterId) {
        $message = 'Invalid chapter selected.'; $msgType = 'error';
    } elseif (count($options) !== 4) {
        $message = 'You must provide exactly 4 options.'; $msgType = 'error';
    } else {
        $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM PREDICTION_OPTION WHERE Chapter_ID = ?");
        $checkStmt->execute([$chapterId]);
        if ($checkStmt->fetchColumn() > 0) {
            $message = 'A poll already exists for this chapter. Delete it first.'; $msgType = 'error';
        } else {
            $insertStmt = $pdo->prepare("INSERT INTO PREDICTION_OPTION (Option_Number, OptionText, Chapter_ID) VALUES (?, ?, ?)");
            foreach (array_values($options) as $i => $text) {
                $insertStmt->execute([$i + 1, $text, $chapterId]);
            }
            $message = 'Prediction poll created successfully!';
        }
    }
}

// ============================================================
// POST: Publish chapter + resolve previous poll + distribute coins
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'publish_and_resolve') {
    $chapterToPublish = intval($_POST['chapter_to_publish'] ?? 0);
    $correctOptionId  = intval($_POST['correct_option_id']  ?? 0);
    $pollChapterId    = intval($_POST['poll_chapter_id']    ?? 0);

    if (!$chapterToPublish) {
        $message = 'Please select a chapter to publish.'; $msgType = 'error';
    } elseif (!$correctOptionId || !$pollChapterId) {
        $pdo->prepare("UPDATE CHAPTER SET isPublished = TRUE WHERE CHAPTER_ID = ?")->execute([$chapterToPublish]);
        $message = 'Chapter published (no poll to resolve).';
    } else {
        try {
            $pdo->beginTransaction();

            $pollInfo = $pdo->prepare("
                SELECT po.OptionText, ch.ChapterNumber, c.Name AS ComicName, c.Title AS ComicTitle
                FROM PREDICTION_OPTION po
                JOIN CHAPTER ch ON po.Chapter_ID = ch.CHAPTER_ID
                JOIN COMIC   c  ON ch.Comic_ID   = c.ID
                WHERE po.ID = ?
            ");
            $pollInfo->execute([$correctOptionId]);
            $poll = $pollInfo->fetch();
            $comicTitle  = $poll ? ($poll['ComicTitle'] ?: $poll['ComicName']) : 'the comic';
            $chapterNo   = $poll['ChapterNumber'] ?? '?';
            $correctText = $poll['OptionText'] ?? 'the correct option';

            $pdo->prepare("UPDATE PREDICTION_OPTION SET IsResolved = TRUE, IsCorrect = (ID = ?) WHERE Chapter_ID = ?")
                ->execute([$correctOptionId, $pollChapterId]);

            $winners = $pdo->prepare("SELECT p.ID AS Prediction_ID, p.UID FROM PREDICTION p WHERE p.Option_ID = ?");
            $winners->execute([$correctOptionId]);
            $winners = $winners->fetchAll();

            $losers = $pdo->prepare("
                SELECT DISTINCT p.ID AS Prediction_ID, p.UID
                FROM PREDICTION p JOIN PREDICTION_OPTION po ON p.Option_ID = po.ID
                WHERE po.Chapter_ID = ? AND p.Option_ID != ?
            ");
            $losers->execute([$pollChapterId, $correctOptionId]);
            $losers = $losers->fetchAll();

            $coinInsert  = $pdo->prepare("INSERT INTO COIN_TRANSACTION (Amount, Time_stamp, UID) VALUES (1, NOW(), ?)");
            $predUpdate  = $pdo->prepare("UPDATE PREDICTION SET Coin_T_ID = ? WHERE ID = ?");
            $notifInsert = $pdo->prepare("INSERT INTO NOTIFICATION (Message, Type, UID) VALUES (?, ?, ?)");

            foreach ($winners as $w) {
                $coinInsert->execute([$w['UID']]);
                $predUpdate->execute([$pdo->lastInsertId(), $w['Prediction_ID']]);
                $notifInsert->execute([
                    "You predicted correctly for {$comicTitle} Chapter {$chapterNo}! The answer was: \"{$correctText}\". You earned 1 coin!",
                    'correct_prediction', $w['UID']
                ]);
            }

            foreach ($losers as $l) {
                $notifInsert->execute([
                    "Your prediction for {$comicTitle} Chapter {$chapterNo} was incorrect. The correct answer was: \"{$correctText}\". Better luck next time!",
                    'wrong_prediction', $l['UID']
                ]);
            }

            $pdo->prepare("UPDATE CHAPTER SET isPublished = TRUE WHERE CHAPTER_ID = ?")->execute([$chapterToPublish]);
            $pdo->commit();
            $message = 'Chapter published! ' . count($winners) . ' user(s) earned coins. ' . count($losers) . ' user(s) notified.';
        } catch (Exception $e) {
            $pdo->rollBack();
            $message = 'Error: ' . $e->getMessage(); $msgType = 'error';
        }
    }
}

// ============================================================
// POST: Delete prediction poll
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_poll') {
    $chapterId = intval($_POST['chapter_id'] ?? 0);
    if ($chapterId) {
        $pdo->prepare("DELETE FROM PREDICTION_OPTION WHERE Chapter_ID = ?")->execute([$chapterId]);
        $message = 'Poll deleted.';
    }
}

// ============================================================
// POST: Grant coins to a user
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'grant_coins') {
    $targetUserId = intval($_POST['target_user_id'] ?? 0);
    $amount       = intval($_POST['coin_amount']    ?? 0);

    if (!$targetUserId) {
        $message = 'Please select a user.'; $msgType = 'error';
    } elseif ($amount === 0 || $amount < -9999 || $amount > 9999) {
        $message = 'Amount must be between -9999 and 9999 (non-zero).'; $msgType = 'error';
    } else {
        // Verify user exists
        $uStmt = $pdo->prepare("SELECT Name FROM USERS WHERE ID = ?");
        $uStmt->execute([$targetUserId]);
        $targetUser = $uStmt->fetchColumn();

        if (!$targetUser) {
            $message = 'User not found.'; $msgType = 'error';
        } else {
            $pdo->prepare("INSERT INTO COIN_TRANSACTION (Amount, Time_stamp, UID) VALUES (?, NOW(), ?)")
                ->execute([$amount, $targetUserId]);

            $verb = $amount > 0 ? "granted {$amount}" : "deducted " . abs($amount);
            $message = "Successfully {$verb} coin(s) to {$targetUser}. Their balance has been updated.";
        }
    }
}

// ============================================================
// POST: Add special emoji to a comic
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_emoji') {
    $emojiName   = trim($_POST['emoji_name']    ?? '');
    $emojiPath   = trim($_POST['emoji_path']    ?? '');
    $emojiCost   = intval($_POST['emoji_cost']  ?? 1);
    $emojiComic  = intval($_POST['emoji_comic'] ?? 0);

    if (empty($emojiName) || empty($emojiPath) || !$emojiComic) {
        $message = 'All emoji fields are required.'; $msgType = 'error';
    } elseif (!preg_match('/^[a-zA-Z0-9_\-]+$/', $emojiName)) {
        $message = 'Emoji name may only contain letters, numbers, hyphens, and underscores.'; $msgType = 'error';
    } elseif ($emojiCost < 1) {
        $message = 'Emoji cost must be at least 1 coin.'; $msgType = 'error';
    } else {
        try {
            $pdo->prepare("INSERT INTO SPECIAL_EMOJI (Name, E_Value, Coin_Amount, Comic_ID) VALUES (?, ?, ?, ?)")
                ->execute([$emojiName, $emojiPath, $emojiCost, $emojiComic]);
            $message = "Emoji \"{$emojiName}\" added successfully.";
        } catch (PDOException $e) {
            $message = 'An emoji with that name already exists.'; $msgType = 'error';
        }
    }
}

// ============================================================
// POST: Delete special emoji
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_emoji') {
    $emojiName = trim($_POST['emoji_name'] ?? '');
    if ($emojiName) {
        $pdo->prepare("DELETE FROM SPECIAL_EMOJI WHERE Name = ?")->execute([$emojiName]);
        $message = "Emoji \"{$emojiName}\" deleted.";
    }
}

// ============================================================
// FETCH DATA
// ============================================================

$comics = $pdo->query("
    SELECT c.ID, c.Name, c.Title, c.IsCompleted,
           COUNT(ch.CHAPTER_ID) as TotalChapters
    FROM COMIC c
    LEFT JOIN CHAPTER ch ON c.ID = ch.Comic_ID
    GROUP BY c.ID ORDER BY c.ID DESC
")->fetchAll();

$chaptersWithPolls = $pdo->query("
    SELECT ch.CHAPTER_ID, ch.ChapterNumber, ch.isPublished, ch.Comic_ID,
           c.Name AS ComicName, c.Title AS ComicTitle,
           COUNT(po.ID) AS OptionCount,
           SUM(po.IsResolved) AS ResolvedCount,
           SUM(CASE WHEN po.IsCorrect THEN 1 ELSE 0 END) AS HasCorrect
    FROM CHAPTER ch
    JOIN COMIC c ON ch.Comic_ID = c.ID
    LEFT JOIN PREDICTION_OPTION po ON ch.CHAPTER_ID = po.Chapter_ID
    GROUP BY ch.CHAPTER_ID
    ORDER BY ch.Comic_ID ASC, ch.ChapterNumber ASC
")->fetchAll();

$unpublishedChapters = $pdo->query("
    SELECT ch.CHAPTER_ID, ch.ChapterNumber, c.Name AS ComicName, c.Title AS ComicTitle
    FROM CHAPTER ch JOIN COMIC c ON ch.Comic_ID = c.ID
    WHERE ch.isPublished = FALSE
    ORDER BY c.ID ASC, ch.ChapterNumber ASC
")->fetchAll();

// All users (for coin granting)
$allUsers = $pdo->query("
    SELECT u.ID, u.Name, u.Email,
           COALESCE(SUM(ct.Amount), 0) AS Balance
    FROM USERS u
    LEFT JOIN COIN_TRANSACTION ct ON u.ID = ct.UID
    GROUP BY u.ID
    ORDER BY u.Name ASC
")->fetchAll();

// All emojis with comic info
$allEmojis = $pdo->query("
    SELECT se.Name, se.E_Value, se.Coin_Amount, se.Comic_ID,
           c.Title AS ComicTitle, c.Name AS ComicName,
           COUNT(ue.UID) AS OwnersCount
    FROM SPECIAL_EMOJI se
    JOIN COMIC c ON se.Comic_ID = c.ID
    LEFT JOIN USER_EMOJI ue ON se.Name = ue.Emoji_Name
    GROUP BY se.Name
    ORDER BY se.Comic_ID ASC, se.Name ASC
")->fetchAll();

// Coin stats
$coinStats = $pdo->query("
    SELECT u.Name, u.Email,
           COALESCE(SUM(ct.Amount), 0) AS CoinBalance,
           COUNT(ct.ID) AS Transactions
    FROM USERS u
    LEFT JOIN COIN_TRANSACTION ct ON u.ID = ct.UID
    GROUP BY u.ID
    ORDER BY CoinBalance DESC
    LIMIT 20
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Akatsuki</title>
    <style>
        :root {
            --bg-primary: #0f0f0f; --bg-secondary: #1a1a1a; --bg-card: #1e1e1e;
            --text-primary: #ffffff; --text-secondary: #a0a0a0; --text-muted: #666;
            --accent-primary: #e74c3c; --accent-secondary: #3498db;
            --border-color: #2a2a2a; --success: #27ae60; --warning: #f39c12;
            --radius-md: 8px; --radius-lg: 12px;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-primary); color: var(--text-primary); padding: 30px 20px; }
        .admin-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid var(--border-color); }
        .admin-header h1 { font-size: 1.6rem; }
        .admin-header a  { color: var(--accent-secondary); font-size: 0.9rem; }
        .container  { max-width: 1100px; margin: 0 auto; }
        .section    { background: var(--bg-card); border: 1px solid var(--border-color); border-radius: var(--radius-lg); padding: 25px; margin-bottom: 30px; }
        .section h2 { font-size: 1.1rem; margin-bottom: 20px; color: var(--accent-secondary); border-bottom: 1px solid var(--border-color); padding-bottom: 10px; }
        .alert          { padding: 12px 16px; border-radius: var(--radius-md); margin-bottom: 20px; font-size: 0.9rem; }
        .alert-success  { background: rgba(39,174,96,0.15); border: 1px solid var(--success); color: var(--success); }
        .alert-error    { background: rgba(231,76,60,0.15);  border: 1px solid var(--accent-primary); color: var(--accent-primary); }
        label           { display: block; font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 6px; }
        input[type="text"], input[type="number"], select, textarea {
            width: 100%; background: #111; color: #fff;
            border: 1px solid var(--border-color); border-radius: var(--radius-md);
            padding: 10px 12px; font-size: 0.9rem; margin-bottom: 14px;
        }
        input[type="text"]:focus, input[type="number"]:focus, select:focus { outline: none; border-color: var(--accent-secondary); }
        .btn           { display: inline-block; padding: 10px 20px; border-radius: var(--radius-md); border: none; cursor: pointer; font-size: 0.9rem; font-weight: 600; }
        .btn-primary   { background: var(--accent-primary);   color: #fff; }
        .btn-secondary { background: var(--accent-secondary); color: #fff; }
        .btn-success   { background: var(--success);          color: #fff; }
        .btn-warning   { background: var(--warning);          color: #000; }
        .btn-danger    { background: transparent; color: var(--accent-primary); border: 1px solid var(--accent-primary); font-size: 0.8rem; padding: 5px 10px; }
        .btn:hover     { opacity: 0.85; }
        table          { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
        th             { text-align: left; padding: 10px; color: var(--text-muted); font-weight: 600; border-bottom: 1px solid var(--border-color); }
        td             { padding: 10px; border-bottom: 1px solid #1a1a1a; color: var(--text-secondary); }
        tr:hover td    { background: rgba(255,255,255,0.02); }
        .badge         { display: inline-block; padding: 2px 8px; border-radius: 20px; font-size: 0.75rem; font-weight: 600; }
        .badge-green   { background: rgba(39,174,96,0.2);  color: var(--success); }
        .badge-orange  { background: rgba(243,156,18,0.2); color: var(--warning); }
        .badge-red     { background: rgba(231,76,60,0.2);  color: var(--accent-primary); }
        .badge-gray    { background: rgba(255,255,255,0.05); color: var(--text-muted); }
        .form-row      { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .form-row-3    { display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 15px; }
        .options-grid  { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 16px; }
        .emoji-preview-sm { width: 32px; height: 32px; object-fit: contain; vertical-align: middle; border-radius: 4px; }
        .section-note  { color: var(--text-muted); font-size: 0.85rem; margin-bottom: 20px; line-height: 1.55; }
        .inline-form   { display: inline; }
    </style>
</head>
<body>
<div class="container">

    <div class="admin-header">
        <h1>🛠 Akatsuki Admin Panel</h1>
        <div>
            <span style="color: var(--text-muted); font-size: 0.85rem; margin-right: 15px;">
                Logged in as: <?php echo h($_SESSION['artist_name'] ?? 'Artist'); ?>
            </span>
            <a href="index.php">← Back to Site</a>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-<?php echo $msgType; ?>"><?php echo h($message); ?></div>
    <?php endif; ?>

    <!-- ============================================================
         SECTION 1: Create Prediction Poll
    ============================================================ -->
    <div class="section">
        <h2>📊 Create Prediction Poll</h2>
        <p class="section-note">
            Create a poll for the latest published chapter. Users predict what happens in the NEXT chapter.
            You must provide exactly 4 options.
        </p>
        <form method="POST" action="">
            <input type="hidden" name="action" value="create_poll">
            <label>Select Chapter to attach poll to:</label>
            <select name="chapter_id" required>
                <option value="">-- Select a published chapter --</option>
                <?php foreach ($chaptersWithPolls as $ch): ?>
                    <?php if ($ch['isPublished'] && $ch['OptionCount'] == 0): ?>
                        <option value="<?php echo $ch['CHAPTER_ID']; ?>">
                            <?php echo h($ch['ComicTitle'] ?: $ch['ComicName']); ?> — Chapter <?php echo $ch['ChapterNumber']; ?>
                        </option>
                    <?php endif; ?>
                <?php endforeach; ?>
            </select>
            <label>Poll Options (exactly 4 — phrase as predictions for the NEXT chapter):</label>
            <div class="options-grid">
                <?php for ($i = 1; $i <= 4; $i++): ?>
                    <div>
                        <label style="color: var(--accent-secondary);">Option <?php echo $i; ?></label>
                        <input type="text" name="options[]" placeholder="Option <?php echo $i; ?>" required>
                    </div>
                <?php endfor; ?>
            </div>
            <button type="submit" class="btn btn-primary">Create Poll</button>
        </form>
    </div>

    <!-- ============================================================
         SECTION 2: Publish Chapter + Resolve Previous Poll
    ============================================================ -->
    <div class="section">
        <h2>🚀 Publish New Chapter & Resolve Poll</h2>
        <p class="section-note">
            When you publish a new chapter, select which option was correct in the PREVIOUS chapter's poll.
            Coins will automatically be distributed to correct predictors and notifications sent to all.
        </p>
        <form method="POST" action="" id="publishForm">
            <input type="hidden" name="action" value="publish_and_resolve">
            <div class="form-row">
                <div>
                    <label>Chapter to Publish:</label>
                    <select name="chapter_to_publish" required>
                        <option value="">-- Select unpublished chapter --</option>
                        <?php foreach ($unpublishedChapters as $ch): ?>
                            <option value="<?php echo $ch['CHAPTER_ID']; ?>">
                                <?php echo h($ch['ComicTitle'] ?: $ch['ComicName']); ?> — Chapter <?php echo $ch['ChapterNumber']; ?>
                            </option>
                        <?php endforeach; ?>
                        <?php if (empty($unpublishedChapters)): ?>
                            <option disabled>No unpublished chapters</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div>
                    <label>Resolve Poll for Chapter (the chapter whose poll you are now answering):</label>
                    <select name="poll_chapter_id" id="pollChapterSelect" onchange="loadOptions(this.value)">
                        <option value="">-- No poll to resolve --</option>
                        <?php foreach ($chaptersWithPolls as $ch): ?>
                            <?php if ($ch['OptionCount'] > 0 && !$ch['ResolvedCount']): ?>
                                <option value="<?php echo $ch['CHAPTER_ID']; ?>">
                                    <?php echo h($ch['ComicTitle'] ?: $ch['ComicName']); ?> — Chapter <?php echo $ch['ChapterNumber']; ?>
                                </option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div id="optionsContainer" style="display:none; margin-bottom: 16px;">
                <label>Select the Correct Option:</label>
                <select name="correct_option_id" id="correctOptionSelect">
                    <option value="">-- Select the chapter first --</option>
                </select>
            </div>
            <button type="submit" class="btn btn-secondary"
                    onclick="return confirm('This will publish the chapter and permanently distribute coins. Continue?');">
                Publish Chapter & Distribute Coins
            </button>
        </form>
    </div>

    <!-- ============================================================
         SECTION 3: Chapter & Poll Status Table
    ============================================================ -->
    <div class="section">
        <h2>📋 Chapter & Poll Overview</h2>
        <table>
            <thead>
                <tr><th>Comic</th><th>Chapter</th><th>Published</th><th>Poll Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php foreach ($chaptersWithPolls as $ch): ?>
                    <tr>
                        <td><?php echo h($ch['ComicTitle'] ?: $ch['ComicName']); ?></td>
                        <td>Chapter <?php echo $ch['ChapterNumber']; ?></td>
                        <td>
                            <?php if ($ch['isPublished']): ?>
                                <span class="badge badge-green">Published</span>
                            <?php else: ?>
                                <span class="badge badge-gray">Draft</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($ch['OptionCount'] == 0): ?>
                                <span class="badge badge-gray">No poll</span>
                            <?php elseif ($ch['ResolvedCount'] > 0): ?>
                                <span class="badge badge-green">Resolved ✓</span>
                            <?php else: ?>
                                <span class="badge badge-orange">Open (<?php echo $ch['OptionCount']; ?> options)</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($ch['OptionCount'] > 0 && !$ch['ResolvedCount']): ?>
                                <form method="POST" class="inline-form"
                                      onsubmit="return confirm('Delete poll and all predictions for this chapter?');">
                                    <input type="hidden" name="action"     value="delete_poll">
                                    <input type="hidden" name="chapter_id" value="<?php echo $ch['CHAPTER_ID']; ?>">
                                    <button type="submit" class="btn btn-danger">Delete Poll</button>
                                </form>
                            <?php else: ?>
                                <span style="color: var(--text-muted); font-size: 0.8rem;">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- ============================================================
         SECTION 4: Grant Coins to Users  ← NEW
    ============================================================ -->
    <div class="section">
        <h2>🪙 Grant / Adjust Coins</h2>
        <p class="section-note">
            Manually set a user's coin balance by adding or deducting coins.
            Enter a positive number to grant coins, or a negative number to deduct.
            This creates a COIN_TRANSACTION record so the history is preserved.
        </p>
        <form method="POST" action="">
            <input type="hidden" name="action" value="grant_coins">
            <div class="form-row">
                <div>
                    <label>Select User:</label>
                    <select name="target_user_id" required>
                        <option value="">-- Select a user --</option>
                        <?php foreach ($allUsers as $u): ?>
                            <option value="<?php echo $u['ID']; ?>">
                                <?php echo h($u['Name']); ?> (<?php echo h($u['Email']); ?>) — <?php echo $u['Balance']; ?> coins
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label>Coin Amount (positive = grant, negative = deduct):</label>
                    <input type="number" name="coin_amount" min="-9999" max="9999" step="1"
                           placeholder="e.g. 5 or -2" required>
                </div>
            </div>
            <button type="submit" class="btn btn-warning"
                    onclick="return confirm('Adjust this user\'s coin balance?');">
                Apply Coin Adjustment
            </button>
        </form>
    </div>

    <!-- ============================================================
         SECTION 5: Coin Economy Overview
    ============================================================ -->
    <div class="section">
        <h2>💰 Coin Economy Overview</h2>
        <table>
            <thead>
                <tr><th>User</th><th>Email</th><th>Coin Balance</th><th>Transactions</th></tr>
            </thead>
            <tbody>
                <?php foreach ($coinStats as $stat): ?>
                    <tr>
                        <td><?php echo h($stat['Name']); ?></td>
                        <td style="color: var(--text-muted);"><?php echo h($stat['Email']); ?></td>
                        <td>
                            <span style="color: var(--warning); font-weight: 600;"><?php echo $stat['CoinBalance']; ?> coins</span>
                        </td>
                        <td><?php echo $stat['Transactions']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- ============================================================
         SECTION 6: Emoji Store Management  ← NEW
    ============================================================ -->
    <div class="section">
        <h2>🎭 Emoji Store Management</h2>
        <p class="section-note">
            Add or remove special emojis for each comic. The <strong>emoji name</strong> is a slug
            used in post tags (letters, numbers, hyphens, underscores only).
            The <strong>file path</strong> should be the server-relative path to the .webp file,
            e.g. <code>assets/emojis/anya-heh.webp</code>. Upload the file to the server first.
        </p>

        <!-- Add emoji form -->
        <form method="POST" action="" style="margin-bottom: 28px; padding-bottom: 24px; border-bottom: 1px solid var(--border-color);">
            <input type="hidden" name="action" value="add_emoji">
            <h3 style="font-size: 0.95rem; color: var(--text-secondary); margin-bottom: 16px;">➕ Add New Emoji</h3>
            <div class="form-row-3">
                <div>
                    <label>Comic:</label>
                    <select name="emoji_comic" required>
                        <option value="">-- Select comic --</option>
                        <?php foreach ($comics as $c): ?>
                            <option value="<?php echo $c['ID']; ?>">
                                <?php echo h($c['Title'] ?: $c['Name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label>Emoji Name (slug):</label>
                    <input type="text" name="emoji_name" placeholder="e.g. anya-heh"
                           pattern="[a-zA-Z0-9_\-]+" title="Letters, numbers, hyphens, underscores only" required>
                </div>
                <div>
                    <label>Coin Cost:</label>
                    <input type="number" name="emoji_cost" min="1" max="100" value="1" required>
                </div>
            </div>
            <div>
                <label>WebP File Path (relative to site root):</label>
                <input type="text" name="emoji_path" placeholder="assets/emojis/anya-heh.webp" required>
            </div>
            <button type="submit" class="btn btn-success">Add Emoji</button>
        </form>

        <!-- Current emojis table -->
        <?php if (empty($allEmojis)): ?>
            <p style="color: var(--text-muted); font-size: 0.9rem;">No emojis in the store yet. Add some above.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr><th>Preview</th><th>Name</th><th>Comic</th><th>Cost</th><th>Owners</th><th>File Path</th><th>Delete</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($allEmojis as $em): ?>
                        <tr>
                            <td>
                                <img src="<?php echo h($em['E_Value']); ?>"
                                     alt="<?php echo h($em['Name']); ?>"
                                     class="emoji-preview-sm"
                                     onerror="this.style.opacity='0.2';">
                            </td>
                            <td style="font-family: monospace; color: var(--text-primary);">
                                <?php echo h($em['Name']); ?>
                            </td>
                            <td><?php echo h($em['ComicTitle'] ?: $em['ComicName']); ?></td>
                            <td style="color: var(--warning);">🪙 <?php echo $em['Coin_Amount']; ?></td>
                            <td><?php echo $em['OwnersCount']; ?> user(s)</td>
                            <td style="font-size: 0.78rem; color: var(--text-muted); font-family: monospace;">
                                <?php echo h($em['E_Value']); ?>
                            </td>
                            <td>
                                <?php if ($em['OwnersCount'] == 0): ?>
                                    <form method="POST" class="inline-form"
                                          onsubmit="return confirm('Permanently delete emoji \"<?php echo h($em['Name']); ?>\"?');">
                                        <input type="hidden" name="action"     value="delete_emoji">
                                        <input type="hidden" name="emoji_name" value="<?php echo h($em['Name']); ?>">
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                <?php else: ?>
                                    <span class="badge badge-gray" title="Cannot delete — users own this emoji">Owned</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

</div><!-- .container -->

<script>
function loadOptions(chapterId) {
    const container = document.getElementById('optionsContainer');
    const select    = document.getElementById('correctOptionSelect');
    if (!chapterId) { container.style.display = 'none'; return; }

    fetch(`get_poll_options.php?chapter_id=${chapterId}`)
        .then(r => r.json())
        .then(options => {
            select.innerHTML = '<option value="">-- Select the correct option --</option>';
            options.forEach(opt => {
                const o = document.createElement('option');
                o.value       = opt.ID;
                o.textContent = `Option ${opt.Option_Number}: ${opt.OptionText}`;
                select.appendChild(o);
            });
            container.style.display = 'block';
        })
        .catch(() => { container.style.display = 'none'; });
}
</script>
</body>
</html>
