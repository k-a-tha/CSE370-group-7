<?php
// Securely escape HTML output
function h($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

// Check if a regular user is logged in
function isUserLoggedIn() {
    return isset($_SESSION['user_id']) && $_SESSION['user_type'] === 'user';
}

// Check if an artist is logged in
function isArtistLoggedIn() {
    return isset($_SESSION['user_id']) && $_SESSION['user_type'] === 'artist';
}
?>