<?php
//header.php
require_once __DIR__ . '/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? h($pageTitle) . ' - Akatsuki' : 'Akatsuki - Manga & Webtoon Platform'; ?></title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
	
</head>
<body>
    <header class="main-header">
        <div class="header-container">
            <a href="index.php" class="logo">
                <span class="logo-text">AKATSUKI</span>
            </a>
            
            <nav class="main-nav">
                <a href="index.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : ''; ?>">HOME</a>
                
                <div class="nav-dropdown">
                    <a href="#" class="nav-link">GENRES <span class="dropdown-arrow">▼</span></a>
                    <div class="dropdown-content">
                        <a href="comics.php?genre=romance">Romance</a>
                        <a href="comics.php?genre=action">Action</a>
                        <a href="comics.php?genre=fantasy">Fantasy</a>
                        <a href="comics.php?genre=comedy">Comedy</a>
                        <a href="comics.php?genre=drama">Drama</a>
                        <a href="comics.php?genre=slice-of-life">Slice of Life</a>
                        <a href="comics.php?genre=horror">Horror</a>
                    </div>
                </div>

                <?php
                    $__live = $pdo->query("
                        SELECT COUNT(*) FROM LIVESTREAM
                        WHERE StartTime <= NOW()
                        AND (EndTime IS NULL OR EndTime > NOW())
                    ")->fetchColumn();
                ?>
                <a href="livestream.php" class="nav-link" id="nav-live">
                    <?php if ($__live > 0): ?>
                        <span class="live-nav-dot"></span>
                    <?php endif; ?>
                    LIVE
                </a>

                <form action="comics.php" method="GET" class="header-search-form">
                    <div class="search-input-group">
                        <?php if (isset($_GET['genre']) && !empty($_GET['genre'])): ?>
                            <input type="hidden" name="genre" value="<?php echo h($_GET['genre']); ?>">
                        <?php endif; ?>
                        <input type="text" name="search" placeholder="Search comics..." 
                               value="<?php echo isset($_GET['search']) ? h($_GET['search']) : ''; ?>">
                        <button type="submit" class="search-submit-btn">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                                <circle cx="11" cy="11" r="8"></circle>
                                <path d="M21 21l-4.35-4.35"></path>
                            </svg>
                        </button>
                    </div>
                </form>
            </nav>
			
			<?php if (isUserLoggedIn()): ?>
				<?php
					$__bellCount = $pdo->prepare("SELECT COUNT(*) FROM NOTIFICATION WHERE UID = ? AND IsRead = FALSE");
					$__bellCount->execute([$_SESSION['user_id']]);
					$__bellCount = intval($__bellCount->fetchColumn());
				?>
				<a href="notifications.php" class="notif-bell-link" title="Notifications">
					🔔
					<?php if ($__bellCount > 0): ?>
						<span class="notif-count-badge"><?php echo $__bellCount > 9 ? '9+' : $__bellCount; ?></span>
					<?php endif; ?>
				</a>
			<?php endif; ?>

            <div class="auth-buttons">
                <?php if (isLoggedIn()): ?>
                    <?php if (isArtistLoggedIn()): ?>
						<a href="admin_panel.php" class="btn btn-outline">Create Prediction</a>
                        <!-- opens the Go Live modal -->
                        <button type="button" class="btn btn-primary"
                                style="background:#ef4444;border-color:#ef4444;cursor:pointer;"
                                onclick="document.getElementById('golive-modal').style.display='flex'">
                            🔴 Go Live
                        </button>
                    <?php endif; ?>
                    <span class="welcome-text">Welcome, <?php echo h($_SESSION['user_name']); ?></span>
                    <a href="logout.php" class="btn btn-outline">Log out</a>
                <?php else: ?>
                    <a href="login_user.php" class="btn btn-outline">Sign in</a>
                    <a href="register_user.php" class="btn btn-outline">Sign up</a>
                <?php endif; ?>
            </div>

            <button class="mobile-menu-btn" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </header>

    <?php if (isArtistLoggedIn()): ?>
    <?php
        $__allComics = $pdo->query("
            SELECT ID, COALESCE(Title, Name) AS Label FROM COMIC ORDER BY Label
        ")->fetchAll();
    ?>

    <!-- ── Go Live Modal ─────────────────────────────── -->
    <div id="golive-modal" style="
            display:none; position:fixed; inset:0; z-index:9999;
            background:rgba(0,0,0,.72); align-items:center; justify-content:center;
            padding:16px; backdrop-filter:blur(4px);"
         onclick="if(event.target===this)this.style.display='none'">

        <div style="background:var(--bg-card,#1a1a2e); border:1px solid var(--border-color,#2a2a3e);
                    border-radius:16px; width:100%; max-width:460px; padding:32px;
                    position:relative; box-shadow:0 24px 64px rgba(0,0,0,.6);">

            <button onclick="document.getElementById('golive-modal').style.display='none'"
                    style="position:absolute;top:14px;right:16px;background:none;border:none;
                           color:var(--text-muted,#888);font-size:1.4rem;cursor:pointer;line-height:1;">✕</button>
            <?php
				$activeStmt = $pdo->prepare("
					SELECT VideoURL, Title 
					FROM LIVESTREAM 
					WHERE AID = ? AND EndTime IS NULL AND StartTime <= NOW()
				");
				$activeStmt->execute([$_SESSION['user_id']]);
				$currentActive = $activeStmt->fetchAll();

				if (!empty($currentActive)): ?>
					<div style="margin-bottom: 20px; padding: 15px; background: rgba(239,68,68,0.1); border: 1px solid #ef4444; border-radius: 12px;">
						<h3 style="color:#f87171; font-size:0.85rem; margin:0 0 10px; text-transform:uppercase;">You are Currently Live</h3>
						<?php foreach ($currentActive as $as): ?>
							<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
								<span style="font-size:0.8rem; color:#fff;"><?php echo htmlspecialchars($as['Title']); ?></span>
								<a href="artist_go_live.php?end=<?php echo urlencode($as['VideoURL']); ?>" 
								   style="background:#ef4444; color:#fff; padding:5px 10px; border-radius:6px; text-decoration:none; font-size:0.75rem; font-weight:700;">
								   ⏹ End Live
								</a>
							</div>
						<?php endforeach; ?>
					</div>
					<hr style="border:0; border-top:1px solid #333; margin:20px 0;">
			<?php endif; ?>
				<!-- END OF PASTED SECTION[cite: 13, 14] -->
            <h2 style="color:var(--text-primary,#fff);font-size:1.2rem;margin:0 0 6px;">🔴 Go Live Now</h2>
            <p style="color:var(--text-muted,#888);font-size:0.83rem;margin:0 0 22px;line-height:1.5;">
                Start your YouTube stream first, paste the link here, then hit Go Live.
            </p>

            <form method="POST" action="artist_go_live.php">
                <input type="hidden" name="action" value="go_live">

                <div style="margin-bottom:14px;">
                    <label style="display:block;font-size:0.8rem;font-weight:600;
                                  color:var(--text-secondary,#aaa);margin-bottom:6px;">Stream Title</label>
                    <input type="text" name="title" placeholder="e.g. Drawing Chapter 12 Live!" required
                           style="width:100%;padding:10px 14px;background:var(--bg-secondary,#111);
                                  border:1px solid var(--border-color,#333);border-radius:8px;
                                  color:var(--text-primary,#fff);font-size:0.9rem;font-family:inherit;
                                  box-sizing:border-box;outline:none;">
                </div>

                <div style="margin-bottom:14px;">
                    <label style="display:block;font-size:0.8rem;font-weight:600;
                                  color:var(--text-secondary,#aaa);margin-bottom:6px;">YouTube Live URL</label>
                    <input type="url" name="video_url" placeholder="https://youtube.com/live/..." required
                           style="width:100%;padding:10px 14px;background:var(--bg-secondary,#111);
                                  border:1px solid var(--border-color,#333);border-radius:8px;
                                  color:var(--text-primary,#fff);font-size:0.9rem;font-family:inherit;
                                  box-sizing:border-box;outline:none;">
                    <small style="font-size:0.74rem;color:var(--text-muted,#888);margin-top:4px;display:block;">
                        Copy from YouTube Studio → Go Live
                    </small>
                </div>

                <div style="margin-bottom:24px;">
                    <label style="display:block;font-size:0.8rem;font-weight:600;
                                  color:var(--text-secondary,#aaa);margin-bottom:6px;">Related Comic</label>
                    <select name="comic_id" required
                            style="width:100%;padding:10px 14px;background:var(--bg-secondary,#111);
                                   border:1px solid var(--border-color,#333);border-radius:8px;
                                   color:var(--text-primary,#fff);font-size:0.9rem;font-family:inherit;
                                   box-sizing:border-box;outline:none;">
                        <option value="">— Select a comic —</option>
                        <?php foreach ($__allComics as $__c): ?>
                            <option value="<?php echo $__c['ID']; ?>"><?php echo h($__c['Label']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="display:flex;gap:10px;">
                    <button type="button"
                            onclick="document.getElementById('golive-modal').style.display='none'"
                            style="flex:1;padding:11px;background:transparent;
                                   border:1px solid var(--border-color,#333);color:var(--text-muted,#888);
                                   border-radius:8px;font-size:0.9rem;cursor:pointer;font-family:inherit;">
                        Cancel
                    </button>
                    <button type="submit"
                            style="flex:2;padding:11px;background:#ef4444;color:#fff;border:none;
                                   border-radius:8px;font-size:1rem;font-weight:700;cursor:pointer;
                                   font-family:inherit;letter-spacing:.02em;">
                        🔴 GO LIVE NOW
                    </button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <main class="main-content">