<?php
//comics.php
$pageTitle = 'All Comics';
require_once 'header.php';

// Get filters
$genre = isset($_GET['genre']) ? trim($_GET['genre']) : '';
$sort = isset($_GET['sort']) ? trim($_GET['sort']) : 'latest';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

function buildUrl($newSort, $g, $s) {
    $params = ['sort' => $newSort];
    if (!empty($g)) $params['genre'] = $g;
    if (!empty($s)) $params['search'] = $s;
    return "comics.php?" . http_build_query($params);
}

// Build query
$query = "
    SELECT 
        c.ID,
        c.Name,
        c.Title,
        c.HardCopyLink,
        c.Synopsis,
        COALESCE(AVG(r.Score), 0) as AvgRating,
        COUNT(DISTINCT r.UID) as RatingCount,
        MAX(ch.Date_of_Publication) as LastUpdate
    FROM COMIC c
    LEFT JOIN RATING r ON c.ID = r.Comic_ID
    LEFT JOIN CHAPTER ch ON c.ID = ch.Comic_ID AND ch.isPublished = TRUE
";

$params = [];
$conditions = [];

// Filter by genre
if (!empty($genre)) {
    $query .= " LEFT JOIN GENRE g ON c.ID = g.Comic_ID";
    $conditions[] = "LOWER(g.Genre) = LOWER(?)";
    $params[] = $genre;
}

// Standard keyword search logic in comics.php
if (!empty($search)) {
    $conditions[] = "(LOWER(c.Name) LIKE LOWER(?) OR LOWER(c.Title) LIKE LOWER(?))";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

if (!empty($conditions)) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}

$query .= " GROUP BY c.ID";

// Sorting
switch ($sort) {
    case 'popular':
        $query .= " ORDER BY AvgRating DESC, RatingCount DESC";
        break;
    case 'name':
        $query .= " ORDER BY c.Name ASC";
        break;
    case 'latest':
    default:
        $query .= " ORDER BY LastUpdate DESC, c.ID DESC";
        break;
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$comics = $stmt->fetchAll();

// Helper functions
function getThumbnail($hardCopyLink, $comicName) {
    if (!empty($hardCopyLink) && file_exists($hardCopyLink)) {
        return $hardCopyLink;
    }
    $slug = strtolower(str_replace(' ', '-', $comicName));
    $path = "assets/thumbnails/{$slug}.webp";
    if (file_exists($path)) {
        return $path;
    }
    return "assets/thumbnails/placeholder.webp";
}

function renderStars($rating) {
    $fullStars = floor($rating / 2);
    $halfStar = ($rating / 2) - $fullStars >= 0.5;
    $emptyStars = 5 - $fullStars - ($halfStar ? 1 : 0);
    
    $html = '';
    for ($i = 0; $i < $fullStars; $i++) $html .= '★';
    if ($halfStar) $html .= '☆';
    for ($i = 0; $i < $emptyStars; $i++) $html .= '☆';
    return $html;
}

function getRecentChapters($pdo, $comicId, $limit = 2) {
    $stmt = $pdo->prepare("
        SELECT CHAPTER_ID, ChapterNumber, Date_of_Publication 
        FROM CHAPTER 
        WHERE Comic_ID = :comicId AND isPublished = TRUE
        ORDER BY ChapterNumber DESC 
        LIMIT :limit
    ");
    $stmt->bindValue(':comicId', (int)$comicId, PDO::PARAM_INT);
    $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
    
    $stmt->execute();
    return $stmt->fetchAll();
}
?>

<style>
    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
        flex-wrap: wrap;
        gap: 20px;
    }
    
    .filters {
        display: flex;
        gap: 15px;
        flex-wrap: wrap;
    }
    
    .filter-select {
        padding: 10px 15px;
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-md);
        color: var(--text-primary);
        cursor: pointer;
    }
    
    .search-form {
        display: flex;
        gap: 10px;
    }
    
    .search-input {
        padding: 10px 15px;
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-md);
        color: var(--text-primary);
        min-width: 200px;
    }
    
    .comics-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 25px;
    }
    
    .active-filters {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
        flex-wrap: wrap;
    }
    
    .filter-tag {
        display: flex;
        align-items: center;
        gap: 8px;
        background: var(--accent-secondary);
        color: var(--text-primary);
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
    }
    
    .filter-tag a {
        color: var(--text-primary);
        font-weight: bold;
    }
</style>

<div class="page-header">
    <h1 class="section-title">
        <?php if ($genre): ?>
            <?php echo h(ucfirst($genre)); ?> Comics
        <?php elseif ($search): ?>
            Search Results for "<?php echo h($search); ?>"
        <?php else: ?>
            All Comics
        <?php endif; ?>
    </h1>
    
    <div class="filters">     
		<select class="filter-select" onchange="window.location.href=this.value">
			<option value="<?php echo buildUrl('latest', $genre, $search); ?>" <?php echo $sort === 'latest' ? 'selected' : ''; ?>>Latest Updates</option>
			<option value="<?php echo buildUrl('popular', $genre, $search); ?>" <?php echo $sort === 'popular' ? 'selected' : ''; ?>>Most Popular</option>
			<option value="<?php echo buildUrl('name', $genre, $search); ?>" <?php echo $sort === 'name' ? 'selected' : ''; ?>>Alphabetical</option>
		</select>
	</div>
</div>

<?php if ($genre || $search): ?>
    <div class="active-filters">
        <?php if ($genre): ?>
            <span class="filter-tag">
                Genre: <?php echo h(ucfirst($genre)); ?>
                <a href="comics.php<?php echo $search ? '?search=' . urlencode($search) : ''; ?>">×</a>
            </span>
        <?php endif; ?>
        <?php if ($search): ?>
            <span class="filter-tag">
                Search: <?php echo h($search); ?>
                <a href="comics.php<?php echo $genre ? '?genre=' . urlencode($genre) : ''; ?>">×</a>
            </span>
        <?php endif; ?>
        <a href="comics.php" style="color: var(--text-muted); font-size: 0.85rem;">Clear all</a>
    </div>
<?php endif; ?>

<div class="comics-grid">
    <?php foreach ($comics as $comic): ?>
        <?php $chapters = getRecentChapters($pdo, $comic['ID']); ?>
        <article class="comic-card">
            <a href="comic.php?id=<?php echo $comic['ID']; ?>" class="comic-thumbnail">
                <img src="<?php echo h(getThumbnail($comic['HardCopyLink'], $comic['Name'])); ?>" 
                     alt="<?php echo h($comic['Title'] ?: $comic['Name']); ?>"
                     loading="lazy">
            </a>
            <div class="comic-info">
                <h3 class="comic-title">
                    <a href="comic.php?id=<?php echo $comic['ID']; ?>">
                        <?php echo h($comic['Title'] ?: $comic['Name']); ?>
                    </a>
                </h3>
                <div class="comic-rating">
                    <span class="stars"><?php echo renderStars($comic['AvgRating']); ?></span>
                    <span class="rating-value"><?php echo number_format($comic['AvgRating'], 1); ?></span>
                </div>
                <div class="comic-chapters">
                    <?php foreach ($chapters as $chapter): ?>
                        <a href="reader.php?id=<?php echo $chapter['CHAPTER_ID']; ?>" class="chapter-link">
                            Chapter <?php echo $chapter['ChapterNumber']; ?>
                        </a>
                    <?php endforeach; ?>
                    <?php if (!empty($comic['LastUpdate'])): ?>
                        <span class="chapter-date">
                            <?php echo date('M j, Y', strtotime($comic['LastUpdate'])); ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </article>
    <?php endforeach; ?>
    
    <?php if (empty($comics)): ?>
        <p style="grid-column: 1/-1; text-align: center; color: var(--text-muted); padding: 50px;">
            <?php if ($search): ?>
                No comics found matching "<?php echo h($search); ?>".
            <?php elseif ($genre): ?>
                No comics found in the <?php echo h($genre); ?> genre.
            <?php else: ?>
                No comics available yet.
            <?php endif; ?>
        </p>
    <?php endif; ?>
</div>

<?php require_once 'footer.php'; ?>