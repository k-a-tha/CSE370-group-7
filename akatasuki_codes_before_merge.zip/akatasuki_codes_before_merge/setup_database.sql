-- =============================================
-- Akatsuki Database Setup Script
-- Database: Anya_Forger
-- =============================================

-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS Anya_Forger;
USE Anya_Forger;

-- =============================================
-- 1. USERS Table
-- =============================================
CREATE TABLE IF NOT EXISTS USERS (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Email VARCHAR(250) NOT NULL UNIQUE,
    Name VARCHAR(100) NOT NULL,
    Gender VARCHAR(20),
    PasswordHash VARCHAR(250) NOT NULL,
    GenrePref VARCHAR(100)
);

-- =============================================
-- 2. ARTIST Table
-- =============================================
CREATE TABLE IF NOT EXISTS ARTIST (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Email VARCHAR(250) NOT NULL UNIQUE,
    Name VARCHAR(100) NOT NULL,
    Gender VARCHAR(20),
    PasswordHash VARCHAR(250) NOT NULL
);

-- =============================================
-- 3. COMIC Table
-- =============================================
CREATE TABLE IF NOT EXISTS COMIC (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    HardCopyLink VARCHAR(500),
    Synopsis VARCHAR(1000),
    Name VARCHAR(200) NOT NULL,
    AID INT NOT NULL,
    Title VARCHAR(200),
    PDF VARCHAR(500),
    FOREIGN KEY (AID) REFERENCES ARTIST(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 4. GENRE Table
-- =============================================
CREATE TABLE IF NOT EXISTS GENRE (
    Comic_ID INT NOT NULL,
    Genre VARCHAR(50) NOT NULL,
    PRIMARY KEY (Comic_ID, Genre),
    FOREIGN KEY (Comic_ID) REFERENCES COMIC(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 5. CHARACTERS Table
-- =============================================
CREATE TABLE IF NOT EXISTS CHARACTERS (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100) NOT NULL,
    Biography VARCHAR(1000),
    Comic_ID INT NOT NULL,
    FOREIGN KEY (Comic_ID) REFERENCES COMIC(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 6. CHAPTER Table
-- =============================================
CREATE TABLE IF NOT EXISTS CHAPTER (
    CHAPTER_ID INT PRIMARY KEY AUTO_INCREMENT,
    Date_of_Publication DATE,
    ChapterNumber INT NOT NULL,
    isPublished BOOLEAN DEFAULT FALSE,
    ContentURL VARCHAR(500),
    Comic_ID INT NOT NULL,
    FOREIGN KEY (Comic_ID) REFERENCES COMIC(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 7. LIVESTREAM Table
-- =============================================
CREATE TABLE IF NOT EXISTS LIVESTREAM (
    VideoURL VARCHAR(500) PRIMARY KEY,
    StartTime DATETIME NOT NULL,
    EndTime DATETIME,
    AID INT NOT NULL,
    Comic_ID INT NOT NULL,
    Title VARCHAR(200),
    FOREIGN KEY (AID) REFERENCES ARTIST(ID) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (Comic_ID) REFERENCES COMIC(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 8. FANART Table
-- =============================================
CREATE TABLE IF NOT EXISTS FANART (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Upload_Date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Image_URL VARCHAR(500) NOT NULL,
    UID INT NOT NULL,
    FOREIGN KEY (UID) REFERENCES USERS(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 9. DEPICTED_IN Table
-- =============================================
CREATE TABLE IF NOT EXISTS DEPICTED_IN (
    Fan_ID INT NOT NULL,
    Character_ID INT NOT NULL,
    Type VARCHAR(50),
    Role VARCHAR(50),
    PRIMARY KEY (Fan_ID, Character_ID),
    FOREIGN KEY (Fan_ID) REFERENCES FANART(ID) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (Character_ID) REFERENCES CHARACTERS(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 10. RATING Table
-- =============================================
CREATE TABLE IF NOT EXISTS RATING (
    TIME_STAMP DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Score DECIMAL(3,1) NOT NULL CHECK (Score >= 0.0 AND Score <= 10.0),
    ReviewText VARCHAR(1000),
    UID INT NOT NULL,
    Comic_ID INT NOT NULL,
    PRIMARY KEY (TIME_STAMP, UID, Comic_ID),
    FOREIGN KEY (UID) REFERENCES USERS(ID) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (Comic_ID) REFERENCES COMIC(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 11. COIN_TRANSACTION Table
-- =============================================
CREATE TABLE IF NOT EXISTS COIN_TRANSACTION (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Amount INT NOT NULL,
    Time_stamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UID INT NOT NULL,
    FOREIGN KEY (UID) REFERENCES USERS(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 12. PREDICTION Table
-- =============================================
CREATE TABLE IF NOT EXISTS PREDICTION (
    PREDICTED_PLOT VARCHAR(500) NOT NULL,
    TimeStamp DATETIME NOT NULL,
    isCorrect BOOLEAN DEFAULT FALSE,
    Chapter_ID INT NOT NULL,
    Coin_T_ID INT,
    UID INT NOT NULL,
    PRIMARY KEY (PREDICTED_PLOT, Chapter_ID, UID),
    FOREIGN KEY (Chapter_ID) REFERENCES CHAPTER(CHAPTER_ID) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (UID) REFERENCES USERS(ID) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (Coin_T_ID) REFERENCES COIN_TRANSACTION(ID) ON DELETE SET NULL
);

-- =============================================
-- 13. NOTIFICATION Table
-- =============================================
CREATE TABLE IF NOT EXISTS NOTIFICATION (
    TIME_STAMP DATETIME NOT NULL,
    PREDICTED_PLOT VARCHAR(500) NOT NULL,
    Chapter_ID INT NOT NULL,
    UID INT NOT NULL,
    PRIMARY KEY (TIME_STAMP, PREDICTED_PLOT, Chapter_ID, UID),
    FOREIGN KEY (PREDICTED_PLOT, Chapter_ID, UID) REFERENCES PREDICTION(PREDICTED_PLOT, Chapter_ID, UID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 14. FORUM_POST Table
-- =============================================
CREATE TABLE IF NOT EXISTS FORUM_POST (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Content VARCHAR(500) NOT NULL,
    TimeStamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UID INT NOT NULL,
    Comic_ID INT NOT NULL,
    FOREIGN KEY (UID) REFERENCES USERS(ID) ON DELETE CASCADE,
    FOREIGN KEY (Comic_ID) REFERENCES COMIC(ID) ON DELETE CASCADE
);

-- =============================================
-- 15. SPECIAL_EMOJI Table
-- =============================================
CREATE TABLE IF NOT EXISTS SPECIAL_EMOJI (
    Name VARCHAR(100) PRIMARY KEY,
    E_Value VARCHAR(10) NOT NULL,
    Coin_Amount INT,
    UID INT NOT NULL,
    FOREIGN KEY (UID) REFERENCES USERS(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 16. USES_ON Table
-- =============================================
CREATE TABLE IF NOT EXISTS USES_ON (
    E_Name VARCHAR(100) NOT NULL,
    F_post_ID INT NOT NULL,
    PRIMARY KEY (E_Name, F_post_ID),
    FOREIGN KEY (E_Name) REFERENCES SPECIAL_EMOJI(Name) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (F_post_ID) REFERENCES FORUM_POST(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 17. VOTE_FOR Table
-- =============================================
CREATE TABLE IF NOT EXISTS VOTE_FOR (
    Vote_Date DATE NOT NULL,
    Character_ID INT NOT NULL,
    Comic_ID INT NOT NULL,
    UID INT NOT NULL,
    PRIMARY KEY (Vote_Date, Character_ID, Comic_ID, UID),
    FOREIGN KEY (Character_ID) REFERENCES CHARACTERS(ID) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (Comic_ID) REFERENCES COMIC(ID) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (UID) REFERENCES USERS(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 18. TOP_FAVOURITE_CHARACTER Table
-- =============================================
CREATE TABLE IF NOT EXISTS TOP_FAVOURITE_CHARACTER (
    RANK INT NOT NULL,
    year YEAR NOT NULL,
    Character_ID INT NOT NULL,
    PRIMARY KEY (RANK, Character_ID),
    FOREIGN KEY (Character_ID) REFERENCES CHARACTERS(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 19. TOP_FAVOURITE_COMIC Table
-- =============================================
CREATE TABLE IF NOT EXISTS TOP_FAVOURITE_COMIC (
    RANK INT NOT NULL,
    Year YEAR NOT NULL,
    Comic_ID INT NOT NULL,
    PRIMARY KEY (RANK, Comic_ID),
    FOREIGN KEY (Comic_ID) REFERENCES COMIC(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- SAMPLE DATA
-- =============================================

-- Insert sample artist
INSERT INTO ARTIST (Email, Name, Gender, PasswordHash) VALUES
('artist@example.com', 'Sample Artist', 'Other', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Insert sample comics
INSERT INTO COMIC (HardCopyLink, Synopsis, Name, AID, Title) VALUES
('assets/thumbnails/solo-leveling.webp', 'In a world where hunters must battle deadly monsters to protect humanity, Sung Jin-Woo is the weakest of them all. But when a mysterious dungeon gives him a unique power, he begins his journey to become the strongest hunter.', 'Solo Leveling', 1, 'Solo Leveling'),
('assets/thumbnails/spy-x-family.webp', 'A spy, an assassin, and a telepath form an unlikely family. Master spy "Twilight" must create a fake family to infiltrate an elite school, but his new "wife" is actually an assassin and his "daughter" is a mind reader!', 'Spy x Family', 1, 'SPY×FAMILY'),
('assets/thumbnails/return-of-the-crazy-demon.webp', 'After being pushed off a cliff by his enemies, the leader of a small sect is reborn 30 years in the past. Armed with memories of his previous life, he sets out on a path of revenge and domination.', 'Return of the Crazy Demon', 1, 'Return of the Crazy Demon');

-- Insert genres
INSERT INTO GENRE (Comic_ID, Genre) VALUES
(1, 'Action'), (1, 'Fantasy'), (1, 'Adventure'),
(2, 'Comedy'), (2, 'Action'), (2, 'Slice of Life'),
(3, 'Action'), (3, 'Martial Arts'), (3, 'Fantasy');

-- Insert chapters
INSERT INTO CHAPTER (Date_of_Publication, ChapterNumber, isPublished, ContentURL, Comic_ID) VALUES
('2026-04-20', 1, TRUE, 'assets/chapters/solo-leveling/chapter-1', 1),
('2026-04-22', 2, TRUE, 'assets/chapters/solo-leveling/chapter-2', 1),
('2026-04-24', 3, TRUE, 'assets/chapters/solo-leveling/chapter-3', 1),
('2026-04-18', 1, TRUE, 'assets/chapters/spy-x-family/chapter-1', 2),
('2026-04-21', 2, TRUE, 'assets/chapters/spy-x-family/chapter-2', 2),
('2026-04-19', 1, TRUE, 'assets/chapters/return-of-the-crazy-demon/chapter-1', 3),
('2026-04-23', 2, TRUE, 'assets/chapters/return-of-the-crazy-demon/chapter-2', 3);

-- Insert sample characters
INSERT INTO CHARACTERS (Name, Biography, Comic_ID) VALUES
('Sung Jin-Woo', 'The main protagonist. Known as the World''s Weakest Hunter before gaining the System.', 1),
('Cha Hae-In', 'An S-Rank Hunter and Vice Guild Master of the Hunters Guild.', 1),
('Loid Forger', 'A spy known by the codename "Twilight", considered the best spy in Westalis.', 2),
('Yor Forger', 'An assassin known as "Thorn Princess" who becomes Loid''s fake wife.', 2),
('Anya Forger', 'A telepath who becomes Loid and Yor''s adopted daughter.', 2);

-- Insert sample user
INSERT INTO USERS (Email, Name, Gender, PasswordHash, GenrePref) VALUES
('user@example.com', 'Sample User', 'Other', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Action');

-- Insert sample ratings
INSERT INTO RATING (TIME_STAMP, Score, ReviewText, UID, Comic_ID) VALUES
(NOW(), 9.5, 'Amazing story with great action sequences!', 1, 1),
(NOW(), 9.0, 'Hilarious and heartwarming family comedy.', 1, 2),
(NOW(), 8.5, 'Great martial arts action and revenge plot.', 1, 3);

SELECT 'Database setup completed successfully!' as Status;
