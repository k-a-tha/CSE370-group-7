<?php
$pageTitle = 'Notifications';
require_once 'header.php';

// Redirect if not logged in as user
if (!isUserLoggedIn()) {
    header('Location: login_user.php');
    exit;
}

$userId = intval($_SESSION['user_id']);

// Mark all as read when page is opened
$pdo->prepare("UPDATE NOTIFICATION SET IsRead = TRUE WHERE UID = ? AND IsRead = FALSE")
    ->execute([$userId]);

// Fetch all notifications for this user
$stmt = $pdo->prepare("
    SELECT ID, TIME_STAMP, Message, Type, IsRead
    FROM NOTIFICATION
    WHERE UID = ?
    ORDER BY TIME_STAMP DESC
    LIMIT 50
");
$stmt->execute([$userId]);
$notifications = $stmt->fetchAll();

// Fetch coin balance
$balanceStmt = $pdo->prepare("SELECT COALESCE(SUM(Amount), 0) AS Balance FROM COIN_TRANSACTION WHERE UID = ?");
$balanceStmt->execute([$userId]);
$balance = $balanceStmt->fetchColumn();
?>

<div class="notifications-page">
    <div class="notifications-header">
        <h1>🔔 Notifications</h1>
        <div class="coin-balance">
            <span class="coin-icon">🪙</span>
            <span class="coin-amount"><?php echo $balance; ?> coins</span>
        </div>
    </div>

    <?php if (empty($notifications)): ?>
        <div class="notifications-empty">
            <p>No notifications yet. Start predicting to earn coins!</p>
            <a href="index.php" class="btn btn-primary" style="margin-top: 15px; display: inline-block;">Browse Comics</a>
        </div>
    <?php else: ?>
        <div class="notifications-list">
            <?php foreach ($notifications as $notif): ?>
                <?php
                $typeClass = match($notif['Type']) {
                    'correct_prediction' => 'notif-correct',
                    'wrong_prediction'   => 'notif-wrong',
                    'new_chapter'        => 'notif-chapter',
                    default              => 'notif-general',
                };
                $icon = match($notif['Type']) {
                    'correct_prediction' => '✅',
                    'wrong_prediction'   => '❌',
                    'new_chapter'        => '📖',
                    default              => '🔔',
                };
                ?>
                <div class="notification-item <?php echo $typeClass; ?>">
                    <span class="notif-icon"><?php echo $icon; ?></span>
                    <div class="notif-body">
                        <p class="notif-message"><?php echo h($notif['Message']); ?></p>
                        <span class="notif-time">
                            <?php echo date('M j, Y \a\t g:i a', strtotime($notif['TIME_STAMP'])); ?>
                        </span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'footer.php'; ?>
