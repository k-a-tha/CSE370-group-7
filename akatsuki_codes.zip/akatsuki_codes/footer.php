    </main>
    <footer class="main-footer">
        <div class="footer-container">
            <div class="footer-brand">
                <a href="index.php" class="logo">
                    <span class="logo-icon">暁</span>
                    <span class="logo-text">Akatsuki</span>
                </a>
                <p class="footer-desc">Your premier destination for manga and webtoons. Read the latest chapters from your favorite series.</p>
            </div>
            
            <div class="footer-links">
                <div class="footer-column">
                    <h4>Browse</h4>
                    <a href="index.php">Home</a>
                    <a href="comics.php">All Comics</a>
                    <a href="comics.php?sort=popular">Popular</a>
                    <a href="comics.php?sort=latest">Latest Updates</a>
                </div>
                <div class="footer-column">
                    <h4>Account</h4>
                    <a href="login_user.php">User Login</a>
                    <a href="register_user.php">User Register</a>
                    <a href="login_artist.php">Artist Login</a>
                    <a href="register_artist.php">Artist Register</a>
                </div>
                <div class="footer-column">
                    <h4>Genres</h4>
                    <a href="comics.php?genre=romance">Romance</a>
                    <a href="comics.php?genre=action">Action</a>
                    <a href="comics.php?genre=fantasy">Fantasy</a>
                    <a href="comics.php?genre=comedy">Comedy</a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> Akatsuki. All rights reserved.</p>
        </div>
    </footer>
    <script src="script.js"></script>
</body>
</html>
