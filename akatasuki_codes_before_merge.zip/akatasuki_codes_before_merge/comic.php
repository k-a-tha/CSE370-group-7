<?php
//comic.php
session_start();
require_once 'db.php';

$comicId = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$comicId) { header('Location: index.php'); exit; }

// ── Handle rating submission ──────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['score'])) {
    if (isUserLoggedIn()) {
        $score = floatval($_POST['score']);
        $review = isset($_POST['review_text']) ? trim($_POST['review_text']) : '';
        $stmt = $pdo->prepare("
            INSERT INTO RATING (UID, Comic_ID, Score, ReviewText, TIME_STAMP)
            VALUES (?, ?, ?, ?, NOW())
            ON DUPLICATE KEY UPDATE
                Score = VALUES(Score),
                ReviewText = VALUES(ReviewText),
                TIME_STAMP = NOW()
        ");
        $stmt->execute([$_SESSION['user_id'], $comicId, $score, $review]);
        header("Location: comic.php?id=$comicId&status=success");
        exit;
    }
}

// ── Handle artist Go Live from comic page ─────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'comic_go_live') {
    if (isArtistLoggedIn()) {
        $artistId = (int)$_SESSION['user_id'];
        $url   = trim($_POST['video_url'] ?? '');
        $title = trim($_POST['stream_title'] ?? '');

        // Verify comic belongs to this artist
        $ok = $pdo->prepare("SELECT ID FROM COMIC WHERE ID = ? AND AID = ?");
        $ok->execute([$comicId, $artistId]);

        if ($url && $title && $ok->fetch()) {
            $stmt = $pdo->prepare("
                INSERT INTO LIVESTREAM (VideoURL, Title, StartTime, EndTime, AID, Comic_ID)
                VALUES (?, ?, NOW(), NULL, ?, ?)
                ON DUPLICATE KEY UPDATE
                    Title     = VALUES(Title),
                    StartTime = VALUES(StartTime),
                    EndTime   = NULL,
                    AID       = VALUES(AID),
                    Comic_ID  = VALUES(Comic_ID)
            ");
            $stmt->execute([$url, $title, $artistId, $comicId]);
        }
        header("Location: comic.php?id=$comicId&live=started");
        exit;
    }
}

// ── Handle artist End Live from comic page ────────────
if (isset($_GET['end_live']) && isArtistLoggedIn()) {
    $artistId = (int)$_SESSION['user_id'];
    $stmt = $pdo->prepare("UPDATE LIVESTREAM SET EndTime = NOW() WHERE Comic_ID = ? AND AID = ? AND (EndTime IS NULL OR EndTime > NOW())");
    $stmt->execute([$comicId, $artistId]);
    header("Location: comic.php?id=$comicId&live=ended");
    exit;
}

// ── Fetch Comic Data ──────────────────────────────────
$stmt = $pdo->prepare("
    SELECT c.*, a.Name as ArtistName,
           COALESCE(AVG(r.Score), 0) as AvgRating,
           COUNT(r.UID) as RatingCount
    FROM COMIC c
    LEFT JOIN ARTIST a ON c.AID = a.ID
    LEFT JOIN RATING r ON c.ID = r.Comic_ID
    WHERE c.ID = ?
    GROUP BY c.ID
");
$stmt->execute([$comicId]);
$comic = $stmt->fetch();

if (!$comic) { header('Location: index.php'); exit; }

// ── Fetch All Public Reviews ──────────────────────────
$stmt = $pdo->prepare("
    SELECT r.*, u.Name as UserName
    FROM RATING r
    JOIN USERS u ON r.UID = u.ID
    WHERE r.Comic_ID = ?
    ORDER BY r.TIME_STAMP DESC
");
$stmt->execute([$comicId]);
$reviews = $stmt->fetchAll();

$pageTitle = $comic['Title'] ?: $comic['Name'];

// Fetch genres
$stmt = $pdo->prepare("SELECT Genre FROM GENRE WHERE Comic_ID = ?");
$stmt->execute([$comicId]);
$genres = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Fetch chapters
$stmt = $pdo->prepare("
    SELECT * FROM CHAPTER
    WHERE Comic_ID = ? AND isPublished = TRUE
    ORDER BY ChapterNumber DESC
");
$stmt->execute([$comicId]);
$chapters = $stmt->fetchAll();

// ── Check for active livestream for this comic ────────
$liveStmt = $pdo->prepare("
    SELECT VideoURL, Title, AID
    FROM LIVESTREAM
    WHERE Comic_ID = ?
      AND StartTime <= NOW()
      AND (EndTime IS NULL OR EndTime > NOW())
    ORDER BY StartTime DESC
    LIMIT 1
");
$liveStmt->execute([$comicId]);
$liveStream = $liveStmt->fetch();

// ── Check if the logged-in artist owns this comic ─────
$artistOwnsComic = false;
if (isArtistLoggedIn()) {
    $artistId = (int)$_SESSION['user_id'];
    $ownerCheck = $pdo->prepare("SELECT ID FROM COMIC WHERE ID = ? AND AID = ?");
    $ownerCheck->execute([$comicId, $artistId]);
    $artistOwnsComic = (bool)$ownerCheck->fetch();
}

// ── Check if this artist is currently live on this comic
$artistIsLive = false;
if ($artistOwnsComic) {
    $artistIsLive = !empty($liveStream) && (int)$liveStream['AID'] === $artistId;
}

// Fetch characters
$stmt = $pdo->prepare("SELECT * FROM CHARACTERS WHERE Comic_ID = ? LIMIT 6");
$stmt->execute([$comicId]);
$characters = $stmt->fetchAll();

// Fetch public reviews
$stmt = $pdo->prepare("
    SELECT r.*, u.Name
    FROM RATING r
    JOIN USERS u ON r.UID = u.ID
    WHERE r.Comic_ID = ?
    ORDER BY r.TIME_STAMP DESC
");
$stmt->execute([$comicId]);
$publicReviews = $stmt->fetchAll();

function getThumbnail($hardCopyLink, $comicName) {
    if (!empty($hardCopyLink) && file_exists($hardCopyLink)) {
        return $hardCopyLink;
    }
    $slug = strtolower(str_replace(' ', '-', $comicName));
    $path = "assets/thumbnails/{$slug}.webp";
    if (file_exists($path)) {
        return $path;
    }
    return "assets/thumbnails/placeholder.webp";
}

require_once 'header.php';
?>

<style>
    .comic-detail {
        display: grid;
        grid-template-columns: 280px 1fr;
        gap: 40px;
        margin-bottom: 40px;
    }
    .comic-cover { position: sticky; top: 100px; }
    .comic-cover img { width: 100%; border-radius: var(--radius-lg); box-shadow: var(--shadow); }
    .comic-meta { display: flex; flex-direction: column; gap: 20px; }
    .comic-meta h1 { font-size: 2rem; color: var(--text-primary); }
    .meta-row { display: flex; flex-wrap: wrap; gap: 15px; align-items: center; }
    .meta-item { display: flex; align-items: center; gap: 8px; color: var(--text-secondary); }
    .genre-tags { display: flex; flex-wrap: wrap; gap: 10px; }
    .genre-tag { background: var(--bg-card); color: var(--text-primary); padding: 6px 15px; border-radius: 20px; font-size: 0.85rem; }
    .synopsis { background: var(--bg-card); padding: 20px; border-radius: var(--radius-lg); line-height: 1.8; color: var(--text-secondary); }
    .action-buttons { display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
    .chapters-section, .characters-section {
        background: var(--bg-card); border-radius: var(--radius-lg); padding: 25px; margin-bottom: 30px;
    }
    .chapters-section h2, .characters-section h2 {
        margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid var(--border-color);
    }
    .chapters-list { display: grid; gap: 10px; }
    .chapter-item {
        display: flex; justify-content: space-between; align-items: center;
        padding: 15px; background: var(--bg-secondary); border-radius: var(--radius-md); transition: var(--transition);
    }
    .chapter-item:hover { background: var(--bg-hover); }
    .chapter-title { font-weight: 500; }
    .chapter-meta { color: var(--text-muted); font-size: 0.85rem; }
    .characters-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 20px; }
    .character-card { text-align: center; padding: 20px; background: var(--bg-secondary); border-radius: var(--radius-md); }
    .character-avatar {
        width: 80px; height: 80px; border-radius: 50%; background: var(--accent-gradient);
        display: flex; align-items: center; justify-content: center;
        margin: 0 auto 15px; font-size: 2rem; color: var(--text-primary);
    }
    .character-name { font-weight: 600; margin-bottom: 5px; }

    /* Live button for users */
    .btn-live {
        display: inline-flex; align-items: center; gap: 8px;
        padding: 10px 20px; background: #ef4444; color: #fff;
        border-radius: var(--radius-md); font-weight: 700; font-size: 0.9rem;
        text-decoration: none; transition: background .2s;
        animation: live-pulse 2s ease-in-out infinite;
    }
    .btn-live:hover { background: #dc2626; }
    .live-dot-btn { width: 9px; height: 9px; background: #fff; border-radius: 50%; animation: blink 1s step-start infinite; }
    @keyframes blink { 50% { opacity: 0; } }
    @keyframes live-pulse {
        0%, 100% { box-shadow: 0 0 0 0 rgba(239,68,68,.45); }
        50%       { box-shadow: 0 0 0 8px rgba(239,68,68,0); }
    }

    /* Artist Go Live button */
    .btn-go-live-artist {
        display: inline-flex; align-items: center; gap: 8px;
        padding: 10px 20px; background: #ef4444; color: #fff;
        border: none; border-radius: var(--radius-md); font-weight: 700;
        font-size: 0.9rem; cursor: pointer; transition: background .2s;
        font-family: inherit;
    }
    .btn-go-live-artist:hover { background: #dc2626; }

    /* Artist End Live button */
    .btn-end-live {
        display: inline-flex; align-items: center; gap: 8px;
        padding: 10px 20px; background: #374151; color: #f87171;
        border: 1px solid #f87171; border-radius: var(--radius-md);
        font-weight: 700; font-size: 0.9rem; text-decoration: none;
        transition: all .2s;
    }
    .btn-end-live:hover { background: rgba(239,68,68,.15); }

    /* Go Live Modal */
    .live-modal-overlay {
        display: none; position: fixed; inset: 0;
        background: rgba(0,0,0,.85); backdrop-filter: blur(4px);
        z-index: 9999; align-items: center; justify-content: center;
    }
    .live-modal-box {
        background: var(--bg-secondary); padding: 30px;
        border-radius: var(--radius-lg); width: 90%; max-width: 460px;
        border: 1px solid var(--border-color);
    }
    .live-modal-box h3 { margin-bottom: 6px; font-size: 1.1rem; }
    .live-modal-box p  { color: var(--text-muted); font-size: 0.85rem; margin-bottom: 20px; }
    .lm-fg { margin-bottom: 16px; }
    .lm-fg label { display: block; font-size: 0.82rem; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; }
    .lm-fg input, .lm-fg select {
        width: 100%; padding: 10px 14px; background: var(--bg-card);
        border: 1px solid var(--border-color); border-radius: var(--radius-md);
        color: var(--text-primary); font-size: 0.9rem; font-family: inherit;
        box-sizing: border-box; transition: border-color .2s;
    }
    .lm-fg input:focus, .lm-fg select:focus { outline: none; border-color: #ef4444; }
    .lm-fg small { font-size: 0.75rem; color: var(--text-muted); margin-top: 4px; display: block; }
    .lm-actions { display: flex; gap: 10px; margin-top: 20px; }
    .btn-golive-submit {
        flex: 1; padding: 12px; background: #ef4444; color: #fff; border: none;
        border-radius: var(--radius-md); font-size: 0.95rem; font-weight: 700;
        cursor: pointer; font-family: inherit; transition: background .2s;
    }
    .btn-golive-submit:hover { background: #dc2626; }

    /* Toast */
    .page-toast {
        border-radius: var(--radius-md); padding: 12px 18px;
        margin-bottom: 22px; font-size: 0.88rem; font-weight: 500;
    }
    .toast-ok  { background: rgba(34,197,94,.12); border: 1px solid rgba(34,197,94,.3); color: #4ade80; }
    .toast-err { background: rgba(239,68,68,.12);  border: 1px solid rgba(239,68,68,.3); color: #f87171; }

    @media (max-width: 768px) {
        .comic-detail { grid-template-columns: 1fr; }
        .comic-cover { position: static; max-width: 200px; margin: 0 auto; }
    }
</style>

<?php if (isset($_GET['live'])): ?>
    <?php if ($_GET['live'] === 'started'): ?>
        <div class="page-toast toast-ok">🔴 You're live! Viewers can now see your stream on this comic's page.</div>
    <?php elseif ($_GET['live'] === 'ended'): ?>
        <div class="page-toast toast-err">⏹ Stream ended successfully.</div>
    <?php endif; ?>
<?php endif; ?>

<div class="comic-detail">
    <div class="comic-cover">
        <img src="<?php echo h(getThumbnail($comic['HardCopyLink'], $comic['Name'])); ?>"
             alt="<?php echo h($comic['Title'] ?: $comic['Name']); ?>">
    </div>

    <div class="comic-meta">
        <h1><?php echo h($comic['Title'] ?: $comic['Name']); ?></h1>

        <div class="meta-row">
            <button type="button" class="asura-rating-trigger" onclick="toggleRatingPopup(true)">
                <span class="star-icon">★</span>
                <span class="score-text"><?php echo number_format($comic['AvgRating'] ?? 0, 1); ?></span>
                <span class="rate-text">Rate</span>
            </button>
            <span style="color: var(--text-muted); font-size: 0.9rem; margin-left: 10px;">
                (<?php echo $comic['RatingCount']; ?> reviews)
            </span>
        </div>

        <div class="meta-row">
            <span class="meta-item"><strong>Author:</strong> <?php echo h($comic['ArtistName'] ?? 'Unknown'); ?></span>
            <span class="meta-item"><strong>Chapters:</strong> <?php echo count($chapters); ?></span>
        </div>

        <?php if (!empty($genres)): ?>
            <div class="genre-tags">
                <?php foreach ($genres as $genre): ?>
                    <span class="genre-tag"><?php echo h($genre); ?></span>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($comic['Synopsis'])): ?>
            <div class="synopsis">
                <strong>Synopsis:</strong><br><br>
                <?php echo nl2br(h($comic['Synopsis'])); ?>
            </div>
        <?php endif; ?>

        <div class="action-buttons">
            <?php if (!empty($chapters)): ?>
                <a href="reader.php?id=<?php echo $chapters[count($chapters)-1]['CHAPTER_ID']; ?>" class="btn btn-primary">
                    Read First Chapter
                </a>
                <a href="reader.php?id=<?php echo $chapters[0]['CHAPTER_ID']; ?>" class="btn btn-secondary">
                    Read Latest Chapter
                </a>
                <a href="community.php?id=<?php echo $comicId; ?>" class="btn btn-outline">
                    💬 Community
                </a>
            <?php endif; ?>

            <?php if ($artistOwnsComic): ?>
                <?php if ($artistIsLive): ?>
                    <!-- Artist is currently live: show End Live button -->
                    <a href="comic.php?id=<?php echo $comicId; ?>&end_live=1"
                       class="btn-end-live"
                       onclick="return confirm('End your current live stream?')">
                        ⏹ End Live
                    </a>
                <?php else: ?>
                    <!-- Artist is not live: show Go Live button -->
                    <button type="button" class="btn-go-live-artist" onclick="toggleLiveModal(true)">
                        🔴 Go Live
                    </button>
                <?php endif; ?>
            <?php else: ?>
                <?php if ($liveStream): ?>
                    <!-- Regular user: clicking Live takes them to comic-specific live page -->
                    <a href="livestream.php?comic_id=<?php echo $comicId; ?>"
                       class="btn-live">
                        <span class="live-dot-btn"></span>
                        LIVE
                    </a>
                <?php endif; ?>
            <?php endif; ?>

           <?php
            // ── Guide button logic ─────────────────────────────
            $guideFile   = "assets/guides/comic-{$comicId}.html";
            $guideExists = !empty($comic['PDF']) && file_exists($guideFile);
            ?>

            <?php if ($guideExists): ?>
                <!-- Anyone can read the guide if it exists -->
                <a href="view_guide.php?comic_id=<?php echo $comicId; ?>"
                   class="btn btn-outline"
                   style="display:inline-flex;align-items:center;gap:6px;">
                    📖 Reading Guide
                </a>
            <?php endif; ?>

            <?php if ($artistOwnsComic): ?>
                <!-- Artist sees an Edit / Create guide button -->
                <a href="create_guide.php?comic_id=<?php echo $comicId; ?>"
                   class="btn btn-outline"
                   style="display:inline-flex;align-items:center;gap:6px;
                          color:var(--accent-color,#818cf8);border-color:rgba(129,140,248,.4);">
                    <?php echo $guideExists ? '✏️ Edit Guide' : '📖 Create Guide'; ?>
                </a>
            <?php endif; ?>

        </div>
    </div>
</div>

<!-- ── Artist Go Live Modal ───────────────────────────── -->
<?php if ($artistOwnsComic && !$artistIsLive): ?>
<div id="goLiveModal" class="live-modal-overlay">
    <div class="live-modal-box">
        <h3>🔴 Go Live on <?php echo h($comic['Title'] ?: $comic['Name']); ?></h3>
        <p>Paste your YouTube Live URL and give your stream a title. Viewers will see a Live button on this comic page.</p>

        <form method="POST" action="comic.php?id=<?php echo $comicId; ?>">
            <input type="hidden" name="action" value="comic_go_live">

            <div class="lm-fg">
                <label>Stream Title</label>
                <input type="text" name="stream_title"
                       placeholder="e.g. Drawing Chapter <?php echo count($chapters) + 1; ?> Live!"
                       required>
            </div>

            <div class="lm-fg">
                <label>YouTube Live URL</label>
                <input type="url" name="video_url"
                       placeholder="https://youtube.com/live/..."
                       required>
                <small>Copy this from YouTube Studio → Go Live after you start streaming.</small>
            </div>

            <div class="lm-actions">
                <button type="submit" class="btn-golive-submit">🔴 GO LIVE NOW</button>
                <button type="button" class="btn btn-outline" onclick="toggleLiveModal(false)">Cancel</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- ── Rating Modal ───────────────────────────────────── -->
<div id="asuraRatingModal" class="rating-overlay">
    <div class="rating-modal-box">
        <?php if (isUserLoggedIn()): ?>
            <h3 style="margin-bottom: 5px;">Rate This Comic</h3>
            <p style="color: var(--text-secondary); font-size: 0.9rem;">Give it a score out of 10</p>
            <form method="POST" action="comic.php?id=<?php echo $comicId; ?>">
                <div class="star-rating-row">
                    <?php for($i=10; $i>=1; $i--): ?>
                        <input type="radio" id="star<?php echo $i; ?>" name="score" value="<?php echo $i; ?>" required>
                        <label for="star<?php echo $i; ?>">★</label>
                    <?php endfor; ?>
                </div>
                <textarea name="review_text" placeholder="Write a short review (optional)..."
                          maxlength="1000" style="width:100%; height:100px; background: #111; color: white; border: 1px solid #333; padding: 12px; border-radius: 8px; resize: none; margin-bottom: 20px;"></textarea>
                <div style="display: flex; gap: 10px;">
                    <button type="submit" name="submit_asura_rating" value="1" class="btn btn-primary" style="flex: 1;">Submit</button>
                    <button type="button" class="btn btn-secondary" style="flex: 1;" onclick="toggleRatingPopup(false)">Cancel</button>
                </div>
            </form>
        <?php else: ?>
            <h3 style="margin-bottom: 15px;">Login Required</h3>
            <p style="color: var(--text-secondary); font-size: 0.9rem; margin-bottom: 20px;">You must be logged in to rate and review comics.</p>
            <div style="display: flex; gap: 10px;">
                <a href="login_user.php" class="btn btn-primary" style="flex: 1;">Log in</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<section class="chapters-section">
    <h2>Chapters (<?php echo count($chapters); ?>)</h2>
    <div class="chapters-list">
        <?php foreach ($chapters as $chapter): ?>
            <a href="reader.php?id=<?php echo $chapter['CHAPTER_ID']; ?>" class="chapter-item">
                <span class="chapter-title">Chapter <?php echo $chapter['ChapterNumber']; ?></span>
                <span class="chapter-meta">
                    <?php echo $chapter['Date_of_Publication'] ? date('M j, Y', strtotime($chapter['Date_of_Publication'])) : 'N/A'; ?>
                </span>
            </a>
        <?php endforeach; ?>
        <?php if (empty($chapters)): ?>
            <p style="color: var(--text-muted); text-align: center; padding: 20px;">No chapters available yet.</p>
        <?php endif; ?>
    </div>
</section>

<?php
// ============================================================
// PASTE THIS BLOCK INTO comic.php
// Insert it AFTER the chapters-section closing </section> tag
// (after line 415, before the characters section)
//
// This block queries the prediction poll for the latest chapter
// and renders it for the user.
// ============================================================

// Fetch latest published chapter for this comic
$latestChapterStmt = $pdo->prepare("
    SELECT CHAPTER_ID, ChapterNumber 
    FROM CHAPTER 
    WHERE Comic_ID = ? AND isPublished = TRUE 
    ORDER BY ChapterNumber DESC 
    LIMIT 1
");
$latestChapterStmt->execute([$comicId]);
$latestChapter = $latestChapterStmt->fetch();

// Fetch prediction options for the latest chapter
$predOptions = [];
$pollResolved = false;
$userPrediction = null;
$totalVotes = 0;

if ($latestChapter) {
    $optStmt = $pdo->prepare("
        SELECT ID, Option_Number, OptionText, IsCorrect, IsResolved
        FROM PREDICTION_OPTION
        WHERE Chapter_ID = ?
        ORDER BY Option_Number ASC
    ");
    $optStmt->execute([$latestChapter['CHAPTER_ID']]);
    $predOptions = $optStmt->fetchAll();

    if (!empty($predOptions)) {
        $pollResolved = (bool)$predOptions[0]['IsResolved'];

        // Check if this user already predicted
        if (isUserLoggedIn()) {
            $myPredStmt = $pdo->prepare("
                SELECT p.Option_ID 
                FROM PREDICTION p
                JOIN PREDICTION_OPTION po ON p.Option_ID = po.ID
                WHERE po.Chapter_ID = ? AND p.UID = ?
            ");
            $myPredStmt->execute([$latestChapter['CHAPTER_ID'], $_SESSION['user_id']]);
            $myPred = $myPredStmt->fetch();
            $userPrediction = $myPred ? $myPred['Option_ID'] : null;
        }

        // Count total votes per option (for results display)
        $voteCountStmt = $pdo->prepare("
            SELECT po.ID, COUNT(p.ID) AS VoteCount
            FROM PREDICTION_OPTION po
            LEFT JOIN PREDICTION p ON po.ID = p.Option_ID
            WHERE po.Chapter_ID = ?
            GROUP BY po.ID
        ");
        $voteCountStmt->execute([$latestChapter['CHAPTER_ID']]);
        $voteCounts = [];
        foreach ($voteCountStmt->fetchAll() as $vc) {
            $voteCounts[$vc['ID']] = intval($vc['VoteCount']);
            $totalVotes += intval($vc['VoteCount']);
        }
    }
}
?>

<?php if (!empty($predOptions)): ?>
<section class="prediction-section">
    <div class="prediction-header">
        <h2>
            🔮 Chapter <?php echo $latestChapter['ChapterNumber']; ?> Prediction
            <?php if ($pollResolved): ?>
                <span class="poll-resolved-badge">Resolved</span>
            <?php else: ?>
                <span class="poll-open-badge">Open</span>
            <?php endif; ?>
        </h2>
        <p class="prediction-subtitle">
            <?php if ($pollResolved): ?>
                Results are in! See how your prediction compared.
            <?php else: ?>
                What do you think happens in the next chapter? Pick one — you cannot change it!
            <?php endif; ?>
        </p>
    </div>

    <?php if (!$pollResolved && !isUserLoggedIn()): ?>
        <div class="prediction-login-prompt">
            <p>You must be <a href="login_user.php">logged in</a> to make a prediction and earn coins.</p>
        </div>
    <?php endif; ?>

    <div class="prediction-options" id="predictionOptions">
        <?php foreach ($predOptions as $opt): ?>
            <?php
            $voteCount   = $voteCounts[$opt['ID']] ?? 0;
            $percent     = $totalVotes > 0 ? round(($voteCount / $totalVotes) * 100) : 0;
            $isMyPick    = ($userPrediction == $opt['ID']);
            $isCorrect   = (bool)$opt['IsCorrect'];

            // CSS state classes
            $optClass = 'prediction-option';
            if ($pollResolved && $isCorrect)          $optClass .= ' option-correct';
            elseif ($pollResolved && $isMyPick)       $optClass .= ' option-wrong-pick';
            elseif (!$pollResolved && $isMyPick)      $optClass .= ' option-selected';
            elseif ($pollResolved)                    $optClass .= ' option-neutral';
            ?>
            <div class="<?php echo $optClass; ?>"
                 <?php if (!$pollResolved && !$userPrediction && isUserLoggedIn()): ?>
                     onclick="selectOption(<?php echo $opt['ID']; ?>, this)"
                     role="button" tabindex="0"
                 <?php endif; ?>
                 data-option-id="<?php echo $opt['ID']; ?>">

                <div class="option-top-row">
                    <div class="option-text-wrap">
                        <?php if ($pollResolved && $isCorrect): ?>
                            <span class="option-badge badge-correct">✓ Correct</span>
                        <?php elseif ($pollResolved && $isMyPick && !$isCorrect): ?>
                            <span class="option-badge badge-wrong">✗ Your Pick</span>
                        <?php elseif ($isMyPick): ?>
                            <span class="option-badge badge-mypick">Your Pick</span>
                        <?php endif; ?>
                        <span class="option-number"><?php echo $opt['Option_Number']; ?>.</span>
                        <span class="option-text"><?php echo h($opt['OptionText']); ?></span>
                    </div>
                    <?php if ($pollResolved || $userPrediction): ?>
                        <span class="option-percent"><?php echo $percent; ?>%</span>
                    <?php endif; ?>
                </div>

                <?php if ($pollResolved || $userPrediction): ?>
                    <div class="option-bar-wrap">
                        <div class="option-bar" style="width: <?php echo $percent; ?>%;
                            background: <?php echo $isCorrect ? 'var(--success)' : ($isMyPick ? 'var(--accent-primary)' : 'var(--accent-secondary)'); ?>;
                        "></div>
                    </div>
                    <div class="option-vote-count"><?php echo $voteCount; ?> vote<?php echo $voteCount !== 1 ? 's' : ''; ?></div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <?php if (!$pollResolved && isUserLoggedIn() && !$userPrediction): ?>
        <div class="prediction-confirm-area" id="confirmArea" style="display:none;">
            <p class="confirm-warning">⚠️ Once you confirm, your prediction is locked and cannot be changed.</p>
            <button class="btn btn-primary" onclick="submitPrediction()">Confirm My Prediction</button>
            <button class="btn btn-outline" onclick="clearSelection()" style="margin-left: 10px;">Cancel</button>
        </div>
        <div id="predMessage" class="prediction-message" style="display:none;"></div>
    <?php endif; ?>

    <?php if ($userPrediction && !$pollResolved): ?>
        <p class="prediction-locked-msg">
            🔒 Your prediction is locked. Check back when the next chapter drops to see if you were right!
        </p>
    <?php endif; ?>

    <?php if ($pollResolved && $userPrediction): ?>
        <?php
        // Check if user's pick was correct
        $userWon = false;
        foreach ($predOptions as $opt) {
            if ($opt['ID'] == $userPrediction && $opt['IsCorrect']) $userWon = true;
        }
        ?>
        <?php if ($userWon): ?>
            <div class="prediction-result-banner result-win">
                🎉 You predicted correctly and earned <strong>1 coin</strong>!
                <a href="notifications.php" style="color: inherit; text-decoration: underline; margin-left: 5px;">View Notifications</a>
            </div>
        <?php else: ?>
            <div class="prediction-result-banner result-lose">
                Better luck next time! Check the next chapter's poll.
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <div class="prediction-footer">
        <span class="total-votes"><?php echo $totalVotes; ?> total prediction<?php echo $totalVotes !== 1 ? 's' : ''; ?> made</span>
        <span class="coin-reward-note">🪙 Correct predictions earn 1 coin</span>
    </div>
</section>
<?php endif; ?>

<script>
let selectedOptionId = null;

function selectOption(optionId, el) {
    // Clear previous selection
    document.querySelectorAll('.prediction-option').forEach(o => {
        o.classList.remove('option-selected');
    });
    
    // Select this one
    el.classList.add('option-selected');
    selectedOptionId = optionId;
    
    // Show confirm area
    document.getElementById('confirmArea').style.display = 'block';
}

function clearSelection() {
    document.querySelectorAll('.prediction-option').forEach(o => {
        o.classList.remove('option-selected');
    });
    selectedOptionId = null;
    document.getElementById('confirmArea').style.display = 'none';
}

function submitPrediction() {
    if (!selectedOptionId) return;
    
    const btn = document.querySelector('#confirmArea .btn-primary');
    btn.disabled = true;
    btn.textContent = 'Submitting...';

    fetch('prediction_submit.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `option_id=${selectedOptionId}`
    })
    .then(r => r.json())
    .then(data => {
        const msgEl = document.getElementById('predMessage');
        msgEl.style.display = 'block';
        msgEl.textContent   = data.message;
        msgEl.className     = 'prediction-message ' + (data.success ? 'msg-success' : 'msg-error');

        if (data.success) {
            document.getElementById('confirmArea').style.display = 'none';
            // Lock the selected option visually
            document.querySelectorAll('.prediction-option').forEach(o => {
                o.style.cursor = 'default';
                o.removeAttribute('onclick');
            });
        } else {
            btn.disabled    = false;
            btn.textContent = 'Confirm My Prediction';
        }
    })
    .catch(() => {
        const msgEl = document.getElementById('predMessage');
        msgEl.style.display = 'block';
        msgEl.textContent   = 'Network error. Please try again.';
        msgEl.className     = 'prediction-message msg-error';
        btn.disabled        = false;
        btn.textContent     = 'Confirm My Prediction';
    });
}
</script>

<?php if (!empty($characters)): ?>

<section class="characters-section">
    <h2>Characters</h2>
    <div class="characters-grid">
        <?php foreach ($characters as $character): ?>
            <div class="character-card">
                <div class="character-avatar"><?php echo mb_substr($character['Name'], 0, 1); ?></div>
                <div class="character-name"><?php echo h($character['Name']); ?></div>
                <?php if (!empty($character['Biography'])): ?>
                    <div style="color: var(--text-muted); font-size: 0.8rem;">
                        <?php echo h(substr($character['Biography'], 0, 50)); ?>...
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<section class="public-reviews-section">
    <div class="container">
        <h2>Community Reviews</h2>
        <div class="reviews-grid">
            <?php if (empty($reviews)): ?>
                <p style="color: var(--text-muted);">No reviews yet. Be the first to rate!</p>
            <?php else: ?>
                <?php foreach ($reviews as $row): ?>
                    <div class="review-display-card">
                        <div class="review-header">
                            <strong class="reviewer-name"><?php echo h($row['UserName']); ?></strong>
                            <span class="review-score" style="color: var(--warning);">
                                <?php echo number_format($row['Score'], 1); ?> ★
                            </span>
                        </div>
                        <p class="review-body"><?php echo h($row['ReviewText']); ?></p>
                        <div class="review-footer">
                            <small class="text-muted"><?php echo date('M j, Y', strtotime($row['TIME_STAMP'])); ?></small>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="community-preview-section" style="padding: 40px 0; border-top: 1px solid var(--border-color); margin-top: 20px;">
    <div class="container">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2>Community Discussions</h2>
            <a href="community.php?id=<?php echo $comicId; ?>" class="btn btn-outline" style="font-size: 0.9rem;">View All Posts</a>
        </div>
        <?php
        $stmt = $pdo->prepare("
            SELECT f.*, u.Name as UserName
            FROM FORUM_POST f
            JOIN USERS u ON f.UID = u.ID
            WHERE f.Comic_ID = ?
            ORDER BY f.TimeStamp DESC
            LIMIT 3
        ");
        $stmt->execute([$comicId]);
        $previewPosts = $stmt->fetchAll();
        ?>
        <div style="display: flex; flex-direction: column; gap: 15px;">
            <?php if (empty($previewPosts)): ?>
                <p style="color: var(--text-muted);">No discussions yet. Start the conversation in the community tab!</p>
            <?php else: ?>
                <?php foreach ($previewPosts as $post): ?>
                    <div style="background: var(--bg-card); border: 1px solid var(--border-color); padding: 15px; border-radius: var(--radius-md);">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                            <strong style="color: var(--accent-secondary);"><?php echo h($post['UserName']); ?></strong>
                            <small style="color: var(--text-muted);"><?php echo date('M j, g:i a', strtotime($post['TimeStamp'])); ?></small>
                        </div>
                        <p style="color: var(--text-secondary); margin: 0; line-height: 1.5;">
                            <?php echo h(mb_strimwidth($post['Content'], 0, 150, "...")); ?>
                        </p>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<script>
function toggleRatingPopup(show) {
    const modal = document.getElementById('asuraRatingModal');
    modal.style.display = show ? 'flex' : 'none';
    document.body.style.overflow = show ? 'hidden' : 'auto';
}

function toggleLiveModal(show) {
    const modal = document.getElementById('goLiveModal');
    if (!modal) return;
    modal.style.display = show ? 'flex' : 'none';
    document.body.style.overflow = show ? 'hidden' : 'auto';
}

window.onclick = function(event) {
    const ratingModal = document.getElementById('asuraRatingModal');
    if (event.target === ratingModal) toggleRatingPopup(false);

    const liveModal = document.getElementById('goLiveModal');
    if (liveModal && event.target === liveModal) toggleLiveModal(false);
}
</script>

<?php require_once 'footer.php'; ?>