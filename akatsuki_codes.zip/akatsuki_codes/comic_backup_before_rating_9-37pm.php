<?php
require_once 'db.php';

$comicId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$comicId) {
    header('Location: index.php');
    exit;
}

// Fetch comic information
$stmt = $pdo->prepare("
    SELECT 
        c.*,
        a.Name as ArtistName,
        COALESCE(AVG(r.Score), 0) as AvgRating,
        COUNT(DISTINCT r.UID) as RatingCount
    FROM COMIC c
    LEFT JOIN ARTIST a ON c.AID = a.ID
    LEFT JOIN RATING r ON c.ID = r.Comic_ID
    WHERE c.ID = ?
    GROUP BY c.ID
");
$stmt->execute([$comicId]);
$comic = $stmt->fetch();

if (!$comic) {
    header('Location: index.php');
    exit;
}

$pageTitle = $comic['Title'] ?: $comic['Name'];

// Fetch genres
$stmt = $pdo->prepare("SELECT Genre FROM GENRE WHERE Comic_ID = ?");
$stmt->execute([$comicId]);
$genres = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Fetch chapters
$stmt = $pdo->prepare("
    SELECT * FROM CHAPTER 
    WHERE Comic_ID = ? AND isPublished = TRUE
    ORDER BY ChapterNumber DESC
");
$stmt->execute([$comicId]);
$chapters = $stmt->fetchAll();

// Fetch characters
$stmt = $pdo->prepare("SELECT * FROM CHARACTERS WHERE Comic_ID = ? LIMIT 6");
$stmt->execute([$comicId]);
$characters = $stmt->fetchAll();

// Helper function to get thumbnail
function getThumbnail($hardCopyLink, $comicName) {
    if (!empty($hardCopyLink) && file_exists($hardCopyLink)) {
        return $hardCopyLink;
    }
    $slug = strtolower(str_replace(' ', '-', $comicName));
    $path = "assets/thumbnails/{$slug}.webp";
    if (file_exists($path)) {
        return $path;
    }
    return "assets/thumbnails/placeholder.webp";
}

// Render stars
function renderStars($rating) {
    $fullStars = floor($rating / 2);
    $halfStar = ($rating / 2) - $fullStars >= 0.5;
    $emptyStars = 5 - $fullStars - ($halfStar ? 1 : 0);
    
    $html = '';
    for ($i = 0; $i < $fullStars; $i++) $html .= '★';
    if ($halfStar) $html .= '☆';
    for ($i = 0; $i < $emptyStars; $i++) $html .= '☆';
    return $html;
}

require_once 'header.php';
?>

<style>
    .comic-detail {
        display: grid;
        grid-template-columns: 280px 1fr;
        gap: 40px;
        margin-bottom: 40px;
    }
    
    .comic-cover {
        position: sticky;
        top: 100px;
    }
    
    .comic-cover img {
        width: 100%;
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow);
    }
    
    .comic-meta {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }
    
    .comic-meta h1 {
        font-size: 2rem;
        color: var(--text-primary);
    }
    
    .meta-row {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        align-items: center;
    }
    
    .meta-item {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--text-secondary);
    }
    
    .genre-tags {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }
    
    .genre-tag {
        background: var(--bg-card);
        color: var(--text-primary);
        padding: 6px 15px;
        border-radius: 20px;
        font-size: 0.85rem;
    }
    
    .synopsis {
        background: var(--bg-card);
        padding: 20px;
        border-radius: var(--radius-lg);
        line-height: 1.8;
        color: var(--text-secondary);
    }
    
    .action-buttons {
        display: flex;
        gap: 15px;
    }
    
    .chapters-section,
    .characters-section {
        background: var(--bg-card);
        border-radius: var(--radius-lg);
        padding: 25px;
        margin-bottom: 30px;
    }
    
    .chapters-section h2,
    .characters-section h2 {
        margin-bottom: 20px;
        padding-bottom: 15px;
        border-bottom: 1px solid var(--border-color);
    }
    
    .chapters-list {
        display: grid;
        gap: 10px;
    }
    
    .chapter-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px;
        background: var(--bg-secondary);
        border-radius: var(--radius-md);
        transition: var(--transition);
    }
    
    .chapter-item:hover {
        background: var(--bg-hover);
    }
    
    .chapter-title {
        font-weight: 500;
    }
    
    .chapter-meta {
        color: var(--text-muted);
        font-size: 0.85rem;
    }
    
    .characters-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
        gap: 20px;
    }
    
    .character-card {
        text-align: center;
        padding: 20px;
        background: var(--bg-secondary);
        border-radius: var(--radius-md);
    }
    
    .character-avatar {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: var(--accent-gradient);
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 15px;
        font-size: 2rem;
        color: var(--text-primary);
    }
    
    .character-name {
        font-weight: 600;
        margin-bottom: 5px;
    }
    
    @media (max-width: 768px) {
        .comic-detail {
            grid-template-columns: 1fr;
        }
        
        .comic-cover {
            position: static;
            max-width: 200px;
            margin: 0 auto;
        }
    }
</style>

<div class="comic-detail">
    <div class="comic-cover">
        <img src="<?php echo h(getThumbnail($comic['HardCopyLink'], $comic['Name'])); ?>" 
             alt="<?php echo h($comic['Title'] ?: $comic['Name']); ?>">
    </div>
    
    <div class="comic-meta">
        <h1><?php echo h($comic['Title'] ?: $comic['Name']); ?></h1>
        
        <div class="meta-row">
            <span class="meta-item">
                <span class="stars" style="color: #ffc107;"><?php echo renderStars($comic['AvgRating']); ?></span>
                <span><?php echo number_format($comic['AvgRating'], 1); ?></span>
                <span>(<?php echo $comic['RatingCount']; ?> reviews)</span>
            </span>
        </div>
        
        <div class="meta-row">
            <span class="meta-item">
                <strong>Author:</strong> <?php echo h($comic['ArtistName'] ?? 'Unknown'); ?>
            </span>
            <span class="meta-item">
                <strong>Chapters:</strong> <?php echo count($chapters); ?>
            </span>
        </div>
        
        <?php if (!empty($genres)): ?>
            <div class="genre-tags">
                <?php foreach ($genres as $genre): ?>
                    <span class="genre-tag"><?php echo h($genre); ?></span>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($comic['Synopsis'])): ?>
            <div class="synopsis">
                <strong>Synopsis:</strong><br><br>
                <?php echo nl2br(h($comic['Synopsis'])); ?>
            </div>
        <?php endif; ?>
        
        <div class="action-buttons">
            <?php if (!empty($chapters)): ?>
                <a href="reader.php?id=<?php echo $chapters[count($chapters)-1]['CHAPTER_ID']; ?>" class="btn btn-primary">
                    Read First Chapter
                </a>
                <a href="reader.php?id=<?php echo $chapters[0]['CHAPTER_ID']; ?>" class="btn btn-secondary">
                    Read Latest Chapter
                </a>
            <?php endif; ?>
            
            <?php if (!empty($comic['HardCopyLink'])): ?>
                <a href="<?php echo h($comic['HardCopyLink']); ?>" class="btn btn-outline" target="_blank">
                    Buy Hard Copy
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Chapters Section -->
<section class="chapters-section">
    <h2>Chapters (<?php echo count($chapters); ?>)</h2>
    
    <div class="chapters-list">
        <?php foreach ($chapters as $chapter): ?>
            <a href="reader.php?id=<?php echo $chapter['CHAPTER_ID']; ?>" class="chapter-item">
                <span class="chapter-title">Chapter <?php echo $chapter['ChapterNumber']; ?></span>
                <span class="chapter-meta">
                    <?php echo $chapter['Date_of_Publication'] ? date('M j, Y', strtotime($chapter['Date_of_Publication'])) : 'N/A'; ?>
                </span>
            </a>
        <?php endforeach; ?>
        
        <?php if (empty($chapters)): ?>
            <p style="color: var(--text-muted); text-align: center; padding: 20px;">
                No chapters available yet.
            </p>
        <?php endif; ?>
    </div>
</section>

<!-- Characters Section -->
<?php if (!empty($characters)): ?>
<section class="characters-section">
    <h2>Characters</h2>
    
    <div class="characters-grid">
        <?php foreach ($characters as $character): ?>
            <div class="character-card">
                <div class="character-avatar">
                    <?php echo mb_substr($character['Name'], 0, 1); ?>
                </div>
                <div class="character-name"><?php echo h($character['Name']); ?></div>
                <?php if (!empty($character['Biography'])): ?>
                    <div class="character-bio" style="color: var(--text-muted); font-size: 0.8rem;">
                        <?php echo h(substr($character['Biography'], 0, 50)); ?>...
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<?php require_once 'footer.php'; ?>