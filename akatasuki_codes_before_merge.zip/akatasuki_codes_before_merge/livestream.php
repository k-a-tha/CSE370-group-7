<?php
//livestream.php
$pageTitle = 'Live Streams';
require_once 'header.php';

function ytId(string $url): ?string {
    $pattern = '/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i';
    if (preg_match($pattern, $url, $match)) {
        return $match[1];
    }
    return null;
}
function ytThumb(string $id): string {
    // hqdefault is more reliable than maxresdefault
    return "https://img.youtube.com/vi/{$id}/hqdefault.jpg";
}
function streamStatus(string $start, ?string $end): string {
    // If there is no EndTime, it is currently LIVE. Otherwise, it is PAST.
    if ($end === null) return 'live';
    return 'past';
}

// ── Comic filter ──────────────────────────────────────
$filterComicId = isset($_GET['comic_id']) ? intval($_GET['comic_id']) : 0;
$filterComic   = null;

if ($filterComicId) {
    $cs = $pdo->prepare("SELECT ID, COALESCE(Title, Name) AS Label, HardCopyLink, Name FROM COMIC WHERE ID = ?");
    $cs->execute([$filterComicId]);
    $filterComic = $cs->fetch();
    if (!$filterComic) $filterComicId = 0;
}

// ── Fetch streams ─────────────────────────────────────
if ($filterComicId) {
    $stmt = $pdo->prepare("
        SELECT l.AID, l.VideoURL, l.StartTime, l.EndTime, l.Title,
               a.Name AS ArtistName,
               c.ID   AS ComicID,
               COALESCE(c.Title, c.Name) AS ComicTitle
        FROM LIVESTREAM l
        JOIN ARTIST a ON l.AID      = a.ID
        JOIN COMIC  c ON l.Comic_ID = c.ID
        WHERE l.Comic_ID = ?
        ORDER BY l.StartTime DESC
    ");
    $stmt->execute([$filterComicId]);
    $rows = $stmt->fetchAll();
} else {
    $rows = $pdo->query("
        SELECT l.AID, l.VideoURL, l.StartTime, l.EndTime, l.Title,
               a.Name AS ArtistName,
               c.ID   AS ComicID,
               COALESCE(c.Title, c.Name) AS ComicTitle
        FROM LIVESTREAM l
        JOIN ARTIST a ON l.AID      = a.ID
        JOIN COMIC  c ON l.Comic_ID = c.ID
        ORDER BY l.StartTime DESC
    ")->fetchAll();
}

$live = $past = [];
foreach ($rows as $r) {
    if ($r['EndTime'] === null) {
        $live[] = $r;
    } else {
        $past[] = $r;
    }
}
?>

<style>
.ls-back-link {
    display: inline-flex; align-items: center; gap: 8px;
    color: var(--text-muted); font-size: 0.88rem; margin-bottom: 18px;
    text-decoration: none; transition: color .2s;
}
.ls-back-link:hover { color: var(--text-primary); }

.ls-filter-banner {
    display: flex; align-items: center; gap: 14px;
    background: var(--bg-card); border: 1px solid var(--border-color);
    border-radius: var(--radius-lg); padding: 16px 20px;
    margin-bottom: 28px;
}
.ls-filter-thumb {
    width: 48px; height: 64px; object-fit: cover;
    border-radius: var(--radius-sm); flex-shrink: 0;
}
.ls-filter-info { flex: 1; }
.ls-filter-title { font-weight: 700; color: var(--text-primary); font-size: 1rem; }
.ls-filter-sub   { font-size: 0.82rem; color: var(--text-muted); margin-top: 3px; }
.ls-filter-clear {
    padding: 6px 14px; background: transparent;
    border: 1px solid var(--border-color); border-radius: var(--radius-sm);
    color: var(--text-muted); font-size: 0.8rem; text-decoration: none;
    transition: all .2s; white-space: nowrap;
}
.ls-filter-clear:hover { border-color: var(--text-primary); color: var(--text-primary); }

.ls-hero { display:flex; align-items:center; gap:14px; margin-bottom:32px; }
.ls-hero h1 { font-size:1.9rem; color:var(--text-primary); }

.pulse-ring { position:relative; width:18px; height:18px; flex-shrink:0; }
.pulse-ring::before, .pulse-ring::after {
    content:''; position:absolute; inset:0; border-radius:50%; background:#ef4444;
}
.pulse-ring::after {
    animation:ripple 1.4s ease-out infinite;
    background:transparent; border:2px solid #ef4444;
}
@keyframes ripple { 0%{transform:scale(1);opacity:.8} 100%{transform:scale(2.4);opacity:0} }

.live-badge {
    background:#ef4444; color:#fff; font-size:0.72rem; font-weight:700;
    letter-spacing:.06em; padding:3px 10px; border-radius:20px;
}
.ls-label {
    font-size:0.72rem; font-weight:700; letter-spacing:.12em;
    text-transform:uppercase; color:var(--text-muted);
    margin-bottom:18px; display:flex; align-items:center; gap:10px;
}
.ls-label::after { content:''; flex:1; height:1px; background:var(--border-color); }
.ls-grid {
    display:grid; grid-template-columns:repeat(auto-fill,minmax(280px,1fr));
    gap:22px; margin-bottom:44px;
}
.ls-card {
    background:var(--bg-card); border:1px solid var(--border-color);
    border-radius:var(--radius-lg); overflow:hidden;
    cursor:pointer; transition:transform .2s,border-color .2s,box-shadow .2s;
    text-decoration:none; display:block; color:inherit;
}
.ls-card:hover {
    transform:translateY(-3px); border-color:rgba(239,68,68,.5);
    box-shadow:0 8px 28px rgba(239,68,68,.1);
}
.ls-card.past:hover { border-color:rgba(129,140,248,.4); box-shadow:none; }
.ls-thumb {
    position:relative; width:100%; padding-top:56.25%;
    background:#0a0a0a; overflow:hidden;
}
.ls-thumb img {
    position:absolute; inset:0; width:100%; height:100%;
    object-fit:cover; transition:transform .35s;
}
.ls-card:hover .ls-thumb img { transform:scale(1.04); }
.play-ov {
    position:absolute; inset:0; display:flex;
    align-items:center; justify-content:center;
    background:rgba(0,0,0,.28); opacity:0; transition:opacity .25s;
}
.ls-card:hover .play-ov { opacity:1; }
.play-btn {
    width:52px; height:52px; background:rgba(255,255,255,.92);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
}
.play-btn::after {
    content:''; border-style:solid; border-width:10px 0 10px 18px;
    border-color:transparent transparent transparent #ef4444; margin-left:3px;
}
.s-badge {
    position:absolute; top:10px; left:10px; padding:4px 10px; border-radius:20px;
    font-size:0.71rem; font-weight:700; letter-spacing:.06em;
    backdrop-filter:blur(6px); z-index:2;
}
.b-live     { background:rgba(239,68,68,.9);  color:#fff; }
.b-past     { background:rgba(20,20,20,.75);  color:#94a3b8; }
.ls-info { padding:14px 16px 16px; }
.ls-title {
    font-size:0.95rem; font-weight:700; color:var(--text-primary);
    line-height:1.35; margin-bottom:8px;
    white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
}
.ls-meta { font-size:0.8rem; color:var(--text-muted); display:flex; gap:8px; flex-wrap:wrap; align-items:center; }
.ls-comic { color:var(--accent-secondary,#818cf8); font-weight:600; }
.ls-time  { margin-top:6px; font-size:0.78rem; color:var(--text-muted); }
.ls-empty {
    padding:44px; text-align:center; color:var(--text-muted);
    background:var(--bg-card); border:1px dashed var(--border-color);
    border-radius:var(--radius-lg); margin-bottom:44px; font-size:0.9rem;
}
@media(max-width:600px) { .ls-grid { grid-template-columns:1fr; } }
</style>

<?php if ($filterComic): ?>
    <a href="comic.php?id=<?php echo $filterComicId; ?>" class="ls-back-link">← Back to comic</a>
    <div class="ls-filter-banner">
        <?php
        $slug  = strtolower(str_replace(' ', '-', $filterComic['Name']));
        $fthumb = !empty($filterComic['HardCopyLink']) ? $filterComic['HardCopyLink'] : "assets/thumbnails/{$slug}.webp";
        ?>
        <img src="<?php echo h($fthumb); ?>" alt="" class="ls-filter-thumb">
        <div class="ls-filter-info">
            <div class="ls-filter-title"><?php echo h($filterComic['Label']); ?> — Live Streams</div>
            <div class="ls-filter-sub">
                Showing <?php echo count($rows); ?> stream<?php echo count($rows) !== 1 ? 's' : ''; ?> for this comic
            </div>
        </div>
        <a href="livestream.php" class="ls-filter-clear">View all streams</a>
    </div>
<?php endif; ?>

<!-- Hero -->
<div class="ls-hero">
    <?php if (!empty($live)): ?>
        <span class="pulse-ring"></span>
        <span class="live-badge"><?php echo count($live); ?> LIVE</span>
    <?php endif; ?>
    <h1><?php echo $filterComic ? h($filterComic['Label']) . ' Streams' : 'Live Streams'; ?></h1>
</div>

<!-- LIVE NOW -->
<div class="ls-label">Live now</div>
<?php if (empty($live)): ?>
    <div class="ls-empty">
        <?php echo $filterComic
            ? 'No streams live right now for ' . h($filterComic['Label']) . ' — check back soon!'
            : 'No streams live right now — check back soon!'; ?>
    </div>
<?php else: ?>
<div class="ls-grid">
<?php foreach ($live as $s):
    $id = ytId($s['VideoURL']);
    $thumb = $id ? ytThumb($id) : 'assets/thumbnails/placeholder.webp';
    $isOwner = (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $s['AID']);
?>
    <a href="<?php echo h($s['VideoURL']); ?>" target="_blank" rel="noopener" class="ls-card">
        <div class="ls-thumb">
            <img src="<?php echo h($thumb); ?>" alt="<?php echo h($s['Title']); ?>" loading="lazy">
            <span class="s-badge b-live">🔴 LIVE</span>
            <div class="play-ov"><div class="play-btn"></div></div>
        </div>
        <div class="ls-info">
            <div class="ls-title"><?php echo h($s['Title']); ?></div>
            <div class="ls-meta">
                <span><?php echo h($s['ArtistName']); ?></span>·
                <a href="comic.php?id=<?php echo $s['ComicID']; ?>" class="ls-comic" onclick="event.stopPropagation()"><?php echo h($s['ComicTitle']); ?></a>
            </div>
            <div class="ls-time">Started <?php echo date('M j · g:i A', strtotime($s['StartTime'])); ?></div>
            
			<?php if ($isOwner): ?>
				<span style="background: rgba(129, 140, 248, 0.1); color: #818cf8; padding: 2px 6px; border-radius: 4px; font-size: 0.65rem; font-weight: 600; margin-left: 5px;">
					OWNER
				</span>
			<?php endif; ?>
		</div>
    </a>
<?php endforeach; ?>
</div>
<?php endif; ?>

<!-- PAST STREAMS (VODs) -->
<?php if (!empty($past)): ?>
<div class="ls-label" style="margin-top:40px;">Past streams</div>
<div class="ls-grid">
<?php foreach ($past as $s):
    $id = ytId($s['VideoURL']);
    $thumb = $id ? ytThumb($id) : 'assets/thumbnails/placeholder.webp';
    $isOwner = (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $s['AID']);
?>
    <a href="<?php echo h($s['VideoURL']); ?>" target="_blank" rel="noopener" class="ls-card past">
        <div class="ls-thumb" style="filter:grayscale(60%);">
            <img src="<?php echo h($thumb); ?>" alt="<?php echo h($s['Title']); ?>" loading="lazy">
            <span class="s-badge b-past">▶ PAST</span>
            <div class="play-ov"><div class="play-btn" style="background:rgba(255,255,255,.7);"></div></div>
        </div>
        <div class="ls-info">
            <div class="ls-title"><?php echo h($s['Title']); ?></div>
            <div class="ls-meta">
                <span><?php echo h($s['ArtistName']); ?></span>·
                <a href="comic.php?id=<?php echo $s['ComicID']; ?>" class="ls-comic" onclick="event.stopPropagation()"><?php echo h($s['ComicTitle']); ?></a>
            </div>
            <div class="ls-time">Ended <?php echo date('M j, Y', strtotime($s['EndTime'])); ?></div>
        </div>
    </a>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php require_once 'footer.php'; ?>