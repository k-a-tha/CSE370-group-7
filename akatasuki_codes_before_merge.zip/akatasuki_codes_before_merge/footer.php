    </main>
    <footer class="main-footer">
        <div class="footer-container">
            <div class="footer-brand">
                <a href="index.php" class="logo">
                    <span class="logo-text">AKATSUKI</span>
                </a>
                <p class="footer-desc">Your premier destination for Manga and Webtoons. Read the latest chapters from your favorite series.</p>
            </div>
            
            <div class="footer-links">
                <div class="footer-column">
                    <h4>Browse</h4>
                    <a href="index.php">HOME</a>
                    <a href="comics.php">COMICS</a>
					<a href="livestream.php">Live Streams</a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> All rights reserved.</p>
        </div>
    </footer>
    <script src="script.js"></script>
</body>
</html>
