<?php
// artist_go_live.php
session_start();
require_once 'db.php';

if (!isArtistLoggedIn()) {
    header('Location: login_user.php');
    exit;
}
$artistId = (int)$_SESSION['user_id'];

// ── GO LIVE ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'go_live') {
    $url     = trim($_POST['video_url'] ?? '');
    $title   = trim($_POST['title']     ?? '');
    $comicId = (int)($_POST['comic_id'] ?? 0);

    if ($url && $title && $comicId > 0) {
        $pdo->prepare("
            INSERT INTO LIVESTREAM (VideoURL, Title, StartTime, EndTime, AID, Comic_ID)
            VALUES (?, ?, NOW(), NULL, ?, ?)
            ON DUPLICATE KEY UPDATE
                Title     = VALUES(Title),
                StartTime = NOW(),
                EndTime   = NULL,
                AID       = VALUES(AID),
                Comic_ID  = VALUES(Comic_ID)
        ")->execute([$url, $title, $artistId, $comicId]);
    }
    header('Location: artist_go_live.php?ok=live');
    exit;
}

// ── END STREAM ────────────────────────────────────────
if (isset($_GET['end'])) {
    $pdo->prepare("UPDATE LIVESTREAM SET EndTime = NOW() WHERE VideoURL = ? AND AID = ?")
        ->execute([$_GET['end'], $artistId]);
    header('Location: artist_go_live.php?ok=ended');
    exit;
}

// ── DELETE ────────────────────────────────────────────
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM LIVESTREAM WHERE VideoURL = ? AND AID = ?")
        ->execute([$_GET['delete'], $artistId]);
    header('Location: artist_go_live.php?ok=deleted');
    exit;
}

// ── All comics ────────────────────────────────────────
$allComics = $pdo->query("
    SELECT ID, COALESCE(Title, Name) AS Label FROM COMIC ORDER BY Label
")->fetchAll();

// ── This artist's streams — status computed in MySQL so timezone can't drift ──
$myStreams = $pdo->prepare("
    SELECT
        l.VideoURL, l.Title, l.StartTime, l.EndTime,
        COALESCE(c.Title, c.Name) AS ComicTitle,
        CASE
            WHEN l.StartTime > NOW()                        THEN 'upcoming'
            WHEN l.EndTime IS NULL OR l.EndTime > NOW()     THEN 'live'
            ELSE 'past'
        END AS StreamStatus
    FROM LIVESTREAM l
    JOIN COMIC c ON l.Comic_ID = c.ID
    WHERE l.AID = ?
    ORDER BY l.StartTime DESC
")->execute([$artistId])
    ?: null;

// PDO::prepare returns a statement; re-do properly
$stmt = $pdo->prepare("
    SELECT
        l.VideoURL, l.Title, l.StartTime, l.EndTime,
        COALESCE(c.Title, c.Name) AS ComicTitle,
        CASE
            WHEN l.EndTime IS NULL THEN 'live'
            ELSE 'past'
        END AS StreamStatus
    FROM LIVESTREAM l
    JOIN COMIC c ON l.Comic_ID = c.ID
    WHERE l.AID = ?
    ORDER BY l.StartTime DESC
");
$stmt->execute([$artistId]);
$myStreams = $stmt->fetchAll();

function ytId(string $url): ?string {
    return preg_match(
        '/(?:youtube\.com\/(?:watch\?(?:.*&)?v=|live\/|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/',
        $url, $m
    ) ? $m[1] : null;
}

$pageTitle = 'Go Live';
require_once 'header.php';
?>

<style>
.gl-wrap    { max-width:860px; margin:0 auto; }
.gl-heading { font-size:1.7rem; color:var(--text-primary); margin-bottom:28px;
              display:flex; align-items:center; gap:12px; }

.gl-tabs { display:flex; gap:4px; margin-bottom:28px; border-bottom:1px solid var(--border-color); }
.gl-tab  { padding:10px 20px; border:none; background:none; color:var(--text-muted);
           cursor:pointer; font-size:0.9rem; font-family:inherit;
           border-bottom:2px solid transparent; margin-bottom:-1px; transition:all .2s; }
.gl-tab.active { color:var(--text-primary);
                 border-bottom-color:var(--accent-secondary,#818cf8); font-weight:600; }
.gl-tab-panel        { display:none; }
.gl-tab-panel.active { display:block; }

.gl-card { background:var(--bg-card); border:1px solid var(--border-color);
           border-radius:var(--radius-lg); padding:28px; margin-bottom:22px; }
.gl-card h3 { font-size:1rem; color:var(--text-primary); margin-bottom:20px;
              padding-bottom:14px; border-bottom:1px solid var(--border-color); }

.fg       { margin-bottom:16px; }
.fg label { display:block; font-size:0.82rem; font-weight:600;
            color:var(--text-secondary); margin-bottom:6px; }
.fg input, .fg select {
    width:100%; padding:10px 14px; background:var(--bg-secondary);
    border:1px solid var(--border-color); border-radius:var(--radius-md);
    color:var(--text-primary); font-size:0.9rem; font-family:inherit;
    transition:border-color .2s; box-sizing:border-box; }
.fg input:focus, .fg select:focus { outline:none; border-color:var(--accent-color,#818cf8); }
.fg small { font-size:0.75rem; color:var(--text-muted); margin-top:4px; display:block; }

.btn-golive { width:100%; padding:13px; background:#ef4444; color:#fff; border:none;
              border-radius:var(--radius-md); font-size:1rem; font-weight:700;
              cursor:pointer; transition:background .2s; letter-spacing:.02em; font-family:inherit; }
.btn-golive:hover { background:#dc2626; }

.toast { border-radius:var(--radius-md); padding:12px 18px;
         margin-bottom:22px; font-size:0.88rem; font-weight:500; }
.t-ok  { background:rgba(34,197,94,.12); border:1px solid rgba(34,197,94,.3); color:#4ade80; }

.stream-row { display:flex; align-items:center; gap:14px;
              padding:14px 0; border-bottom:1px solid var(--border-color); }
.stream-row:last-child { border-bottom:none; }
.sr-thumb   { width:80px; height:48px; object-fit:cover;
              border-radius:6px; flex-shrink:0; background:#111; }
.sr-body    { flex:1; min-width:0; }
.sr-title   { font-weight:600; color:var(--text-primary); font-size:0.9rem;
              white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sr-meta    { font-size:0.78rem; color:var(--text-muted); margin-top:3px; }
.sr-actions { display:flex; gap:8px; flex-shrink:0; }

.pill       { display:inline-block; padding:3px 10px; border-radius:20px;
              font-size:0.7rem; font-weight:700; letter-spacing:.05em; }
.p-live     { background:rgba(239,68,68,.18);  color:#f87171; }
.p-upcoming { background:rgba(234,179,8,.18);  color:#fbbf24; }
.p-past     { background:rgba(100,116,139,.2); color:#94a3b8; }

.btn-end { padding:5px 12px; background:rgba(239,68,68,.15);
           border:1px solid rgba(239,68,68,.35); color:#f87171;
           border-radius:var(--radius-sm); font-size:0.78rem; font-weight:600;
           text-decoration:none; transition:background .2s; }
.btn-end:hover { background:rgba(239,68,68,.28); }
.btn-del { padding:5px 12px; background:transparent;
           border:1px solid var(--border-color); color:var(--text-muted);
           border-radius:var(--radius-sm); font-size:0.78rem;
           text-decoration:none; transition:all .2s; }
.btn-del:hover { border-color:#f87171; color:#f87171; }
.empty-streams { padding:32px; text-align:center; color:var(--text-muted); font-size:0.9rem; }
</style>

<div class="gl-wrap">

<div class="gl-heading">🎥 Go Live</div>

<?php if (isset($_GET['ok'])): ?>
    <?php $msgs = ['live'      => 'You\'re live! Your stream is now visible to viewers.',
                   'ended'     => 'Stream ended.',
                   'deleted'   => 'Stream removed.',
                   'scheduled' => 'Stream scheduled!']; ?>
    <div class="toast t-ok">✓ <?php echo $msgs[$_GET['ok']] ?? 'Done.'; ?></div>
<?php endif; ?>

<div class="gl-tabs">
    <button class="gl-tab active" onclick="switchTab('now',this)">🔴 Go Live Now</button>
    <button class="gl-tab"        onclick="switchTab('streams',this)">
        My Streams
        <?php if (!empty($myStreams))
            echo '<span style="background:var(--border-color);padding:1px 7px;border-radius:10px;font-size:0.75rem;margin-left:4px;">'.count($myStreams).'</span>';
        ?>
    </button>
</div>

<!-- GO LIVE NOW -->
<div id="tab-now" class="gl-tab-panel active">
    <div class="gl-card">
        <h3>Start a stream right now</h3>
        <p style="color:var(--text-muted);font-size:0.88rem;margin-bottom:20px;line-height:1.6;">
            Start your YouTube stream first, then paste the link below. The stream goes live on the site immediately.
        </p>
        <form method="POST" action="artist_go_live.php">
            <input type="hidden" name="action" value="go_live">
            <div class="fg">
                <label>Stream Title</label>
                <input type="text" name="title" placeholder="e.g. Drawing Chapter 12 Live!" required>
            </div>
            <div class="fg">
                <label>YouTube Live URL</label>
                <input type="url" name="video_url" placeholder="https://youtube.com/live/..." required>
                <small>Copy from YouTube Studio → Go Live.</small>
            </div>
            <div class="fg">
                <label>Related Comic</label>
                <select name="comic_id" required>
                    <option value="">— Select a comic —</option>
                    <?php foreach ($allComics as $c): ?>
                        <option value="<?php echo $c['ID']; ?>"><?php echo h($c['Label']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn-golive">🔴 GO LIVE NOW</button>
        </form>
    </div>
</div>

<!-- SCHEDULE -->
<div id="tab-schedule" class="gl-tab-panel">
    <div class="gl-card">
        <h3>Schedule a future stream</h3>
        <p style="color:var(--text-muted);font-size:0.88rem;margin-bottom:20px;line-height:1.6;">
            Pick a future date and time. The stream will automatically show as Live when that time arrives.
        </p>
        <form method="POST" action="artist_go_live.php">
            <input type="hidden" name="action" value="schedule">
            <div class="fg">
                <label>Stream Title</label>
                <input type="text" name="title" placeholder="e.g. Chapter 13 Speed-draw" required>
            </div>
            <div class="fg">
                <label>YouTube URL</label>
                <input type="url" name="video_url" placeholder="https://youtube.com/live/..." required>
            </div>
            <div class="fg">
                <label>Related Comic</label>
                <select name="comic_id" required>
                    <option value="">— Select a comic —</option>
                    <?php foreach ($allComics as $c): ?>
                        <option value="<?php echo $c['ID']; ?>"><?php echo h($c['Label']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="fg">
                <label>Start Date &amp; Time</label>
                <input type="datetime-local" name="start_time" required>
                <small>Use a future date. The stream status will flip to Live automatically at this time.</small>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;">📅 Schedule Stream</button>
        </form>
    </div>
</div>

<!-- MY STREAMS -->
<div id="tab-streams" class="gl-tab-panel">
    <div class="gl-card">
        <h3>Your streams</h3>
        <?php if (empty($myStreams)): ?>
            <div class="empty-streams">No streams yet — go live!</div>
        <?php else: ?>
            <?php foreach ($myStreams as $s):
                $st  = $s['StreamStatus']; // computed by MySQL — no timezone drift
                $id  = ytId($s['VideoURL']);
                $th  = $id ? "https://img.youtube.com/vi/{$id}/defaulSt.jpg"
                           : 'assets/thumbnails/placeholder.webp';
                $pillLabel = match($st) {
                    'live'     => '🔴 LIVE',
                    default    => 'Past'
                };
            ?>
            <div class="stream-row">
                <img src="<?php echo h($th); ?>" class="sr-thumb" alt="">
                <div class="sr-body">
                    <div class="sr-title"><?php echo h($s['Title']); ?></div>
                    <div class="sr-meta">
                        <span class="pill p-<?php echo $st; ?>"><?php echo $pillLabel; ?></span>
                        &nbsp;<?php echo h($s['ComicTitle']); ?>
                        &nbsp;·&nbsp;<?php echo date('M j, Y · g:i A', strtotime($s['StartTime'])); ?>
                    </div>
                </div>
                <div class="sr-actions">
                    <?php if ($st === 'live'): ?>
                        <a href="artist_go_live.php?end=<?php echo urlencode($s['VideoURL']); ?>"
                           class="btn-end"
                           onclick="return confirm('End this stream?')">⏹ End</a>
                    <?php endif; ?>
                    <a href="<?php echo h($s['VideoURL']); ?>" target="_blank" class="btn-del">▶</a>
                    <a href="artist_go_live.php?delete=<?php echo urlencode($s['VideoURL']); ?>"
                       class="btn-del"
                       onclick="return confirm('Delete this stream?')">🗑</a>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

</div>

<script>
function switchTab(name, btn) {
    document.querySelectorAll('.gl-tab-panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.gl-tab').forEach(b => b.classList.remove('active'));
    document.getElementById('tab-' + name).classList.add('active');
    btn.classList.add('active');
}
// Auto-switch to My Streams tab after going live so the End button is visible
<?php if (isset($_GET['ok']) && $_GET['ok'] === 'live'): ?>
window.addEventListener('DOMContentLoaded', () => {
    const streamsBtn = document.querySelectorAll('.gl-tab')[2];
    switchTab('streams', streamsBtn);
});
<?php endif; ?>
</script>

<?php require_once 'footer.php'; ?>