<?php
require_once 'db.php';

$comicId = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$comicId) { header('Location: index.php'); exit; }

// Handle new post submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['post_content'])) {
    if (!isUserLoggedIn()) {
        header("Location: login_user.php");
        exit;
    }
    $content = trim($_POST['post_content']);
    if (!empty($content) && mb_strlen($content) <= 500) {
        $stmt = $pdo->prepare("
            INSERT INTO FORUM_POST (Content, TimeStamp, UID, Comic_ID)
            VALUES (?, NOW(), ?, ?)
        ");
        $stmt->execute([$content, $_SESSION['user_id'], $comicId]);
        header("Location: community.php?id=$comicId&posted=1");
        exit;
    }
}

// Handle post deletion (own posts only)
if (isset($_GET['delete']) && isUserLoggedIn()) {
    $postId = intval($_GET['delete']);
    $stmt = $pdo->prepare("DELETE FROM FORUM_POST WHERE ID = ? AND UID = ?");
    $stmt->execute([$postId, $_SESSION['user_id']]);
    header("Location: community.php?id=$comicId");
    exit;
}

// Fetch comic info
$stmt = $pdo->prepare("
    SELECT c.ID, c.Name, c.Title, c.HardCopyLink, c.Synopsis,
           a.Name as ArtistName,
           COALESCE(AVG(r.Score), 0) as AvgRating,
           COUNT(DISTINCT r.UID) as RatingCount
    FROM COMIC c
    LEFT JOIN ARTIST a ON c.AID = a.ID
    LEFT JOIN RATING r ON c.ID = r.Comic_ID
    WHERE c.ID = ?
    GROUP BY c.ID
");
$stmt->execute([$comicId]);
$comic = $stmt->fetch();
if (!$comic) { header('Location: index.php'); exit; }

// Fetch genres
$stmt = $pdo->prepare("SELECT Genre FROM GENRE WHERE Comic_ID = ?");
$stmt->execute([$comicId]);
$genres = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Sorting
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'newest';
$orderBy = $sort === 'oldest' ? 'fp.TimeStamp ASC' : 'fp.TimeStamp DESC';

// Fetch forum posts with user info and member count
$stmt = $pdo->prepare("
    SELECT fp.ID, fp.Content, fp.TimeStamp,
           u.ID as UserID, u.Name as UserName
    FROM FORUM_POST fp
    JOIN USERS u ON fp.UID = u.ID
    WHERE fp.Comic_ID = ?
    ORDER BY $orderBy
");
$stmt->execute([$comicId]);
$posts = $stmt->fetchAll();

// Total member count (unique posters)
$stmt = $pdo->prepare("SELECT COUNT(DISTINCT UID) as Members FROM FORUM_POST WHERE Comic_ID = ?");
$stmt->execute([$comicId]);
$memberCount = $stmt->fetchColumn();

function getThumbnail($hardCopyLink, $comicName) {
    if (!empty($hardCopyLink) && file_exists($hardCopyLink)) return $hardCopyLink;
    $slug = strtolower(str_replace(' ', '-', $comicName));
    $path = "assets/thumbnails/{$slug}.webp";
    if (file_exists($path)) return $path;
    return "assets/thumbnails/placeholder.webp";
}

function timeAgo($datetime) {
    $now  = new DateTime();
    $ago  = new DateTime($datetime);
    $diff = $now->diff($ago);
    if ($diff->y > 0) return $diff->y . 'y ago';
    if ($diff->m > 0) return $diff->m . 'mo ago';
    if ($diff->d > 0) return $diff->d . 'd ago';
    if ($diff->h > 0) return $diff->h . 'h ago';
    if ($diff->i > 0) return $diff->i . 'm ago';
    return 'just now';
}

$pageTitle = ($comic['Title'] ?: $comic['Name']) . ' — Community';
require_once 'header.php';
?>

<style>
/* ── Layout ───────────────────────────────────────────── */
.community-layout {
    display: grid;
    grid-template-columns: 1fr 300px;
    gap: 30px;
    align-items: start;
}

/* ── Banner ───────────────────────────────────────────── */
.community-banner {
    background: var(--bg-card);
    border-radius: var(--radius-lg);
    overflow: hidden;
    margin-bottom: 28px;
    border: 1px solid var(--border-color);
}

.banner-inner {
    display: flex;
    align-items: center;
    gap: 24px;
    padding: 24px;
}

.banner-cover {
    width: 90px;
    height: 120px;
    object-fit: cover;
    border-radius: var(--radius-md);
    flex-shrink: 0;
    box-shadow: var(--shadow);
}

.banner-info { flex: 1; min-width: 0; }

.banner-title {
    font-size: 1.6rem;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 6px;
}

.banner-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    align-items: center;
    margin-bottom: 12px;
    font-size: 0.85rem;
    color: var(--text-muted);
}

.banner-meta span { display: flex; align-items: center; gap: 5px; }

.genre-badges { display: flex; flex-wrap: wrap; gap: 7px; }

.genre-badge {
    background: rgba(var(--accent-rgb, 99,102,241), 0.15);
    color: var(--accent-color, #818cf8);
    border: 1px solid rgba(var(--accent-rgb, 99,102,241), 0.3);
    padding: 3px 12px;
    border-radius: 20px;
    font-size: 0.78rem;
    font-weight: 500;
}

.banner-actions { display: flex; gap: 10px; margin-top: 14px; }

/* ── Compose Box ──────────────────────────────────────── */
.compose-card {
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-lg);
    padding: 22px;
    margin-bottom: 24px;
}

.compose-card h3 {
    font-size: 1rem;
    margin-bottom: 14px;
    color: var(--text-primary);
}

.compose-textarea {
    width: 100%;
    min-height: 100px;
    background: var(--bg-secondary);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    color: var(--text-primary);
    padding: 12px 15px;
    resize: vertical;
    font-family: inherit;
    font-size: 0.95rem;
    transition: border-color 0.2s;
    box-sizing: border-box;
}

.compose-textarea:focus {
    outline: none;
    border-color: var(--accent-color, #818cf8);
}

.compose-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 12px;
}

.char-counter {
    font-size: 0.8rem;
    color: var(--text-muted);
}

.char-counter.warn { color: #f59e0b; }
.char-counter.over { color: #ef4444; }

.login-prompt {
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-lg);
    padding: 22px;
    margin-bottom: 24px;
    text-align: center;
    color: var(--text-muted);
}

.login-prompt a { color: var(--accent-color, #818cf8); font-weight: 600; }

/* ── Post Controls ────────────────────────────────────── */
.posts-controls {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
}

.posts-count {
    font-weight: 600;
    color: var(--text-primary);
}

.sort-tabs { display: flex; gap: 6px; }

.sort-tab {
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 0.82rem;
    color: var(--text-muted);
    text-decoration: none;
    border: 1px solid transparent;
    transition: all 0.2s;
}

.sort-tab:hover, .sort-tab.active {
    background: var(--bg-card);
    border-color: var(--border-color);
    color: var(--text-primary);
}

/* ── Posts ────────────────────────────────────────────── */
.post-card {
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-lg);
    padding: 20px;
    margin-bottom: 16px;
    transition: border-color 0.2s;
}

.post-card:hover { border-color: rgba(var(--accent-rgb, 99,102,241), 0.4); }

.post-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 14px;
}

.avatar {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.1rem;
    font-weight: 700;
    color: white;
    flex-shrink: 0;
    text-transform: uppercase;
}

.post-author-info { flex: 1; }

.post-author {
    font-weight: 600;
    color: var(--text-primary);
    font-size: 0.95rem;
}

.post-time {
    font-size: 0.78rem;
    color: var(--text-muted);
    margin-top: 1px;
}

.post-delete {
    background: none;
    border: none;
    color: var(--text-muted);
    cursor: pointer;
    font-size: 0.78rem;
    padding: 4px 8px;
    border-radius: var(--radius-sm);
    transition: all 0.2s;
    text-decoration: none;
}

.post-delete:hover { color: #ef4444; background: rgba(239,68,68,0.1); }

.post-content {
    color: var(--text-secondary);
    line-height: 1.75;
    white-space: pre-wrap;
    word-break: break-word;
    font-size: 0.95rem;
}

.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: var(--text-muted);
    background: var(--bg-card);
    border: 1px dashed var(--border-color);
    border-radius: var(--radius-lg);
}

.empty-state .empty-icon { font-size: 3rem; margin-bottom: 12px; }

/* ── Sidebar ──────────────────────────────────────────── */
.community-sidebar { position: sticky; top: 90px; }

.sidebar-card {
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-lg);
    padding: 20px;
    margin-bottom: 20px;
}

.sidebar-card h4 {
    font-size: 0.8rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: var(--text-muted);
    margin-bottom: 16px;
    padding-bottom: 10px;
    border-bottom: 1px solid var(--border-color);
}

.stat-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
    border-bottom: 1px solid rgba(var(--border-rgb, 255,255,255), 0.05);
    font-size: 0.88rem;
}

.stat-row:last-child { border-bottom: none; }
.stat-label { color: var(--text-muted); }
.stat-value { font-weight: 600; color: var(--text-primary); }

.rules-list {
    list-style: none;
    padding: 0;
    margin: 0;
    counter-reset: rules;
}

.rules-list li {
    counter-increment: rules;
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 8px 0;
    font-size: 0.88rem;
    color: var(--text-secondary);
    border-bottom: 1px solid rgba(var(--border-rgb, 255,255,255), 0.05);
}

.rules-list li:last-child { border-bottom: none; }

.rules-list li::before {
    content: counter(rules);
    background: rgba(var(--accent-rgb, 99,102,241), 0.2);
    color: var(--accent-color, #818cf8);
    width: 22px;
    height: 22px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.75rem;
    font-weight: 700;
    flex-shrink: 0;
}

.success-toast {
    background: rgba(34,197,94,0.15);
    border: 1px solid rgba(34,197,94,0.3);
    color: #4ade80;
    border-radius: var(--radius-md);
    padding: 12px 18px;
    margin-bottom: 20px;
    font-size: 0.9rem;
}

@media (max-width: 900px) {
    .community-layout { grid-template-columns: 1fr; }
    .community-sidebar { position: static; }
}

@media (max-width: 600px) {
    .banner-inner { flex-direction: column; text-align: center; }
    .genre-badges { justify-content: center; }
    .banner-actions { justify-content: center; }
}
</style>

<!-- Banner -->
<div class="community-banner">
    <div class="banner-inner">
        <img src="<?php echo h(getThumbnail($comic['HardCopyLink'], $comic['Name'])); ?>"
             alt="<?php echo h($comic['Title'] ?: $comic['Name']); ?>"
             class="banner-cover">
        <div class="banner-info">
            <div class="banner-title">
                <?php echo h($comic['Title'] ?: $comic['Name']); ?> Community
            </div>
            <div class="banner-meta">
                <span>💬 <?php echo count($posts); ?> posts</span>
                <span>👥 <?php echo $memberCount; ?> members</span>
                <span>⭐ <?php echo number_format($comic['AvgRating'], 1); ?> avg rating</span>
                <?php if ($comic['ArtistName']): ?>
                    <span>✏️ <?php echo h($comic['ArtistName']); ?></span>
                <?php endif; ?>
            </div>
            <?php if (!empty($genres)): ?>
                <div class="genre-badges">
                    <?php foreach ($genres as $g): ?>
                        <span class="genre-badge"><?php echo h($g); ?></span>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <div class="banner-actions">
                <a href="comic.php?id=<?php echo $comicId; ?>" class="btn btn-outline">← Back to Comic</a>
            </div>
        </div>
    </div>
</div>

<div class="community-layout">
    <!-- Main Feed -->
    <div class="community-main">

        <?php if (isset($_GET['posted'])): ?>
            <div class="success-toast">✓ Your post has been published!</div>
        <?php endif; ?>

        <!-- Compose -->
        <?php if (isUserLoggedIn()): ?>
            <div class="compose-card">
                <h3>Share your thoughts about <?php echo h($comic['Title'] ?: $comic['Name']); ?></h3>
                <form method="POST" action="community.php?id=<?php echo $comicId; ?>">
                    <textarea 
                        name="post_content"
                        class="compose-textarea"
                        placeholder="What are your thoughts? Theories, reactions, fan discussions — all welcome!"
                        maxlength="500"
                        id="postTextarea"
                        required></textarea>
                    <div class="compose-footer">
                        <span class="char-counter" id="charCounter">0 / 500</span>
                        <button type="submit" class="btn btn-primary">Post</button>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <div class="login-prompt">
                <p>💬 <a href="login_user.php">Sign in</a> to join the community and post your thoughts!</p>
            </div>
        <?php endif; ?>

        <!-- Posts list -->
        <div class="posts-controls">
            <span class="posts-count"><?php echo count($posts); ?> Post<?php echo count($posts) !== 1 ? 's' : ''; ?></span>
            <div class="sort-tabs">
                <a href="?id=<?php echo $comicId; ?>&sort=newest" 
                   class="sort-tab <?php echo $sort !== 'oldest' ? 'active' : ''; ?>">Newest</a>
                <a href="?id=<?php echo $comicId; ?>&sort=oldest" 
                   class="sort-tab <?php echo $sort === 'oldest' ? 'active' : ''; ?>">Oldest</a>
            </div>
        </div>

        <?php if (empty($posts)): ?>
            <div class="empty-state">
                <div class="empty-icon">💬</div>
                <h3 style="color: var(--text-secondary); margin-bottom: 8px;">No posts yet</h3>
                <p>Be the first to start a discussion about <?php echo h($comic['Title'] ?: $comic['Name']); ?>!</p>
            </div>
        <?php else: ?>
            <?php foreach ($posts as $post): ?>
                <div class="post-card">
                    <div class="post-header">
                        <div class="avatar">
                            <?php echo mb_substr($post['UserName'], 0, 1); ?>
                        </div>
                        <div class="post-author-info">
                            <div class="post-author"><?php echo h($post['UserName']); ?></div>
                            <div class="post-time"><?php echo timeAgo($post['TimeStamp']); ?> · <?php echo date('M j, Y', strtotime($post['TimeStamp'])); ?></div>
                        </div>
                        <?php if (isUserLoggedIn() && $_SESSION['user_id'] == $post['UserID']): ?>
                            <a href="community.php?id=<?php echo $comicId; ?>&delete=<?php echo $post['ID']; ?>"
                               class="post-delete"
                               onclick="return confirm('Delete this post?')">🗑 Delete</a>
                        <?php endif; ?>
                    </div>
                    <div class="post-content"><?php echo h($post['Content']); ?></div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Sidebar -->
    <aside class="community-sidebar">
        <!-- Stats -->
        <div class="sidebar-card">
            <h4>Community Stats</h4>
            <div class="stat-row">
                <span class="stat-label">Total Posts</span>
                <span class="stat-value"><?php echo count($posts); ?></span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Members</span>
                <span class="stat-value"><?php echo $memberCount; ?></span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Avg Rating</span>
                <span class="stat-value"><?php echo number_format($comic['AvgRating'], 1); ?> / 10</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Total Reviews</span>
                <span class="stat-value"><?php echo $comic['RatingCount']; ?></span>
            </div>
        </div>

        <!-- Rules -->
        <div class="sidebar-card">
            <h4>Community Rules</h4>
            <ul class="rules-list">
                <li>Be respectful to other members</li>
                <li>No spoilers without warning</li>
                <li>Stay on topic for this comic</li>
                <li>No spam or self-promotion</li>
                <li>Have fun and enjoy the discussion!</li>
            </ul>
        </div>

        <!-- Quick links -->
        <div class="sidebar-card">
            <h4>Quick Links</h4>
            <div style="display: flex; flex-direction: column; gap: 8px;">
                <a href="comic.php?id=<?php echo $comicId; ?>" class="btn btn-outline" style="text-align:center; width:100%; box-sizing:border-box;">Comic Details</a>
                <a href="comics.php" class="btn btn-outline" style="text-align:center; width:100%; box-sizing:border-box;">All Comics</a>
            </div>
        </div>
    </aside>
</div>

<script>
const textarea = document.getElementById('postTextarea');
const counter  = document.getElementById('charCounter');
if (textarea) {
    textarea.addEventListener('input', () => {
        const len = textarea.value.length;
        counter.textContent = len + ' / 500';
        counter.className = 'char-counter' + (len > 450 ? (len >= 500 ? ' over' : ' warn') : '');
    });
}
</script>

<?php require_once 'footer.php'; ?>
