<?php
// prediction_submit.php
// AJAX endpoint - returns JSON only, no HTML output
// Called via fetch() from the prediction poll on comic.php

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';

// ---- Auth check ----
$isUser = isset($_SESSION['user_id']) && isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'user';
if (!$isUser) {
    echo json_encode(['success' => false, 'message' => 'You must be logged in as a user to make predictions.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

$optionId = intval($_POST['option_id'] ?? 0);
$userId   = intval($_SESSION['user_id']);

if (!$optionId) {
    echo json_encode(['success' => false, 'message' => 'Please select an option before confirming.']);
    exit;
}

// ---- Fetch and validate the option ----
$stmt = $pdo->prepare("
    SELECT 
        po.ID,
        po.Chapter_ID,
        po.IsResolved,
        po.OptionText,
        ch.Comic_ID,
        ch.ChapterNumber,
        c.Name  AS ComicName,
        c.Title AS ComicTitle
    FROM PREDICTION_OPTION po
    JOIN CHAPTER ch ON po.Chapter_ID = ch.CHAPTER_ID
    JOIN COMIC   c  ON ch.Comic_ID   = c.ID
    WHERE po.ID = ?
");
$stmt->execute([$optionId]);
$option = $stmt->fetch();

if (!$option) {
    echo json_encode(['success' => false, 'message' => 'The selected option does not exist.']);
    exit;
}

if ($option['IsResolved']) {
    echo json_encode(['success' => false, 'message' => 'This prediction poll has already closed.']);
    exit;
}

// ---- Only allow predictions on the latest published chapter ----
$latestStmt = $pdo->prepare("
    SELECT CHAPTER_ID 
    FROM CHAPTER 
    WHERE Comic_ID = ? AND isPublished = TRUE 
    ORDER BY ChapterNumber DESC 
    LIMIT 1
");
$latestStmt->execute([$option['Comic_ID']]);
$latest = $latestStmt->fetch();

if (!$latest || $latest['CHAPTER_ID'] != $option['Chapter_ID']) {
    echo json_encode(['success' => false, 'message' => 'Predictions are only available for the latest chapter.']);
    exit;
}

// ---- Check if user already predicted for this chapter (any option) ----
// Note: UNIQUE(Option_ID, UID) only prevents re-picking the same option.
// This query enforces one prediction per user per CHAPTER across all options.
$checkStmt = $pdo->prepare("
    SELECT p.ID 
    FROM PREDICTION p
    JOIN PREDICTION_OPTION po ON p.Option_ID = po.ID
    WHERE po.Chapter_ID = ? AND p.UID = ?
");
$checkStmt->execute([$option['Chapter_ID'], $userId]);

if ($checkStmt->fetch()) {
    echo json_encode(['success' => false, 'message' => 'You have already made a prediction for this chapter. It cannot be changed.']);
    exit;
}

// ---- Lock in the prediction ----
$insertStmt = $pdo->prepare("
    INSERT INTO PREDICTION (Option_ID, UID, TimeStamp)
    VALUES (?, ?, NOW())
");

try {
    $insertStmt->execute([$optionId, $userId]);
    $comicTitle = $option['ComicTitle'] ?: $option['ComicName'];
    echo json_encode([
        'success'    => true,
        'message'    => "Prediction locked! You chose: \"{$option['OptionText']}\". You cannot change this.",
        'option_id'  => $optionId,
        'comic'      => $comicTitle,
        'chapter_no' => $option['ChapterNumber']
    ]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Failed to save your prediction. Please try again.']);
}
