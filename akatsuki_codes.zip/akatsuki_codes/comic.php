<?php
// require_once 'db.php';

// $comicId = isset($_GET['id']) ? intval($_GET['id']) : 0;

// if (!$comicId) {
    // header('Location: index.php');
    // exit;
// }

// Handle the Rating/Review submission
// if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_asura_rating'])) {
    // Only process if user is logged in
    // if (isset($_SESSION['user_id'])) {
        // $score = floatval($_POST['score']);
        // $review = trim($_POST['eviewText']);
        
        // $stmt = $pdo->prepare("
            // INSERT INTO RATING (UID, Comic_ID, Score, ReviewText, TIME_STAMP) 
            // VALUES (?, ?, ?, ?, NOW()) 
            // ON DUPLICATE KEY UPDATE 
                // Score = VALUES(Score), 
                // ReviewText = VALUES(ReviewText), 
                // TIME_STAMP = NOW()
        // ");
        // $stmt->execute([$_SESSION['user_id'], $comicId, $score, $review]);
        
        // header("Location: comic.php?id=$comicId");
        // exit;
    // } 
	// else {
        //Redirect to login if a guest tries to submit
        // header("Location: login_user.php");
        // exit;
    // }
// }

//Fetch comic information
// $stmt = $pdo->prepare("
    // SELECT 
        // c.*,
        // a.Name as ArtistName,
        // COALESCE(AVG(r.Score), 0) as AvgRating,
        // COUNT(DISTINCT r.UID) as RatingCount
    // FROM COMIC c
    // LEFT JOIN ARTIST a ON c.AID = a.ID
    // LEFT JOIN RATING r ON c.ID = r.Comic_ID
    // WHERE c.ID = ?
    // GROUP BY c.ID
// ");
// $stmt->execute([$comicId]);
// $comic = $stmt->fetch();

// if (!$comic) {
    // header('Location: index.php');
    // exit;
// }
session_start();
require_once 'db.php';

$comicId = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$comicId) { header('Location: index.php'); exit; }

// --- 1. Submission Logic (The Upsert) ---
// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Temporary debug - remove after fixing
    // error_log("POST received. Data: " . print_r($_POST, true));
    // error_log("Session: " . print_r($_SESSION, true));
    // error_log("Comic ID: " . $comicId);
    // die(json_encode([
        // 'post' => $_POST,
        // 'session_user_id' => $_SESSION['user_id'] ?? 'NOT SET',
        // 'comic_id' => $comicId,
        // 'submit_button_present' => isset($_POST['submit_asura_rating']) ? 'YES' : 'NO',
    // ]));
// }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['score'])) {
    if (isUserLoggedIn()) {
        $score = floatval($_POST['score']);
        $review = isset($_POST['review_text']) ? trim($_POST['review_text']) : '';
        
        $stmt = $pdo->prepare("
            INSERT INTO RATING (UID, Comic_ID, Score, ReviewText, TIME_STAMP) 
            VALUES (?, ?, ?, ?, NOW()) 
            ON DUPLICATE KEY UPDATE 
                Score = VALUES(Score), 
                ReviewText = VALUES(ReviewText), 
                TIME_STAMP = NOW()
        ");
        $stmt->execute([$_SESSION['user_id'], $comicId, $score, $review]);
        header("Location: comic.php?id=$comicId&status=success");
        exit;
    }
}

//--- 2. Fetch Comic Data & Structured Aggregates ---
$stmt = $pdo->prepare("
    SELECT c.*, a.Name as ArtistName,
           COALESCE(AVG(r.Score), 0) as AvgRating,
           COUNT(r.UID) as RatingCount
    FROM COMIC c
    LEFT JOIN ARTIST a ON c.AID = a.ID  /* Changed Artist_ID to AID */
    LEFT JOIN RATING r ON c.ID = r.Comic_ID
    WHERE c.ID = ?
    GROUP BY c.ID
");
 $stmt->execute([$comicId]);
 $comic = $stmt->fetch();

// --- 3. Fetch All Public Reviews ---
$stmt = $pdo->prepare("
    SELECT r.*, u.Name as UserName 
    FROM RATING r 
    JOIN USERS u ON r.UID = u.ID 
    WHERE r.Comic_ID = ? 
    ORDER BY r.TIME_STAMP DESC
");
$stmt->execute([$comicId]);
$reviews = $stmt->fetchAll();

// upto this, newly added

$pageTitle = $comic['Title'] ?: $comic['Name'];

// Fetch genres
$stmt = $pdo->prepare("SELECT Genre FROM GENRE WHERE Comic_ID = ?");
$stmt->execute([$comicId]);
$genres = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Fetch chapters
$stmt = $pdo->prepare("
    SELECT * FROM CHAPTER 
    WHERE Comic_ID = ? AND isPublished = TRUE
    ORDER BY ChapterNumber DESC
");
$stmt->execute([$comicId]);
$chapters = $stmt->fetchAll();

// Fetch characters
$stmt = $pdo->prepare("SELECT * FROM CHARACTERS WHERE Comic_ID = ? LIMIT 6");
$stmt->execute([$comicId]);
$characters = $stmt->fetchAll();

// Fetch all public reviews for this comic
$stmt = $pdo->prepare("
    SELECT r.*, u.Name 
    FROM RATING r 
    JOIN USERS u ON r.UID = u.ID 
    WHERE r.Comic_ID = ? 
    ORDER BY r.TIME_STAMP DESC
");
$stmt->execute([$comicId]);
$publicReviews = $stmt->fetchAll();

// Helper function to get thumbnail
function getThumbnail($hardCopyLink, $comicName) {
    if (!empty($hardCopyLink) && file_exists($hardCopyLink)) {
        return $hardCopyLink;
    }
    $slug = strtolower(str_replace(' ', '-', $comicName));
    $path = "assets/thumbnails/{$slug}.webp";
    if (file_exists($path)) {
        return $path;
    }
    return "assets/thumbnails/placeholder.webp";
}

require_once 'header.php';
?>

<style>
    .comic-detail {
        display: grid;
        grid-template-columns: 280px 1fr;
        gap: 40px;
        margin-bottom: 40px;
    }
    
    .comic-cover {
        position: sticky;
        top: 100px;
    }
    
    .comic-cover img {
        width: 100%;
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow);
    }
    
    .comic-meta {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }
    
    .comic-meta h1 {
        font-size: 2rem;
        color: var(--text-primary);
    }
    
    .meta-row {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        align-items: center;
    }
    
    .meta-item {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--text-secondary);
    }
    
    .genre-tags {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }
    
    .genre-tag {
        background: var(--bg-card);
        color: var(--text-primary);
        padding: 6px 15px;
        border-radius: 20px;
        font-size: 0.85rem;
    }
    
    .synopsis {
        background: var(--bg-card);
        padding: 20px;
        border-radius: var(--radius-lg);
        line-height: 1.8;
        color: var(--text-secondary);
    }
    
    .action-buttons {
        display: flex;
        gap: 15px;
    }
    
    .chapters-section,
    .characters-section {
        background: var(--bg-card);
        border-radius: var(--radius-lg);
        padding: 25px;
        margin-bottom: 30px;
    }
    
    .chapters-section h2,
    .characters-section h2 {
        margin-bottom: 20px;
        padding-bottom: 15px;
        border-bottom: 1px solid var(--border-color);
    }
    
    .chapters-list {
        display: grid;
        gap: 10px;
    }
    
    .chapter-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px;
        background: var(--bg-secondary);
        border-radius: var(--radius-md);
        transition: var(--transition);
    }
    
    .chapter-item:hover {
        background: var(--bg-hover);
    }
    
    .chapter-title {
        font-weight: 500;
    }
    
    .chapter-meta {
        color: var(--text-muted);
        font-size: 0.85rem;
    }
    
    .characters-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
        gap: 20px;
    }
    
    .character-card {
        text-align: center;
        padding: 20px;
        background: var(--bg-secondary);
        border-radius: var(--radius-md);
    }
    
    .character-avatar {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: var(--accent-gradient);
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 15px;
        font-size: 2rem;
        color: var(--text-primary);
    }
    
    .character-name {
        font-weight: 600;
        margin-bottom: 5px;
    }
    
    @media (max-width: 768px) {
        .comic-detail {
            grid-template-columns: 1fr;
        }
        
        .comic-cover {
            position: static;
            max-width: 200px;
            margin: 0 auto;
        }
    }
</style>

<div class="comic-detail">
    <div class="comic-cover">
        <img src="<?php echo h(getThumbnail($comic['HardCopyLink'], $comic['Name'])); ?>" 
             alt="<?php echo h($comic['Title'] ?: $comic['Name']); ?>">
    </div>
    
    <div class="comic-meta">
        <h1><?php echo h($comic['Title'] ?: $comic['Name']); ?></h1>
        
        <div class="meta-row">
            <button type="button" class="asura-rating-trigger" onclick="toggleRatingPopup(true)">
				<span class="star-icon">★</span>
				<span class="score-text"><?php echo number_format($comic['AvgRating'] ?? 0, 1); ?></span>
				<span class="rate-text">Rate</span>
			</button>
            <span style="color: var(--text-muted); font-size: 0.9rem; margin-left: 10px;">
                (<?php echo $comic['RatingCount']; ?> reviews)
            </span>
        </div>
        
        <div class="meta-row">
            <span class="meta-item">
                <strong>Author:</strong> <?php echo h($comic['ArtistName'] ?? 'Unknown'); ?>
            </span>
            <span class="meta-item">
                <strong>Chapters:</strong> <?php echo count($chapters); ?>
            </span>
        </div>
        
        <?php if (!empty($genres)): ?>
            <div class="genre-tags">
                <?php foreach ($genres as $genre): ?>
                    <span class="genre-tag"><?php echo h($genre); ?></span>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($comic['Synopsis'])): ?>
            <div class="synopsis">
                <strong>Synopsis:</strong><br><br>
                <?php echo nl2br(h($comic['Synopsis'])); ?>
            </div>
        <?php endif; ?>
        
        <div class="action-buttons">
            <?php if (!empty($chapters)): ?>
                <a href="reader.php?id=<?php echo $chapters[count($chapters)-1]['CHAPTER_ID']; ?>" class="btn btn-primary">
                    Read First Chapter
                </a>
                <a href="reader.php?id=<?php echo $chapters[0]['CHAPTER_ID']; ?>" class="btn btn-secondary">
                    Read Latest Chapter
                </a>
				<a href="community.php?id=<?php echo $comicId; ?>" class="btn btn-outline">
					💬 Community
				</a>
            <?php endif; ?>
            
            <?php if (!empty($comic['HardCopyLink'])): ?>
                <a href="<?php echo h($comic['HardCopyLink']); ?>" class="btn btn-outline" target="_blank">
                    Buy Hard Copy
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<section class="chapters-section">
    <h2>Chapters (<?php echo count($chapters); ?>)</h2>
    
    <div class="chapters-list">
        <?php foreach ($chapters as $chapter): ?>
            <a href="reader.php?id=<?php echo $chapter['CHAPTER_ID']; ?>" class="chapter-item">
                <span class="chapter-title">Chapter <?php echo $chapter['ChapterNumber']; ?></span>
                <span class="chapter-meta">
                    <?php echo $chapter['Date_of_Publication'] ? date('M j, Y', strtotime($chapter['Date_of_Publication'])) : 'N/A'; ?>
                </span>
            </a>
        <?php endforeach; ?>
        
        <?php if (empty($chapters)): ?>
            <p style="color: var(--text-muted); text-align: center; padding: 20px;">
                No chapters available yet.
            </p>
        <?php endif; ?>
    </div>
</section>

<?php if (!empty($characters)): ?>
<section class="characters-section">
    <h2>Characters</h2>
    
    <div class="characters-grid">
        <?php foreach ($characters as $character): ?>
            <div class="character-card">
                <div class="character-avatar">
                    <?php echo mb_substr($character['Name'], 0, 1); ?>
                </div>
                <div class="character-name"><?php echo h($character['Name']); ?></div>
                <?php if (!empty($character['Biography'])): ?>
                    <div class="character-bio" style="color: var(--text-muted); font-size: 0.8rem;">
                        <?php echo h(substr($character['Biography'], 0, 50)); ?>...
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<div id="asuraRatingModal" class="rating-overlay">
    <div class="rating-modal-box">
        <?php if (isUserLoggedIn()): ?>
            <h3 style="margin-bottom: 5px;">Rate This Comic</h3>
            <p style="color: var(--text-secondary); font-size: 0.9rem;">Give it a score out of 10</p>
            
            
			<form method="POST" action="comic.php?id=<?php echo $comicId; ?>">
                <div class="star-rating-row">
                    <?php for($i=10; $i>=1; $i--): ?>
                        <input type="radio" id="star<?php echo $i; ?>" name="score" value="<?php echo $i; ?>" required>
                        <label for="star<?php echo $i; ?>">★</label>
                    <?php endfor; ?>
                </div>
                
                <textarea name="review_text" placeholder="Write a short review (optional)..." 
                          maxlength="1000" style="width:100%; height:100px; background: #111; color: white; border: 1px solid #333; padding: 12px; border-radius: 8px; resize: none; margin-bottom: 20px;"></textarea>
                
                <div style="display: flex; gap: 10px;">
                    <button type="submit" name="submit_asura_rating" value="1" class="btn btn-primary" style="flex: 1;">Submit</button>
                    <button type="button" class="btn btn-secondary" style="flex: 1;" onclick="toggleRatingPopup(false)">Cancel</button>
                </div>
            </form>
        <?php else: ?>
            <h3 style="margin-bottom: 15px;">Login Required</h3>
            <p style="color: var(--text-secondary); font-size: 0.9rem; margin-bottom: 20px;">You must be logged in to rate and review comics.</p>
            <div style="display: flex; gap: 10px;">
                <a href="login_user.php" class="btn btn-primary" style="flex: 1;">Login</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
function toggleRatingPopup(show) {
    const modal = document.getElementById('asuraRatingModal');
    modal.style.display = show ? 'flex' : 'none';
    
    // Prevent background scrolling when modal is open
    document.body.style.overflow = show ? 'hidden' : 'auto';
}

// Close if clicking outside the box
window.onclick = function(event) {
    const modal = document.getElementById('asuraRatingModal');
    if (event.target == modal) {
        toggleRatingPopup(false);
    }
}
</script>

<section class="public-reviews-section">
    <div class="container">
        <h2>Community Reviews</h2>
        <div class="reviews-grid">
            <?php if (empty($reviews)): ?>
                <p style="color: var(--text-muted);">No reviews yet. Be the first to rate!</p>
            <?php else: ?>
                <?php foreach ($reviews as $row): ?>
                    <div class="review-display-card">
                        <div class="review-header">
                            <strong class="reviewer-name"><?php echo htmlspecialchars($row['UserName']); ?></strong>
                            <span class="review-score" style="color: var(--warning);">
                                <?php echo number_format($row['Score'], 1); ?> ★
                            </span>
                        </div>
                        <p class="review-body"><?php echo htmlspecialchars($row['ReviewText']); ?></p>
                        <div class="review-footer">
                            <small class="text-muted"><?php echo date('M j, Y', strtotime($row['TIME_STAMP'])); ?></small>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<section class="community-preview-section" style="padding: 40px 0; border-top: 1px solid var(--border-color); margin-top: 20px;">
    <div class="container">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2>Community Discussions</h2>
            <a href="community.php?id=<?php echo $comicId; ?>" class="btn btn-outline" style="font-size: 0.9rem;">View All Posts</a>
        </div>

        <?php
        // Fetch 3 latest posts for this specific comic
        $stmt = $pdo->prepare("
            SELECT f.*, u.Name as UserName 
            FROM FORUM_POST f 
            JOIN USERS u ON f.UID = u.ID 
            WHERE f.Comic_ID = ? 
            ORDER BY f.TimeStamp DESC 
            LIMIT 3
        ");
        $stmt->execute([$comicId]);
        $previewPosts = $stmt->fetchAll();
        ?>

        <div class="posts-preview-grid" style="display: flex; flex-direction: column; gap: 15px;">
            <?php if (empty($previewPosts)): ?>
                <p style="color: var(--text-muted);">No discussions yet. Start the conversation in the community tab!</p>
            <?php else: ?>
                <?php foreach ($previewPosts as $post): ?>
                    <div class="post-preview-card" style="background: var(--bg-card); border: 1px solid var(--border-color); padding: 15px; border-radius: var(--radius-md);">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                            <strong style="color: var(--accent-secondary);"><?php echo htmlspecialchars($post['UserName']); ?></strong>
                            <small class="text-muted"><?php echo date('M j, g:i a', strtotime($post['TimeStamp'])); ?></small>
                        </div>
                        <p style="color: var(--text-secondary); margin: 0; line-height: 1.5;">
                            <?php echo htmlspecialchars(mb_strimwidth($post['Content'], 0, 150, "...")); ?>
                        </p>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php require_once 'footer.php'; ?>