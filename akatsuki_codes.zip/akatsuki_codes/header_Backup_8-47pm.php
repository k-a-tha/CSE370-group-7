<?php
require_once __DIR__ . '/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? h($pageTitle) . ' - Akatsuki' : 'Akatsuki - Manga & Webtoon Platform'; ?></title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header class="main-header">
        <div class="header-container">
            <a href="index.php" class="logo">
                <span class="logo-icon">🕮</span>
                <span class="logo-text">Akatsuki</span>
            </a>
            
            <nav class="main-nav">
                <a href="index.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : ''; ?>">HOME</a>
                <div class="nav-dropdown">
                    <a href="#" class="nav-link">All Webtoons <span class="dropdown-arrow">▼</span></a>
                    <div class="dropdown-content">
                        <a href="comics.php?genre=romance">Romance</a>
                        <a href="comics.php?genre=action">Action</a>
                        <a href="comics.php?genre=fantasy">Fantasy</a>
                        <a href="comics.php?genre=comedy">Comedy</a>
                        <a href="comics.php?genre=drama">Drama</a>
                    </div>
                </div>
				<form action="comics.php" method="GET" class="header-search-form">
					<div class="search-input-group">
						<?php if(isset($_GET['genre']) && !empty($_GET['genre'])): ?>
						<input type="hidden" name="genre" value="<?php echo h($_GET['genre']); ?>">
						<?php endif; ?>
						<input type="text" name="search" placeholder="Search comics..." 
						   value="<?php echo isset($_GET['search']) ? h($_GET['search']) : ''; ?>">
						<button type="submit" class="search-submit-btn">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
								<circle cx="11" cy="11" r="8"></circle>
								<path d="M21 21l-4.35-4.35"></path>
							</svg>
						</button>
					</div>
				</form>

            </nav>

            <div class="genre-nav">
                <a href="comics.php?genre=romance">ROMANCE</a>
                <a href="comics.php?genre=manhwa">MANHWA</a>
                <a href="comics.php?genre=manhua">MANHUA</a>
                <div class="nav-dropdown">
                    <a href="#">MORE ▶</a>
                    <div class="dropdown-content">
                        <a href="comics.php?genre=action">Action</a>
                        <a href="comics.php?genre=fantasy">Fantasy</a>
                        <a href="comics.php?genre=slice-of-life">Slice of Life</a>
                        <a href="comics.php?genre=horror">Horror</a>
                    </div>
                </div>
            </div>

            <div class="auth-buttons">
                <?php if (isLoggedIn()): ?>
                    <span class="welcome-text">Welcome, <?php echo h($_SESSION['user_name']); ?></span>
                    <a href="logout.php" class="btn btn-outline">Logout</a>
                <?php else: ?>
                    <a href="login_user.php" class="btn btn-outline">Sign in</a>
                    <a href="register_user.php" class="btn btn-outline">Sign up</a>
                <?php endif; ?>
            </div>

            <button class="mobile-menu-btn" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </header>
    <main class="main-content">
