<?php
//index.php
$pageTitle = 'Home';
require_once 'header.php';

// Fetch featured comics with their latest chapters
$featuredQuery = $pdo->query("
    SELECT
        c.ID,
        c.Name,
        c.Title,
        c.HardCopyLink,
        c.Synopsis,
        a.Name as ArtistName,
        COALESCE(AVG(r.Score), 0) as AvgRating,
        COUNT(DISTINCT r.UID) as RatingCount
    FROM COMIC c
    LEFT JOIN ARTIST a ON c.AID = a.ID
    LEFT JOIN RATING r ON c.ID = r.Comic_ID
    GROUP BY c.ID
    ORDER BY c.ID DESC
    LIMIT 8
");
$featuredComics = $featuredQuery->fetchAll();

// Fetch latest updated comics (comics with recent chapters)
$latestQuery = $pdo->query("
    SELECT
        c.ID,
        c.Name,
        c.Title,
        c.HardCopyLink,
        COALESCE(AVG(r.Score), 0) as AvgRating,
        ch.CHAPTER_ID,
        ch.ChapterNumber,
        ch.Date_of_Publication
    FROM COMIC c
    LEFT JOIN RATING r ON c.ID = r.Comic_ID
    LEFT JOIN CHAPTER ch ON c.ID = ch.Comic_ID AND ch.isPublished = TRUE
    GROUP BY c.ID, ch.CHAPTER_ID
    ORDER BY ch.Date_of_Publication DESC, c.ID DESC
    LIMIT 12
");
$latestComics = $latestQuery->fetchAll();

// Helper function to get recent chapters for a comic
function getRecentChapters($pdo, $comicId, $limit = 2) {
    $stmt = $pdo->prepare("
        SELECT CHAPTER_ID, ChapterNumber, Date_of_Publication
        FROM CHAPTER
        WHERE Comic_ID = :comic_id AND isPublished = TRUE
        ORDER BY ChapterNumber DESC
        LIMIT :limit
    ");
    $stmt->bindValue(':comic_id', $comicId, PDO::PARAM_INT);
    $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

// Helper function to render star rating
function renderStars($rating) {
    $fullStars = floor($rating / 2);
    $halfStar = ($rating / 2) - $fullStars >= 0.5;
    $emptyStars = 5 - $fullStars - ($halfStar ? 1 : 0);
    $html = '';
    for ($i = 0; $i < $fullStars; $i++) $html .= '★';
    if ($halfStar) $html .= '☆';
    for ($i = 0; $i < $emptyStars; $i++) $html .= '☆';
    return $html;
}

// Helper to get thumbnail path
function getThumbnail($hardCopyLink, $comicName) {
    if (!empty($hardCopyLink)) {
        return h($hardCopyLink);
    }
    $slug = strtolower(str_replace(' ', '-', $comicName));
    $path = "assets/thumbnails/{$slug}.webp";
    if (file_exists($_SERVER['DOCUMENT_ROOT'] . "/akatsuki/" . $path)) {
        return $path;
    }
    return "assets/thumbnails/placeholder.webp";
}
?>

<div class="homepage-grid">
    <div class="main-column">
        <!-- Featured Comics Section -->
        <section class="featured-section">
            <div class="section-header">
                <h2 class="section-title">Featured Comics</h2>
            </div>

            <div class="featured-grid">
                <?php foreach ($featuredComics as $comic): ?>
                    <?php $chapters = getRecentChapters($pdo, $comic['ID']); ?>
                    <article class="comic-card">
                        <a href="comic.php?id=<?php echo $comic['ID']; ?>" class="comic-thumbnail">
                            <img src="<?php echo h(getThumbnail($comic['HardCopyLink'], $comic['Name'])); ?>"
                                 alt="<?php echo h($comic['Title'] ?: $comic['Name']); ?>"
                                 loading="lazy">
                            <span class="hot-badge">HOT</span>
                        </a>
                        <div class="comic-info">
                            <h3 class="comic-title">
                                <a href="comic.php?id=<?php echo $comic['ID']; ?>">
                                    <?php echo h($comic['Title'] ?: $comic['Name']); ?>
                                </a>
                            </h3>
                            <div class="comic-rating">
                                <span class="stars"><?php echo renderStars($comic['AvgRating']); ?></span>
                                <span class="rating-value"><?php echo number_format($comic['AvgRating'], 1); ?></span>
                            </div>
                            <div class="comic-chapters">
                                <?php foreach ($chapters as $chapter): ?>
                                    <a href="reader.php?id=<?php echo $chapter['CHAPTER_ID']; ?>" class="chapter-link">
                                        Chapter <?php echo $chapter['ChapterNumber']; ?>
                                        <span class="chapter-new">NEW</span>
                                    </a>
                                <?php endforeach; ?>
                                <?php if (empty($chapters)): ?>
                                    <span class="chapter-date">Coming soon</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>

                <?php if (empty($featuredComics)): ?>
                    <p class="text-center" style="grid-column: 1/-1; color: var(--text-muted);">
                        No comics available yet. Check back soon!
                    </p>
                <?php endif; ?>
            </div>
        </section>

        <!-- Latest Manga Updates Section -->
        <section class="updates-section">
            <div class="section-header">
                <span class="section-badge">LATEST MANGA UPDATES</span>
            </div>

            <div class="updates-grid">
                <?php
                $displayedComics = [];
                foreach ($latestComics as $comic):
                    if (in_array($comic['ID'], $displayedComics)) continue;
                    $displayedComics[] = $comic['ID'];
                    $chapters = getRecentChapters($pdo, $comic['ID']);
                ?>
                    <article class="comic-card">
                        <a href="comic.php?id=<?php echo $comic['ID']; ?>" class="comic-thumbnail">
                            <img src="<?php echo h(getThumbnail($comic['HardCopyLink'], $comic['Name'])); ?>"
                                 alt="<?php echo h($comic['Title'] ?: $comic['Name']); ?>"
                                 loading="lazy">
                        </a>
                        <div class="comic-info">
                            <h3 class="comic-title">
                                <a href="comic.php?id=<?php echo $comic['ID']; ?>">
                                    <?php echo h($comic['Title'] ?: $comic['Name']); ?>
                                </a>
                            </h3>
                            <div class="comic-rating">
                                <span class="stars"><?php echo renderStars($comic['AvgRating']); ?></span>
                                <span class="rating-value"><?php echo number_format($comic['AvgRating'], 1); ?></span>
                            </div>
                            <div class="comic-chapters">
                                <?php foreach ($chapters as $chapter): ?>
                                    <a href="reader.php?id=<?php echo $chapter['CHAPTER_ID']; ?>" class="chapter-link">
                                        Chapter <?php echo $chapter['ChapterNumber']; ?>
                                        <span class="chapter-new">NEW</span>
                                    </a>
                                <?php endforeach; ?>
                                <?php if (!empty($chapters) && !empty($chapters[0]['Date_of_Publication'])): ?>
                                    <span class="chapter-date">
                                        <?php echo date('F j, Y', strtotime($chapters[0]['Date_of_Publication'])); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    </div>
</div>

<?php require_once 'footer.php'; ?>
