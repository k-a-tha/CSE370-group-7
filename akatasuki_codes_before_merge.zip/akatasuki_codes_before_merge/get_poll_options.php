<?php
// get_poll_options.php
// AJAX helper for admin_panel.php - returns poll options for a chapter as JSON

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'db.php';

// Artist only
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'artist') {
    echo json_encode([]);
    exit;
}

$chapterId = intval($_GET['chapter_id'] ?? 0);
if (!$chapterId) {
    echo json_encode([]);
    exit;
}

$stmt = $pdo->prepare("
    SELECT ID, Option_Number, OptionText 
    FROM PREDICTION_OPTION 
    WHERE Chapter_ID = ?
    ORDER BY Option_Number ASC
");
$stmt->execute([$chapterId]);
echo json_encode($stmt->fetchAll());
