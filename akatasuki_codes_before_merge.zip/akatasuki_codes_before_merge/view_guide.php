<?php
// view_guide.php  —  Anyone (user, artist, guest) can view the guide.
require_once 'db.php';

$comicId = isset($_GET['comic_id']) ? (int)$_GET['comic_id'] : 0;
if (!$comicId) {
    header('Location: index.php');
    exit;
}

// ── Fetch comic & guide path ──────────────────────────
$stmt = $pdo->prepare("
    SELECT c.ID, c.Name, c.Title, c.PDF, c.HardCopyLink, c.AID,
           a.Name AS ArtistName
    FROM COMIC c
    JOIN ARTIST a ON c.AID = a.ID
    WHERE c.ID = ?
");
$stmt->execute([$comicId]);
$comic = $stmt->fetch();

if (!$comic) {
    header('Location: index.php');
    exit;
}

$comicLabel = $comic['Title'] ?: $comic['Name'];
$guideFile  = "assets/guides/comic-{$comicId}.html";

// If no guide exists, redirect back with a message
if (empty($comic['PDF']) || !file_exists($guideFile)) {
    header("Location: comic.php?id={$comicId}&no_guide=1");
    exit;
}

// ── Parse the saved JSON blob from the guide file ─────
$raw  = file_get_contents($guideFile);
$data = null;
if (preg_match('/<script type="application\/json" id="guide-data">(.*?)<\/script>/s', $raw, $m)) {
    $data = json_decode(html_entity_decode($m[1]), true);
}

if (!$data) {
    header("Location: comic.php?id={$comicId}");
    exit;
}

// ── Check if logged-in artist owns this comic ─────────
$isOwner = isArtistLoggedIn() && (int)$_SESSION['user_id'] === (int)$comic['AID'];

$pageTitle = ($data['guide_title'] ?: $comicLabel) . ' — Guide';
require_once 'header.php';
?>

<style>
/* ── Wrapper ──────────────────────────────────────────── */
.gv-wrap        { max-width: 820px; margin: 0 auto; }

.gv-back        { display: inline-flex; align-items: center; gap: 8px; color: var(--text-muted);
                  font-size: 0.88rem; margin-bottom: 20px; text-decoration: none; transition: color .2s; }
.gv-back:hover  { color: var(--text-primary); }

/* ── Hero ─────────────────────────────────────────────── */
.gv-hero        { background: var(--bg-card); border: 1px solid var(--border-color);
                  border-radius: var(--radius-lg); padding: 32px; margin-bottom: 28px;
                  display: flex; gap: 24px; align-items: flex-start; }
.gv-cover       { width: 80px; height: 110px; object-fit: cover;
                  border-radius: var(--radius-md); flex-shrink: 0; }
.gv-hero-info   { flex: 1; min-width: 0; }
.gv-comic-name  { font-size: 0.82rem; font-weight: 600; text-transform: uppercase;
                  letter-spacing: .07em; color: var(--accent-color, #818cf8); margin-bottom: 6px; }
.gv-main-title  { font-size: 1.8rem; font-weight: 800; color: var(--text-primary);
                  line-height: 1.2; margin-bottom: 10px; }
.gv-by          { font-size: 0.85rem; color: var(--text-muted); }
.gv-by strong   { color: var(--text-secondary); }

/* Edit button shown only to owner */
.btn-edit-guide { display: inline-flex; align-items: center; gap: 6px;
                  padding: 7px 16px; background: rgba(129,140,248,.12);
                  border: 1px solid rgba(129,140,248,.3); color: var(--accent-color, #818cf8);
                  border-radius: var(--radius-sm); font-size: 0.82rem; font-weight: 600;
                  text-decoration: none; transition: all .2s; margin-top: 14px; }
.btn-edit-guide:hover { background: rgba(129,140,248,.22); }

/* ── Section card ─────────────────────────────────────── */
.gv-card        { background: var(--bg-card); border: 1px solid var(--border-color);
                  border-radius: var(--radius-lg); padding: 28px; margin-bottom: 20px; }
.gv-overview    { color: var(--text-secondary); line-height: 1.85; font-size: 0.97rem; }

.gv-section     { margin-bottom: 0; }
.gv-section + .gv-section { margin-top: 28px; padding-top: 28px;
                             border-top: 1px solid var(--border-color); }

.gv-sec-heading { font-size: 1.15rem; font-weight: 700; color: var(--text-primary);
                  margin-bottom: 14px; display: flex; align-items: center; gap: 10px; }
.gv-sec-heading::before { content: ''; width: 4px; height: 20px;
                           background: var(--accent-color, #818cf8);
                           border-radius: 2px; flex-shrink: 0; }
.gv-sec-body    { color: var(--text-secondary); line-height: 1.85; font-size: 0.95rem; }

/* ── Tips ─────────────────────────────────────────────── */
.gv-tips-block  { background: rgba(129,140,248,.06); border: 1px solid rgba(129,140,248,.2);
                  border-radius: var(--radius-lg); padding: 24px; margin-bottom: 20px; }
.gv-tips-block .gv-sec-heading::before { background: #fbbf24; }
.gv-tips-list   { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 10px; }
.gv-tips-list li { display: flex; align-items: flex-start; gap: 10px;
                   color: var(--text-secondary); font-size: 0.95rem; line-height: 1.6; }
.gv-tips-list li::before { content: '✦'; color: #fbbf24; font-size: 0.8rem;
                            margin-top: 3px; flex-shrink: 0; }

/* ── Final notes ──────────────────────────────────────── */
.gv-final       { background: rgba(34,197,94,.05); border: 1px solid rgba(34,197,94,.2);
                  border-radius: var(--radius-lg); padding: 24px; }
.gv-final .gv-sec-heading::before { background: #4ade80; }
.gv-final .gv-sec-body { color: var(--text-secondary); }

/* ── Table of contents ────────────────────────────────── */
.gv-toc         { background: var(--bg-card); border: 1px solid var(--border-color);
                  border-radius: var(--radius-lg); padding: 20px 24px; margin-bottom: 20px; }
.gv-toc h4      { font-size: 0.78rem; text-transform: uppercase; letter-spacing: .09em;
                  color: var(--text-muted); margin-bottom: 12px; }
.gv-toc ol      { padding-left: 18px; margin: 0; display: flex; flex-direction: column; gap: 6px; }
.gv-toc ol li   { color: var(--text-secondary); font-size: 0.9rem; }
.gv-toc ol li a { color: var(--accent-color, #818cf8); text-decoration: none; }
.gv-toc ol li a:hover { text-decoration: underline; }

/* ── Responsive ───────────────────────────────────────── */
@media (max-width: 540px) {
    .gv-hero { flex-direction: column; }
    .gv-main-title { font-size: 1.4rem; }
}
</style>

<div class="gv-wrap">

    <a href="comic.php?id=<?php echo $comicId; ?>" class="gv-back">← Back to Comic</a>

    <!-- ── Hero ────────────────────────────────────────── -->
    <div class="gv-hero">
        <?php
        $slug  = strtolower(str_replace(' ', '-', $comic['Name']));
        $thumb = !empty($comic['HardCopyLink']) ? $comic['HardCopyLink'] : "assets/thumbnails/{$slug}.webp";
        ?>
        <img src="<?php echo h($thumb); ?>" alt="" class="gv-cover">
        <div class="gv-hero-info">
            <div class="gv-comic-name">📖 Reading Guide</div>
            <div class="gv-main-title"><?php echo h($data['guide_title']); ?></div>
            <div class="gv-by">
                For <strong><?php echo h($comicLabel); ?></strong>
                &nbsp;·&nbsp; by <strong><?php echo h($comic['ArtistName']); ?></strong>
            </div>
            <?php if ($isOwner): ?>
                <a href="create_guide.php?comic_id=<?php echo $comicId; ?>" class="btn-edit-guide">
                    ✏️ Edit Guide
                </a>
            <?php endif; ?>
        </div>
    </div>

    <?php
    // ── Build table of contents entries ──────────────────
    $tocItems = [];
    if ($data['overview'])    $tocItems[] = 'Overview';
    foreach ($data['sections'] as $s) {
        if ($s['heading']) $tocItems[] = $s['heading'];
    }
    if ($data['tips'])        $tocItems[] = 'Tips & Tricks';
    if ($data['final_notes']) $tocItems[] = 'Final Notes';
    ?>

    <?php if (count($tocItems) > 1): ?>
    <div class="gv-toc">
        <h4>Contents</h4>
        <ol>
            <?php foreach ($tocItems as $i => $item): ?>
                <li><a href="#section-<?php echo $i; ?>"><?php echo h($item); ?></a></li>
            <?php endforeach; ?>
        </ol>
    </div>
    <?php endif; ?>

    <?php
    $tocIndex = 0; // track which TOC anchor we're on

    // ── Overview ──────────────────────────────────────────
    if ($data['overview']):
    ?>
    <div class="gv-card" id="section-<?php echo $tocIndex++; ?>">
        <div class="gv-section">
            <div class="gv-sec-heading">Overview</div>
            <div class="gv-overview"><?php echo nl2br(h($data['overview'])); ?></div>
        </div>
    </div>
    <?php endif; ?>

    <!-- ── Content Sections ─────────────────────────────── -->
    <?php
    $hasAnySections = false;
    foreach ($data['sections'] as $s) {
        if ($s['heading'] || $s['body']) { $hasAnySections = true; break; }
    }
    if ($hasAnySections):
    ?>
    <div class="gv-card">
        <?php $first = true; ?>
        <?php foreach ($data['sections'] as $s):
            if (!$s['heading'] && !$s['body']) continue;
        ?>
        <div class="gv-section" id="section-<?php echo $tocIndex++; ?>">
            <?php if ($s['heading']): ?>
                <div class="gv-sec-heading"><?php echo h($s['heading']); ?></div>
            <?php endif; ?>
            <?php if ($s['body']): ?>
                <div class="gv-sec-body"><?php echo nl2br(h($s['body'])); ?></div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- ── Tips ─────────────────────────────────────────── -->
    <?php if (!empty($data['tips'])):
        $tipLines = array_filter(array_map('trim', explode("\n", $data['tips'])));
    ?>
    <div class="gv-tips-block" id="section-<?php echo $tocIndex++; ?>">
        <div class="gv-sec-heading">💡 Tips &amp; Tricks</div>
        <ul class="gv-tips-list">
            <?php foreach ($tipLines as $tip): ?>
                <li><?php echo h($tip); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <!-- ── Final Notes ──────────────────────────────────── -->
    <?php if (!empty($data['final_notes'])): ?>
    <div class="gv-final" id="section-<?php echo $tocIndex++; ?>">
        <div class="gv-sec-heading">📝 Final Notes</div>
        <div class="gv-sec-body"><?php echo nl2br(h($data['final_notes'])); ?></div>
    </div>
    <?php endif; ?>

</div>

<?php require_once 'footer.php'; ?>
